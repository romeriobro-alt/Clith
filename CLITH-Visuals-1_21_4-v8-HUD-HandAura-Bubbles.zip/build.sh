#!/usr/bin/env sh
set -eu
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle was not found. Install Gradle 8.12. The original archive did not include the wrapper JAR." >&2
  exit 1
fi
gradle build
