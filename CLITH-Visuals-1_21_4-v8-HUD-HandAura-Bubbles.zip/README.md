# CLITH 1.21.4 — winter neon visual client (v8)

## Что нового в v8

- **Небо**: удалены пресеты Sunset Glow, Synthwave и Void Rings. Добавлен **«Зимний неон»** (по умолчанию): белый переливающийся купол, пушистые облака, длинные светящиеся завитки, кристаллические снежинки, узоры-мандалы, мерцающие 4-лучевые звёзды. Настройки: «Цвет неона» (палитра), «Перелив», «Узоры», «Снежинки».
- **Частицы**: модуль Particles теперь рисует собственные светящиеся частицы в мире (свечение, звёзды, снежинки, сердца, ромбы, кольца). Режимы: вокруг / шлейф / аура; цвет — палитра, градиент из двух палитр, радуга или тема.
- **Шрифт**: Go Sans заменён на Inter (Latin + Cyrillic, TrueType); тексты и ширины кэшируются.
- **HUD и GUI**: стеклянные полупрозрачные панели с градиентной рамкой, анимации появления модулей в списке, нажатия клавиш, переключатели, ползунки, маркер вкладок, снег в меню. Клик по логотипу или по цветным точкам внизу — смена темы (по умолчанию Ice).
- Старые конфиги (до v3) стартуют с новой темой и новым небом.

> В исходной v7 указывалась проверка против заглушек API; изменения v8 прошли синтаксический разбор Java, но полная Gradle-сборка и запуск Minecraft в этом окружении не выполнялись.

## Build

Use JDK 21 and Gradle 8.12 or newer compatible with Fabric Loom 1.9.2. The project targets Minecraft 1.21.4, Yarn `1.21.4+build.8`, Fabric Loader 0.16.10 and Fabric API `0.118.0+1.21.4`.

The archive has a `build.bat` and `build.sh`. The Gradle wrapper JAR is not included in this project copy, so use an installed Gradle or the Gradle tool window in IntelliJ IDEA. `settings.gradle` includes the Fabric Maven repository for Loom plugin resolution.

## Crash fix (2026-10-20)

- Fixed `IllegalStateException: BufferBuilder was empty` in `ClithSkyRenderer.drawGalaxyStars`.
- `drawGalaxyStars` and `drawGoldenParticles` now use one Tessellator buffer per draw call. The prior code began the shared Tessellator builder twice and then tried to end both references; the second `end()` could therefore end an already-finished, empty builder.
- The two affected render methods were exercised with a test Tessellator that reuses a single BufferBuilder, and both completed without the reported exception. This is a focused renderer test, not a full Minecraft/Fabric launch test.

## Reference HUD, hand aura and bubble trail

This revision adds a compact, glass-style status pill at the top centre of the screen (player name, FPS, local clock and multiplayer ping when available), plus an animated multicolour hand aura for first-person view. The aura has selectable palettes, pulse, size, brightness and sparkles in the `Hand Aura` module.

`Trails` now has a `Пузыри` style selected by default. Bubbles spawn while moving, rise and wobble independently, expand slightly, use the selected colour palette, and fade out with an iridescent rim and reflection. The particle module also includes `Мыльные пузыри` as a particle shape.

When loading a configuration saved by v3, the v4 migration preserves the selected theme and switches `Trails` to the requested bubble style once. You can change it back from the ClickGUI at any time.

