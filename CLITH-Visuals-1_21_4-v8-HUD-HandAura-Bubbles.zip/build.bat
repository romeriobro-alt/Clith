@echo off
setlocal
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle was not found. Install Gradle 8.12 or open the project in an IDE configured with a Gradle installation.
  echo The original archive did not include the Gradle wrapper JAR.
  exit /b 1
)
gradle build
if errorlevel 1 exit /b %errorlevel%
echo Build complete. Check build\libs for clith-*.jar.
