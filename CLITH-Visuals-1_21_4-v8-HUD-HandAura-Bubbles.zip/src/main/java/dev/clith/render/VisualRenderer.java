package dev.clith.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.clith.module.Module;
import dev.clith.module.ModuleManager;
import dev.clith.module.WorldEffect;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;

/** Draws every enabled WorldEffect module and keeps the matrices needed to project world points to the HUD. */
public final class VisualRenderer {
    private static final Matrix4f VIEW_PROJ = new Matrix4f();
    private static double camX, camY, camZ;
    private static boolean hasMatrix;
    private static long last = System.nanoTime();

    private VisualRenderer() {}

    public static void init() {
        WorldRenderEvents.BEFORE_ENTITIES.register(VisualRenderer::render);
    }

    private static void render(WorldRenderContext context) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        Vec3d cam = context.camera().getPos();
        camX = cam.x;
        camY = cam.y;
        camZ = cam.z;
        VIEW_PROJ.set(context.projectionMatrix()).mul(context.positionMatrix());
        hasMatrix = true;

        long n = System.nanoTime();
        float dt = Math.min(0.1f, (n - last) / 1_000_000_000f);
        last = n;

        boolean any = false;
        for (Module m : ModuleManager.MODULES) {
            if (m instanceof WorldEffect && m.isEnabled()) { any = true; break; }
        }
        if (!any) return;

        float tickDelta = mc.getRenderTickCounter().getTickDelta(false);
        double now = Gfx.now();
        Gfx g = new Gfx(Gfx.vertexMatrix(context.positionMatrix()), context.positionMatrix(), cam, dt);

        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        for (Module m : ModuleManager.MODULES) {
            if (m instanceof WorldEffect fx && m.isEnabled()) {
                fx.renderWorld(g, tickDelta, now);
                g.flush();
            }
        }

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    /** Projects a world position to scaled GUI coordinates. Returns null if it is behind the camera. */
    public static float[] project(double x, double y, double z, int scaledW, int scaledH) {
        if (!hasMatrix) return null;
        Vector4f v = new Vector4f((float) (x - camX), (float) (y - camY), (float) (z - camZ), 1f);
        VIEW_PROJ.transform(v);
        if (v.w <= 0.05f) return null;
        float nx = v.x / v.w, ny = v.y / v.w;
        if (nx < -1.5f || nx > 1.5f || ny < -1.5f || ny > 1.5f) return null;
        return new float[]{(nx * 0.5f + 0.5f) * scaledW, (0.5f - ny * 0.5f) * scaledH};
    }
}
