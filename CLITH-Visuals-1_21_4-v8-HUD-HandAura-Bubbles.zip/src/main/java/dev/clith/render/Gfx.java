package dev.clith.render;

import dev.clith.gui.Draw;
import dev.clith.gui.ThemeManager;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * Tiny immediate-mode helper for world-space effects. Coordinates passed in are WORLD coordinates;
 * they are made camera-relative here. The batch is started lazily and only ended when it has
 * vertices, so an empty frame can never trigger "BufferBuilder was empty".
 */
public final class Gfx {
    public static final String[] COLOR_MODES = {"Тема", "Радуга", "Янтарь", "Океан", "Сакура"};

    public final float dt;
    public final Matrix4f m;
    public final double cx, cy, cz;
    /** Camera right / up axes expressed in world space (for billboards). */
    public final float rx, ry, rz, ux, uy, uz;
    private BufferBuilder b;

    /**
     * In 1.21.4 the world renderer has already put the camera rotation into the model-view matrix
     * by the time Fabric fires BEFORE_ENTITIES, so vertices must NOT be multiplied by positionMatrix
     * again. This is deliberately constant: an earlier version tried to detect it per frame, but
     * the model-view lags behind while the camera turns, which made the result flip between frames
     * and the world flicker.
     */
    public static Matrix4f vertexMatrix(Matrix4f positionMatrix) {
        return new Matrix4f();
    }

    public Gfx(Matrix4f vertexMatrix, Matrix4f view, Vec3d cam, float dt) {
        this.m = new Matrix4f(vertexMatrix);
        this.cx = cam.x;
        this.cy = cam.y;
        this.cz = cam.z;
        this.dt = dt;
        this.rx = view.m00();
        this.ry = view.m10();
        this.rz = view.m20();
        this.ux = view.m01();
        this.uy = view.m11();
        this.uz = view.m21();
    }

    public static double now() {
        return System.nanoTime() / 1_000_000_000.0;
    }

    public static int color(int mode, float t) {
        t -= (float) Math.floor(t);
        float p = 1f - Math.abs(2f * t - 1f);
        return switch (mode) {
            case 0 -> Draw.lerp(ThemeManager.current().primary, ThemeManager.current().secondary, p);
            case 1 -> MathHelper.hsvToRgb(t, 0.6f, 1f);
            case 2 -> Draw.lerp(0xFFD27A, 0xF97316, p);
            case 3 -> Draw.lerp(0x38BDF8, 0x6366F1, p);
            default -> Draw.lerp(0xFB7185, 0xA855F7, p);
        };
    }

    /** Draws and clears whatever is queued. Safe to call with nothing queued. */
    public void flush() {
        if (b != null) {
            BufferRenderer.drawWithGlobalProgram(b.end());
            b = null;
        }
    }

    public void v(double x, double y, double z, int rgb, float a) {
        if (b == null) b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        float al = MathHelper.clamp(a, 0f, 1f);
        b.vertex(m, (float) (x - cx), (float) (y - cy), (float) (z - cz))
                .color(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f, al);
    }

    public void tri(double x1, double y1, double z1, int c1, float a1,
                    double x2, double y2, double z2, int c2, float a2,
                    double x3, double y3, double z3, int c3, float a3) {
        v(x1, y1, z1, c1, a1);
        v(x2, y2, z2, c2, a2);
        v(x3, y3, z3, c3, a3);
        v(x3, y3, z3, c3, a3);
    }

    /** Flat ring on a horizontal plane. dash &gt; 0 leaves gaps (segments on / segments off). */
    public void ringFlat(double x, double y, double z, double r0, double r1, int segs, double rot,
                         int mode, float a0, float a1, float hue, int dash) {
        for (int i = 0; i < segs; i++) {
            if (dash > 0 && (i / dash) % 2 == 1) continue;
            double s0 = rot + Math.PI * 2 * i / segs, s1 = rot + Math.PI * 2 * (i + 1) / segs;
            int c0 = color(mode, (float) i / segs + hue), c1 = color(mode, (float) (i + 1) / segs + hue);
            double ax = Math.cos(s0), az = Math.sin(s0), bx = Math.cos(s1), bz = Math.sin(s1);
            v(x + ax * r0, y, z + az * r0, c0, a0);
            v(x + ax * r1, y, z + az * r1, c0, a1);
            v(x + bx * r1, y, z + bz * r1, c1, a1);
            v(x + bx * r0, y, z + bz * r0, c1, a0);
        }
    }

    /** Filled horizontal disk, bright in the middle and soft at the edge. */
    public void disk(double x, double y, double z, double r, int segs, int mode, float aCenter, float aEdge, float hue) {
        int cc = color(mode, hue);
        for (int i = 0; i < segs; i++) {
            double s0 = Math.PI * 2 * i / segs, s1 = Math.PI * 2 * (i + 1) / segs;
            int c0 = color(mode, (float) i / segs + hue), c1 = color(mode, (float) (i + 1) / segs + hue);
            tri(x, y, z, cc, aCenter,
                    x + Math.cos(s0) * r, y, z + Math.sin(s0) * r, c0, aEdge,
                    x + Math.cos(s1) * r, y, z + Math.sin(s1) * r, c1, aEdge);
        }
    }

    /** Vertical cylinder band (open tube) between y0 and y1. */
    public void band(double x, double z, double y0, double y1, double r, int segs, double rot,
                     int mode, float aBottom, float aTop, float hue) {
        for (int i = 0; i < segs; i++) {
            double s0 = rot + Math.PI * 2 * i / segs, s1 = rot + Math.PI * 2 * (i + 1) / segs;
            int c0 = color(mode, (float) i / segs + hue), c1 = color(mode, (float) (i + 1) / segs + hue);
            double ax = Math.cos(s0) * r, az = Math.sin(s0) * r, bx = Math.cos(s1) * r, bz = Math.sin(s1) * r;
            v(x + ax, y0, z + az, c0, aBottom);
            v(x + bx, y0, z + bz, c1, aBottom);
            v(x + bx, y1, z + bz, c1, aTop);
            v(x + ax, y1, z + az, c0, aTop);
        }
    }

    /** Soft round glow that always faces the camera. */
    public void glow(double x, double y, double z, double size, int rgb, float a) {
        int segs = 10;
        for (int i = 0; i < segs; i++) {
            double s0 = Math.PI * 2 * i / segs, s1 = Math.PI * 2 * (i + 1) / segs;
            double c0 = Math.cos(s0) * size, n0 = Math.sin(s0) * size, c1 = Math.cos(s1) * size, n1 = Math.sin(s1) * size;
            tri(x, y, z, rgb, a,
                    x + rx * c0 + ux * n0, y + ry * c0 + uy * n0, z + rz * c0 + uz * n0, rgb, 0f,
                    x + rx * c1 + ux * n1, y + ry * c1 + uy * n1, z + rz * c1 + uz * n1, rgb, 0f);
        }
    }

    /** Solid camera-facing square, rotated by rot (radians). */
    public void billboard(double x, double y, double z, double size, double rot, int rgb, float a) {
        double c = Math.cos(rot) * size, s = Math.sin(rot) * size;
        double ax = rx * c + ux * s, ay = ry * c + uy * s, az = rz * c + uz * s;
        double bx = -rx * s + ux * c, by = -ry * s + uy * c, bz = -rz * s + uz * c;
        v(x - ax - bx, y - ay - by, z - az - bz, rgb, a);
        v(x + ax - bx, y + ay - by, z + az - bz, rgb, a);
        v(x + ax + bx, y + ay + by, z + az + bz, rgb, a);
        v(x - ax + bx, y - ay + by, z - az + bz, rgb, a);
    }

    /** Ring in the camera plane. */
    public void billboardRing(double x, double y, double z, double r0, double r1, int segs, int rgb, float a0, float a1) {
        for (int i = 0; i < segs; i++) {
            double s0 = Math.PI * 2 * i / segs, s1 = Math.PI * 2 * (i + 1) / segs;
            double c0 = Math.cos(s0), n0 = Math.sin(s0), c1 = Math.cos(s1), n1 = Math.sin(s1);
            v(x + (rx * c0 + ux * n0) * r0, y + (ry * c0 + uy * n0) * r0, z + (rz * c0 + uz * n0) * r0, rgb, a0);
            v(x + (rx * c0 + ux * n0) * r1, y + (ry * c0 + uy * n0) * r1, z + (rz * c0 + uz * n0) * r1, rgb, a1);
            v(x + (rx * c1 + ux * n1) * r1, y + (ry * c1 + uy * n1) * r1, z + (rz * c1 + uz * n1) * r1, rgb, a1);
            v(x + (rx * c1 + ux * n1) * r0, y + (ry * c1 + uy * n1) * r0, z + (rz * c1 + uz * n1) * r0, rgb, a0);
        }
    }

    /**
     * Animated translucent bubble with a palette rim, tinted glass interior and a moving specular
     * highlight. All geometry is camera-facing, so it stays round from any viewing angle.
     */
    public void bubble(double x, double y, double z, double radius, double rot, int paletteMode, float hue, float alpha) {
        drawBubble(x, y, z, radius, rot, paletteMode, hue, 0, 0, alpha);
    }

    /** Bubble variant used by effects that already calculated their own colour palette. */
    public void bubble(double x, double y, double z, double radius, double rot, int rgb, int highlight, float alpha) {
        drawBubble(x, y, z, radius, rot, -1, 0f, rgb, highlight, alpha);
    }

    private void drawBubble(double x, double y, double z, double radius, double rot,
                            int paletteMode, float hue, int baseRgb, int highlightRgb, float alpha) {
        if (radius <= 0.001 || alpha <= 0.005f) return;
        int segs = 28;
        double inner = radius * 0.70;
        double outer = radius * 0.91;
        int tint = paletteMode >= 0 ? color(paletteMode, hue) : baseRgb;
        int bright = paletteMode >= 0 ? color(paletteMode, hue + 0.18f) : highlightRgb;

        for (int i = 0; i < segs; i++) {
            double a0 = rot + Math.PI * 2 * i / segs;
            double a1 = rot + Math.PI * 2 * (i + 1) / segs;
            double c0 = Math.cos(a0), s0 = Math.sin(a0), c1 = Math.cos(a1), s1 = Math.sin(a1);
            int c0rgb = paletteMode >= 0 ? color(paletteMode, hue + i / (float) segs * 0.22f)
                    : Draw.lerp(tint, bright, 0.16f + 0.22f * (float) (0.5 + 0.5 * Math.sin(a0)));
            int c1rgb = paletteMode >= 0 ? color(paletteMode, hue + (i + 1) / (float) segs * 0.22f)
                    : Draw.lerp(tint, bright, 0.16f + 0.22f * (float) (0.5 + 0.5 * Math.sin(a1)));

            // Faint tinted glass inside the rim.
            q(x, y, z, 0, 0, tint, alpha * 0.045f);
            q(x, y, z, Math.cos(a0) * inner, Math.sin(a0) * inner, c0rgb, alpha * 0.075f);
            q(x, y, z, Math.cos(a1) * inner, Math.sin(a1) * inner, c1rgb, alpha * 0.075f);
            q(x, y, z, 0, 0, tint, alpha * 0.045f);

            // Iridescent shell, bright at the inner edge and softly fading outward.
            q(x, y, z, c0 * inner, s0 * inner, c0rgb, alpha * 0.72f);
            q(x, y, z, c0 * outer, s0 * outer, c0rgb, alpha * 0.15f);
            q(x, y, z, c1 * outer, s1 * outer, c1rgb, alpha * 0.15f);
            q(x, y, z, c1 * inner, s1 * inner, c1rgb, alpha * 0.72f);
        }

        // A curved-looking glass glint: short strokes and a tiny soft white reflection.
        double ha = rot - 2.15;
        double hx = Math.cos(ha) * radius * 0.42;
        double hy = Math.sin(ha) * radius * 0.42;
        bar(x, y, z, hx - radius * 0.08, hy - radius * 0.11,
                hx + radius * 0.05, hy + radius * 0.09, radius * 0.075, 0xFFFFFF, alpha * 0.62f);
        double gx = rx * hx + ux * hy;
        double gy = ry * hx + uy * hy;
        double gz = rz * hx + uz * hy;
        glow(x + gx, y + gy, z + gz, radius * 0.085, 0xFFFFFF, alpha * 0.28f);
    }

    // ------------------------------------------------------------------ camera-facing sprite shapes

    /** One vertex at a point (px, py) in the camera plane around the world position (x, y, z). */
    private void q(double x, double y, double z, double px, double py, int rgb, float a) {
        v(x + rx * px + ux * py, y + ry * px + uy * py, z + rz * px + uz * py, rgb, a);
    }

    /** Thin camera-facing bar between two points of the camera plane. */
    private void bar(double x, double y, double z, double ax, double ay, double bx, double by,
                     double th, int rgb, float a) {
        double dx = bx - ax, dy = by - ay;
        double len = Math.sqrt(dx * dx + dy * dy);
        if (len < 1.0e-9) return;
        double nx = -dy / len * th * 0.5, ny = dx / len * th * 0.5;
        q(x, y, z, ax - nx, ay - ny, rgb, a);
        q(x, y, z, bx - nx, by - ny, rgb, a);
        q(x, y, z, bx + nx, by + ny, rgb, a);
        q(x, y, z, ax + nx, ay + ny, rgb, a);
    }

    /** Four-point sparkle: two long thin diamonds crossed at right angles. */
    public void sparkle(double x, double y, double z, double size, double rot, int rgb, float a) {
        double w = size * 0.17;
        for (int k = 0; k < 2; k++) {
            double ang = rot + k * Math.PI / 2;
            double c = Math.cos(ang), s = Math.sin(ang);
            q(x, y, z, c * size, s * size, rgb, a);
            q(x, y, z, -s * w, c * w, rgb, a);
            q(x, y, z, -c * size, -s * size, rgb, a);
            q(x, y, z, s * w, -c * w, rgb, a);
        }
    }

    /** Six-armed crystal snowflake with two pairs of side branches on every arm. */
    public void snowflake(double x, double y, double z, double size, double rot, int rgb, float a) {
        double th = Math.max(size * 0.11, 0.004);
        for (int k = 0; k < 6; k++) {
            double ang = rot + k * Math.PI / 3;
            double c = Math.cos(ang), s = Math.sin(ang);
            bar(x, y, z, c * size * 0.1, s * size * 0.1, c * size, s * size, th, rgb, a);
            double[] at = {0.46, 0.74};
            double[] len = {0.34, 0.22};
            for (int j = 0; j < 2; j++) {
                double bx = c * size * at[j], by = s * size * at[j];
                for (int side = -1; side <= 1; side += 2) {
                    double ba = ang + side * Math.PI / 3;
                    bar(x, y, z, bx, by, bx + Math.cos(ba) * size * len[j], by + Math.sin(ba) * size * len[j], th * 0.85, rgb, a);
                }
            }
        }
    }

    /** Filled heart. */
    public void heart(double x, double y, double z, double size, double rot, int rgb, float a) {
        int segs = 18;
        double cr = Math.cos(rot), sr = Math.sin(rot);
        for (int i = 0; i < segs; i++) {
            double t0 = Math.PI * 2 * i / segs, t1 = Math.PI * 2 * (i + 1) / segs;
            double[] p0 = heartPoint(t0), p1 = heartPoint(t1);
            q(x, y, z, (0.0 * cr - 0.05 * sr) * size, (0.0 * sr + 0.05 * cr) * size, rgb, a);
            q(x, y, z, (p0[0] * cr - p0[1] * sr) * size, (p0[0] * sr + p0[1] * cr) * size, rgb, a);
            q(x, y, z, (p1[0] * cr - p1[1] * sr) * size, (p1[0] * sr + p1[1] * cr) * size, rgb, a);
            q(x, y, z, (p1[0] * cr - p1[1] * sr) * size, (p1[0] * sr + p1[1] * cr) * size, rgb, a);
        }
    }

    private static double[] heartPoint(double t) {
        double s = Math.sin(t);
        double px = 16 * s * s * s / 17.0;
        double py = (13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)) / 17.0 + 0.05;
        return new double[]{px, py};
    }

    /** Axis-aligned box, all six faces. */
    public void box(double x0, double y0, double z0, double x1, double y1, double z1, int rgb, float a) {
        v(x0, y0, z0, rgb, a); v(x1, y0, z0, rgb, a); v(x1, y0, z1, rgb, a); v(x0, y0, z1, rgb, a); // bottom
        v(x0, y1, z0, rgb, a); v(x0, y1, z1, rgb, a); v(x1, y1, z1, rgb, a); v(x1, y1, z0, rgb, a); // top
        v(x0, y0, z0, rgb, a); v(x0, y1, z0, rgb, a); v(x1, y1, z0, rgb, a); v(x1, y0, z0, rgb, a); // north
        v(x0, y0, z1, rgb, a); v(x1, y0, z1, rgb, a); v(x1, y1, z1, rgb, a); v(x0, y1, z1, rgb, a); // south
        v(x0, y0, z0, rgb, a); v(x0, y0, z1, rgb, a); v(x0, y1, z1, rgb, a); v(x0, y1, z0, rgb, a); // west
        v(x1, y0, z0, rgb, a); v(x1, y1, z0, rgb, a); v(x1, y1, z1, rgb, a); v(x1, y0, z1, rgb, a); // east
    }

    /** Twelve thin edge bars around a box. */
    public void boxEdges(double x0, double y0, double z0, double x1, double y1, double z1,
                         double t, int mode, float a, float hue) {
        double h = t / 2;
        int i = 0;
        for (int yi = 0; yi < 2; yi++) {
            for (int zi = 0; zi < 2; zi++) {
                double y = yi == 0 ? y0 : y1, z = zi == 0 ? z0 : z1;
                box(x0 - h, y - h, z - h, x1 + h, y + h, z + h, color(mode, hue + i++ / 12f), a);
            }
        }
        for (int xi = 0; xi < 2; xi++) {
            for (int zi = 0; zi < 2; zi++) {
                double x = xi == 0 ? x0 : x1, z = zi == 0 ? z0 : z1;
                box(x - h, y0 - h, z - h, x + h, y1 + h, z + h, color(mode, hue + i++ / 12f), a);
            }
        }
        for (int xi = 0; xi < 2; xi++) {
            for (int yi = 0; yi < 2; yi++) {
                double x = xi == 0 ? x0 : x1, y = yi == 0 ? y0 : y1;
                box(x - h, y - h, z0 - h, x + h, y + h, z1 + h, color(mode, hue + i++ / 12f), a);
            }
        }
    }
}
