package dev.clith.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.clith.module.SkyModule;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix4f;

import java.util.Random;

/** Replaces the vanilla sky with a full CLITH sky dome and style-specific sky artwork. */
public final class ClithSkyRenderer {
    private static final java.util.Set<Identifier> SMOOTHED = new java.util.HashSet<>();
    private static final float DOME_RADIUS = 176.0f;
    private static final Identifier AURORA_TEXTURE = Identifier.of("clith", "textures/environment/aurora.png");
    private static final Identifier NEBULA_TEXTURE = Identifier.of("clith", "textures/environment/nebula.png");
    private static final Identifier END_BEAMS_TEXTURE = Identifier.of("clith", "textures/environment/end_beams.png");
    private static final Particle[] PLINTUS_PARTICLES = makeParticles(0xC117A, 920, false);
    private static final Particle[] GALAXY_PARTICLES = makeParticles(0x6A1A7, 1450, true);
    private static final Cloud[] CLOUDS = makeClouds();

    private ClithSkyRenderer() {}

    public static void init() {
        // Use BEFORE_ENTITIES and the always-available positionMatrix; matrixStack() is
        // null at this stage in Fabric API 1.21.4, which made the old renderer return early.
        WorldRenderEvents.BEFORE_ENTITIES.register(ClithSkyRenderer::render);
    }

    private static void render(WorldRenderContext context) {
        SkyModule sky = SkyModule.instance;
        if (sky == null || !sky.isEnabled() || !SkyModule.customSkyActive()) return;
        // positionMatrix() is valid at BEFORE_ENTITIES; context.matrixStack() is not.
        Matrix4f matrix = Gfx.vertexMatrix(context.positionMatrix());
        int mode = sky.mode.index();
        boolean animated = sky.animated.get();
        double seconds = System.nanoTime() / 1_000_000_000.0;
        float power = (float) sky.intensity.get();

        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false); // the sky is only a backdrop: never write into the world's depth buffer
        RenderSystem.disableCull();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        // Opaque sky dome replaces the vanilla background. It is centered at the view
        // origin because world-render vertices are camera-relative at this render stage.
        drawDome(matrix, mode);
        RenderSystem.depthMask(false);

        switch (mode) {
            case 0 -> { // Aurora — textured, broad flowing curtains, not a star-particle effect
                drawTexturedLayer(matrix, AURORA_TEXTURE, seconds, power, animated, 173.0f, 0.92f);
                drawAurora(matrix, seconds, power, animated);
                drawGalaxyStars(matrix, seconds, power * 0.35f, animated);
            }
            case 1 -> { // Nebula — organic cloud texture plus moving purple/blue gas sheets
                drawTexturedLayer(matrix, NEBULA_TEXTURE, seconds, power, animated, 172.8f, 0.95f);
                drawNebula(matrix, seconds, power, animated);
                drawGalaxyStars(matrix, seconds, power * 0.38f, animated);
            }
            case 2 -> { // End Beams — tall animated light columns around the horizon
                drawEndBeams(matrix, seconds, power, animated);
                drawGalaxyStars(matrix, seconds, power * 0.30f, animated);
            }
            case 3 -> { // Galaxy preset
                drawTexturedLayer(matrix, NEBULA_TEXTURE, seconds, power * 0.72f, animated, 173.0f, 0.72f);
                drawGalaxyNebula(matrix, seconds, power, animated);
                drawGalaxyStars(matrix, seconds, power, animated);
            }
            case 4 -> { // Angular warm Plintus-inspired preset
                drawAngularClouds(matrix);
                drawGoldenParticles(matrix, seconds, power, animated);
            }
            case SkyModule.METEORS -> {
                drawGalaxyStars(matrix, seconds, power * 0.9f, animated);
                drawMeteors(matrix, seconds, power, animated);
            }
            case SkyModule.WINTER -> drawWinter(matrix, seconds, power, animated);
            default -> { }
        }

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    /** Colour of the sky right at the horizon: the world fog is tinted with this so terrain melts into the sky. */
    public static int horizonColor(int mode) {
        int o = dev.clith.module.CustomFog.overrideColor();
        return o != -1 ? o : skyColorRaw(0.0f, mode);
    }

    /** Full-sphere opaque background. It completely replaces vanilla sun, moon and stars. */
    private static void drawDome(Matrix4f matrix, int mode) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        int latBands = dev.clith.module.Optimization.liteSky() ? 18 : 36;
        int longitudeSegments = dev.clith.module.Optimization.liteSky() ? 48 : 96;
        for (int lat = 0; lat < latBands; lat++) {
            double p0 = -Math.PI * 0.5 + Math.PI * lat / latBands;
            double p1 = -Math.PI * 0.5 + Math.PI * (lat + 1) / latBands;
            for (int lon = 0; lon < longitudeSegments; lon++) {
                double a0 = Math.PI * 2.0 * lon / longitudeSegments;
                double a1 = Math.PI * 2.0 * (lon + 1) / longitudeSegments;
                Vec v00 = sphere(a0, p0, DOME_RADIUS);
                Vec v10 = sphere(a1, p0, DOME_RADIUS);
                Vec v11 = sphere(a1, p1, DOME_RADIUS);
                Vec v01 = sphere(a0, p1, DOME_RADIUS);
                vertex(b, matrix, v00, skyColor((float) Math.sin(p0), mode), 1f);
                vertex(b, matrix, v10, skyColor((float) Math.sin(p0), mode), 1f);
                vertex(b, matrix, v11, skyColor((float) Math.sin(p1), mode), 1f);
                vertex(b, matrix, v01, skyColor((float) Math.sin(p1), mode), 1f);
            }
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    /**
     * Dome colour with a seamless horizon: everything from slightly above to well below the horizon line
     * is exactly the fog colour, so far terrain / sea fades into the sky with no visible edge.
     * If Custom Fog has its own colour, the sky blends from that colour into the artwork above.
     */
    private static int skyColor(float height, int mode) {
        height = MathHelper.clamp(height, -1f, 1f);
        int horizon = horizonColor(mode);
        int fogOverride = dev.clith.module.CustomFog.overrideColor();
        if (height <= 0f) {
            float k = MathHelper.clamp((-height - 0.30f) / 0.60f, 0f, 1f);
            k = k * k * (3f - 2f * k);
            return k <= 0f ? horizon : mix(horizon, skyColorRaw(height, mode), k);
        }
        int raw = skyColorRaw(height, mode);
        if (fogOverride == -1) return raw;
        float k = MathHelper.clamp(height / 0.40f, 0f, 1f);
        k = k * k * (3f - 2f * k);
        return mix(horizon, raw, k);
    }

    private static int skyColorRaw(float height, int mode) {
        height = MathHelper.clamp(height, -1f, 1f);
        if (mode == 0) { // Aurora: deep indigo to a cold blue horizon
            if (height < -0.12f) return mix(0x050915, 0x111A39, (height + 1f) / 0.88f);
            if (height < 0.28f) return mix(0x111A39, 0x171A42, (height + 0.12f) / 0.40f);
            return mix(0x171A42, 0x03040D, (height - 0.28f) / 0.72f);
        }
        if (mode == 1) { // Nebula
            if (height < -0.18f) return mix(0x070A18, 0x1C1035, (height + 1f) / 0.82f);
            if (height < 0.30f) return mix(0x1C1035, 0x241544, (height + 0.18f) / 0.48f);
            return mix(0x241544, 0x050611, (height - 0.30f) / 0.70f);
        }
        if (mode == 2) { // End beams
            if (height < -0.16f) return mix(0x040711, 0x141128, (height + 1f) / 0.84f);
            if (height < 0.25f) return mix(0x141128, 0x24143C, (height + 0.16f) / 0.41f);
            return mix(0x24143C, 0x04040C, (height - 0.25f) / 0.75f);
        }
        if (mode == 3) { // Galaxy
            if (height < -0.15f) return mix(0x100E19, 0x24152E, (height + 1f) / 0.85f);
            if (height < 0.42f) return mix(0x24152E, 0x302043, (height + 0.15f) / 0.57f);
            return mix(0x302043, 0x080A14, (height - 0.42f) / 0.58f);
        }
        if (mode == SkyModule.METEORS) { // Meteors
            if (height < -0.15f) return mix(0x04060F, 0x0A1228, (height + 1f) / 0.85f);
            if (height < 0.30f) return mix(0x0A1228, 0x142446, (height + 0.15f) / 0.45f);
            return mix(0x142446, 0x02030A, (height - 0.30f) / 0.70f);
        }
        if (mode == SkyModule.WINTER) { // Winter neon: frosty white horizon rising into a soft periwinkle zenith
            int c;
            if (height < -0.10f) c = mix(0xDCE8F8, 0xEEF6FF, (height + 1f) / 0.90f);
            else if (height < 0.22f) c = mix(0xEEF6FF, 0xC6D6F2, (height + 0.10f) / 0.32f);
            else if (height < 0.62f) c = mix(0xC6D6F2, 0x93A6D6, (height - 0.22f) / 0.40f);
            else c = mix(0x93A6D6, 0x6A7CB6, (height - 0.62f) / 0.38f);
            SkyModule sm = SkyModule.instance;
            return sm == null ? c : mix(c, sm.neon.rgb(), 0.16f);
        }
        // Plintus-inspired amber dusk
        if (height < -0.20f) return mix(0x282017, 0x6F4B25, (height + 1f) / 0.80f);
        if (height < 0.06f) return mix(0x6F4B25, 0xE9B854, (height + 0.20f) / 0.26f);
        if (height < 0.42f) return mix(0xE9B854, 0xA97532, (height - 0.06f) / 0.36f);
        return mix(0xA97532, 0x3A2918, (height - 0.42f) / 0.58f);
    }

    /** Dark, chunky cloud silhouettes positioned all around the horizon. */
    private static void drawAngularClouds(Matrix4f matrix) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (Cloud cloud : CLOUDS) {
            Vec dir = direction(cloud.yaw, cloud.pitch);
            Vec right = normalize(new Vec(dir.z, 0, -dir.x));
            Vec up = normalize(cross(dir, right));
            Vec center = scale(dir, 154.0f);
            float x = -cloud.width * 0.5f;
            for (int i = 0; i < cloud.pieces; i++) {
                float w = cloud.width / cloud.pieces * (0.76f + cloud.jitter[i] * 0.54f);
                float h = cloud.height * (0.60f + cloud.jitter[(i + 2) % cloud.jitter.length] * 0.80f);
                float y = (cloud.jitter[(i + 1) % cloud.jitter.length] - 0.5f) * cloud.height * 0.75f;
                int tone = (i % 4 == 0) ? 0x52412C : (i % 3 == 0 ? 0x443A2D : 0x393126);
                float alpha = 0.64f + cloud.jitter[(i + 3) % cloud.jitter.length] * 0.19f;
                tangentQuad(b, matrix, center, right, up, x + w * 0.5f, y, w, h, tone, alpha);
                // Low second row gives each cloud an uneven, blocky silhouette.
                if ((i + cloud.pieces) % 3 == 0) {
                    tangentQuad(b, matrix, center, right, up, x + w * 0.36f,
                            y - h * 0.48f, w * 0.72f, h * 0.46f, 0x30271D, alpha * 0.95f);
                }
                x += w * 0.83f;
            }
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    /** Fine golden fragments, diamonds and glow halos — never the vanilla white star field. */
    private static void drawGoldenParticles(Matrix4f matrix, double seconds, float power, boolean animated) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        // Tessellator's backing builder must not be begun twice before ending it.
        // Put halos and bright cores in the same batch to avoid an empty second end().
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        int particleCount = Math.min(PLINTUS_PARTICLES.length, Math.max(40, SkyModule.instance.stars.getInt() * (dev.clith.module.Optimization.liteSky() ? 1 : 2)));
        for (int particleIndex = 0; particleIndex < particleCount; particleIndex++) {
            Particle p = PLINTUS_PARTICLES[particleIndex];
            float twinkle = animated ? 0.60f + 0.40f * (float) Math.sin(seconds * p.speed + p.phase) : 1f;
            Vec dir = direction(p.yaw, p.pitch);
            Vec right = normalize(new Vec(dir.z, 0, -dir.x));
            if (length(right) < 0.001f) right = new Vec(1, 0, 0);
            Vec up = normalize(cross(dir, right));
            Vec center = scale(dir, 149.0f);
            float size = p.size * (animated ? 0.94f + 0.06f * (float) Math.sin(seconds * p.speed * 0.55 + p.phase) : 1f);
            float alpha = MathHelper.clamp(p.alpha * power * twinkle, 0f, 1f);
            if (p.large) {
                tangentDiamond(b, matrix, center, right, up, size * 2.9f, size * 2.1f, p.rotation, 0xFFB334, alpha * 0.11f);
                tangentDiamond(b, matrix, center, right, up, size * 1.8f, size * 1.4f, p.rotation, 0xFFD16A, alpha * 0.19f);
                tangentDiamond(b, matrix, center, right, up, size, size * 0.68f, p.rotation, p.color, alpha * 0.98f);
            } else {
                tangentDiamond(b, matrix, center, right, up, size, size * (p.kind == 0 ? 0.68f : 1.0f), p.rotation, p.color, alpha);
            }
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    private static void drawGalaxyNebula(Matrix4f matrix, double seconds, float power, boolean animated) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (int i = 0; i < 34; i++) {
            float yaw = (float) (i * 2.399963 + 0.20 * Math.sin(seconds * 0.035 + i));
            float pitch = -0.06f + 0.20f * (float) Math.sin(i * 1.47);
            Vec dir = direction(yaw, pitch);
            Vec right = normalize(new Vec(dir.z, 0, -dir.x));
            Vec up = normalize(cross(dir, right));
            Vec center = scale(dir, 153.0f);
            float size = 4.0f + (i % 5) * 1.6f;
            float flicker = animated ? 0.70f + 0.30f * (float) Math.sin(seconds * 0.22 + i) : 1f;
            int color = i % 3 == 0 ? 0xA26BFF : (i % 3 == 1 ? 0x6856C9 : 0xC276E8);
            tangentQuad(b, matrix, center, right, up, 0, 0, size * 2.5f, size * 0.65f, color, 0.10f * power * flicker);
            tangentQuad(b, matrix, center, right, up, 0, 0, size, size * 0.32f, color, 0.15f * power * flicker);
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    private static void drawGalaxyStars(Matrix4f matrix, double seconds, float power, boolean animated) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        // Use one Tessellator batch. Ending two references to the same backing builder
        // caused "BufferBuilder was empty" in the previous implementation.
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        int particleCount = Math.min(GALAXY_PARTICLES.length, Math.max(40, SkyModule.instance.stars.getInt() / (dev.clith.module.Optimization.liteSky() ? 2 : 1)));
        for (int particleIndex = 0; particleIndex < particleCount; particleIndex++) {
            Particle p = GALAXY_PARTICLES[particleIndex];
            Vec dir = direction(p.yaw, p.pitch);
            Vec right = normalize(new Vec(dir.z, 0, -dir.x));
            if (length(right) < 0.001f) right = new Vec(1, 0, 0);
            Vec up = normalize(cross(dir, right));
            Vec center = scale(dir, 148.0f);
            float twinkle = animated ? 0.24f + 0.76f * (0.5f + 0.5f * (float) Math.sin(seconds * p.speed + p.phase)) : 1f;
            float size = p.size * 0.65f;
            float alpha = MathHelper.clamp(p.alpha * power * twinkle, 0f, 1f);
            if (p.large) tangentDiamond(b, matrix, center, right, up, size * 3f, size * 3f, p.rotation, p.color, alpha * 0.10f);
            tangentDiamond(b, matrix, center, right, up, size, size, p.rotation, p.color, alpha);
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    /** Draws a seamless equirectangular atmospheric texture over the sky sphere. */
    private static void drawTexturedLayer(Matrix4f matrix, Identifier texture, double seconds,
                                          float power, boolean animated, float radius, float opacity) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, texture);
        // Smooth filtering for these gradient textures. It is set ON THE TEXTURE OBJECT, once.
        // (Raw glTexParameter calls here hit whatever texture was bound last - the block atlas -
        // and made every block texture blurry.)
        if (SMOOTHED.add(texture)) {
            MinecraftClient.getInstance().getTextureManager().getTexture(texture).setFilter(true, false);
        }
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        int latBands = dev.clith.module.Optimization.liteSky() ? 20 : 40;
        int longitudeSegments = dev.clith.module.Optimization.liteSky() ? 60 : 120;
        float yawDrift = animated ? (float) (seconds * 0.022) : 0f;
        float alpha = MathHelper.clamp(power, 0f, 1f) * opacity;
        for (int lat = 0; lat < latBands; lat++) {
            double p0 = -Math.PI * 0.5 + Math.PI * lat / latBands;
            double p1 = -Math.PI * 0.5 + Math.PI * (lat + 1) / latBands;
            float v0 = (float) (0.5 - p0 / Math.PI);
            float v1 = (float) (0.5 - p1 / Math.PI);
            for (int lon = 0; lon < longitudeSegments; lon++) {
                double a0 = Math.PI * 2.0 * lon / longitudeSegments + yawDrift;
                double a1 = Math.PI * 2.0 * (lon + 1) / longitudeSegments + yawDrift;
                float u0 = lon / (float) longitudeSegments;
                float u1 = (lon + 1) / (float) longitudeSegments;
                texturedVertex(b, matrix, sphere(a0, p0, radius), u0, v0, alpha);
                texturedVertex(b, matrix, sphere(a1, p0, radius), u1, v0, alpha);
                texturedVertex(b, matrix, sphere(a1, p1, radius), u1, v1, alpha);
                texturedVertex(b, matrix, sphere(a0, p1, radius), u0, v1, alpha);
            }
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
        // Leave the shader state clean for the following color-only sky meshes.
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
    }

    private static void texturedVertex(BufferBuilder b, Matrix4f matrix, Vec p,
                                       float u, float v, float alpha) {
        b.vertex(matrix, p.x, p.y, p.z).texture(u, v).color(1f, 1f, 1f, alpha);
    }

    /**
     * Aurora curtains: continuous curved meshes with layered translucent glow.
     * Their edges ripple and travel continuously, so the sky itself is animated;
     * these are not Minecraft particles or a blinking overlay.
     */
    private static void drawAurora(Matrix4f matrix, double seconds, float power, boolean animated) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        int ribbons = 8;
        for (int i = 0; i < ribbons; i++) {
            float phase = i * 1.731f;
            float yaw = (float) (Math.PI * 2.0 * i / ribbons
                    + (animated ? Math.sin(seconds * 0.10 + i * 0.81) * 0.095 : 0));
            float width = 0.80f + (i % 3) * 0.13f;
            float bottom = 0.04f + (i % 4) * 0.045f;
            float height = 0.86f + (i % 3) * 0.12f;
            int[] glow = {0x142D86, 0x176EAF, 0x16C7B4, 0x5148BB};
            int[] bright = {0x264DCC, 0x15B7DF, 0x27F0BB, 0x9472FF};
            appendCurtain(b, matrix, seconds, animated, yaw, width * 1.75f, bottom - 0.035f,
                    height + 0.13f, phase, 172f, power * 0.11f, glow, 32, 10, 0.20f);
            appendCurtain(b, matrix, seconds, animated, yaw, width, bottom,
                    height, phase, 170f, power * 0.44f, bright, 36, 12, 0.125f);
            // Thin luminous ridges make the curtains feel layered rather than flat.
            if (i % 2 == 0) {
                appendCurtain(b, matrix, seconds, animated, yaw + 0.07f, width * 0.27f,
                        bottom + 0.05f, height * 0.91f, phase + 1.2f, 168.4f,
                        power * 0.25f, new int[]{0x3B74FF, 0x59FFD5, 0xBE8CFF}, 32, 10, 0.045f);
            }
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    /** Broad, irregular gas clouds made from flowing translucent sheets. */
    private static void drawNebula(Matrix4f matrix, double seconds, float power, boolean animated) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        int[][] palettes = {
                {0x2225A0, 0x6940D8, 0xC14DBD, 0xE7A1F9},
                {0x103B9C, 0x365DDF, 0xA14BE8, 0xF49AE7},
                {0x174F9B, 0x3D4FBB, 0x7852D1, 0x42D7D8},
                {0x351A83, 0x8D37C8, 0xCF5DBA, 0x8176F8},
                {0x14216B, 0x3851C1, 0x7B61E7, 0xD181EF}
        };
        for (int layer = 0; layer < palettes.length; layer++) {
            float phase = layer * 1.37f;
            float centerYaw = (float) (layer * 2.399963 + (animated ? seconds * (layer % 2 == 0 ? 0.012 : -0.009) : 0));
            appendNebulaSheet(b, matrix, seconds, animated, centerYaw, phase,
                    167.8f - layer * 0.45f, power * (0.31f - layer * 0.025f), palettes[layer],
                    88, 10, 0.15f + (layer % 3) * 0.035f);
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    /** Tall, narrow moving light columns that rise from the horizon into the sky. */
    private static void drawEndBeams(Matrix4f matrix, double seconds, float power, boolean animated) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        int count = 18;
        int[][] palettes = {
                {0x222A9B, 0x6250F0, 0xAD9BFF},
                {0x16469F, 0x35B9F4, 0xD2F9FF},
                {0x4B238E, 0xB04DF4, 0xF0BCFF},
                {0x163E8C, 0x51D2DE, 0xB6FFF4}
        };
        for (int i = 0; i < count; i++) {
            float phase = i * 2.173f;
            float yaw = (float) (Math.PI * 2.0 * i / count
                    + (animated ? Math.sin(seconds * 0.22 + phase) * 0.026 : 0));
            float width = 0.018f + (i % 4) * 0.007f;
            float bottom = -0.02f + (i % 5) * 0.035f;
            float height = 0.65f + (i % 6) * 0.105f;
            int[] palette = palettes[i % palettes.length];
            appendCurtain(b, matrix, seconds, animated, yaw, width * 9.0f, bottom,
                    height * 1.05f, phase, 172f, power * 0.10f, palette, 12, 12, 0.18f);
            appendCurtain(b, matrix, seconds, animated, yaw, width * 2.7f, bottom,
                    height, phase, 169.8f, power * 0.32f, palette, 12, 12, 0.075f);
            if (i % 2 == 0) {
                appendCurtain(b, matrix, seconds, animated, yaw, width * 0.85f,
                        bottom + 0.035f, height * 0.84f, phase + 1.5f, 168.2f,
                        power * 0.50f, new int[]{0x7774FF, 0xB0E9FF, 0xF6E6FF}, 12, 12, 0.035f);
            }
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    /** Appends one undulating curtain strip into a shared vertex buffer. */
    private static void appendCurtain(BufferBuilder b, Matrix4f matrix, double seconds, boolean animated,
                                      float centerYaw, float widthYaw, float bottomPitch, float heightPitch,
                                      float phase, float radius, float strength, int[] palette,
                                      int segments, int rows, float waveAmplitude) {
        for (int x = 0; x < segments; x++) {
            float u0 = x / (float) segments;
            float u1 = (x + 1) / (float) segments;
            float yaw0 = centerYaw + (u0 - 0.5f) * widthYaw;
            float yaw1 = centerYaw + (u1 - 0.5f) * widthYaw;
            float edge0 = (float) Math.pow(Math.max(0, Math.sin(Math.PI * u0)), 0.65);
            float edge1 = (float) Math.pow(Math.max(0, Math.sin(Math.PI * u1)), 0.65);
            for (int y = 0; y < rows; y++) {
                float v0 = y / (float) rows;
                float v1 = (y + 1) / (float) rows;
                float wave00 = curtainWave(u0, v0, phase, seconds, animated, waveAmplitude);
                float wave10 = curtainWave(u1, v0, phase, seconds, animated, waveAmplitude);
                float wave11 = curtainWave(u1, v1, phase, seconds, animated, waveAmplitude);
                float wave01 = curtainWave(u0, v1, phase, seconds, animated, waveAmplitude);
                float p00 = bottomPitch + heightPitch * v0 + wave00;
                float p10 = bottomPitch + heightPitch * v0 + wave10;
                float p11 = bottomPitch + heightPitch * v1 + wave11;
                float p01 = bottomPitch + heightPitch * v1 + wave01;
                float a00 = strength * edge0 * curtainVerticalFade(v0) * curtainFlicker(u0, phase, seconds, animated);
                float a10 = strength * edge1 * curtainVerticalFade(v0) * curtainFlicker(u1, phase, seconds, animated);
                float a11 = strength * edge1 * curtainVerticalFade(v1) * curtainFlicker(u1, phase, seconds, animated);
                float a01 = strength * edge0 * curtainVerticalFade(v1) * curtainFlicker(u0, phase, seconds, animated);
                int c0 = gradient(palette, v0), c1 = gradient(palette, v1);
                vertex(b, matrix, sphere(yaw0, p00, radius), c0, a00);
                vertex(b, matrix, sphere(yaw1, p10, radius), c0, a10);
                vertex(b, matrix, sphere(yaw1, p11, radius), c1, a11);
                vertex(b, matrix, sphere(yaw0, p01, radius), c1, a01);
            }
        }
    }

    private static float curtainWave(float u, float v, float phase, double seconds,
                                     boolean animated, float amplitude) {
        if (!animated) return 0f;
        float t = (float) seconds;
        float a = (float) Math.sin(u * 10.5f + phase + t * 0.42f);
        float b = (float) Math.sin(u * 22f - phase * 1.7f - t * 0.26f + v * 3.5f);
        float c = (float) Math.sin(u * 4.1f + phase * 0.7f + t * 0.13f);
        return amplitude * (a * (0.55f + v * 0.45f) + b * 0.23f + c * 0.32f);
    }

    private static float curtainVerticalFade(float v) {
        float softBottom = MathHelper.clamp(v * 4.4f, 0f, 1f);
        float softTop = MathHelper.clamp((1f - v) * 3.5f, 0f, 1f);
        float belly = 0.38f + 0.62f * (float) Math.sin(Math.PI * v);
        return softBottom * softTop * belly;
    }

    private static float curtainFlicker(float u, float phase, double seconds, boolean animated) {
        if (!animated) return 1f;
        return 0.80f + 0.20f * (float) Math.sin(u * 8.0f + phase + seconds * 0.35);
    }

    /** A full-width undulating nebula sheet with noisy, softly faded edges. */
    private static void appendNebulaSheet(BufferBuilder b, Matrix4f matrix, double seconds,
                                          boolean animated, float yawOffset, float phase, float radius, float strength,
                                          int[] palette, int segments, int rows, float baseWidth) {
        for (int x = 0; x < segments; x++) {
            float u0 = x / (float) segments;
            float u1 = (x + 1) / (float) segments;
            float yaw0 = (float) (u0 * Math.PI * 2.0 + yawOffset);
            float yaw1 = (float) (u1 * Math.PI * 2.0 + yawOffset);
            for (int y = 0; y < rows; y++) {
                float v0 = y / (float) rows;
                float v1 = (y + 1) / (float) rows;
                float center0 = nebulaCenter(u0, phase, seconds, animated);
                float center1 = nebulaCenter(u1, phase, seconds, animated);
                float width0 = baseWidth * (0.48f + 0.52f * Math.abs((float) Math.sin(u0 * 14.0f + phase * 2.0f)));
                float width1 = baseWidth * (0.48f + 0.52f * Math.abs((float) Math.sin(u1 * 14.0f + phase * 2.0f)));
                float p00 = center0 + (v0 - 0.5f) * width0;
                float p10 = center1 + (v0 - 0.5f) * width1;
                float p11 = center1 + (v1 - 0.5f) * width1;
                float p01 = center0 + (v1 - 0.5f) * width0;
                float edge0 = (float) Math.pow(Math.max(0, Math.sin(Math.PI * v0)), 0.62);
                float edge1 = (float) Math.pow(Math.max(0, Math.sin(Math.PI * v1)), 0.62);
                float movement0 = animated ? 0.82f + 0.18f * (float) Math.sin(u0 * 23 + phase + seconds * 0.28) : 1f;
                float movement1 = animated ? 0.82f + 0.18f * (float) Math.sin(u1 * 23 + phase + seconds * 0.28) : 1f;
                int c0 = gradient(palette, v0), c1 = gradient(palette, v1);
                vertex(b, matrix, sphere(yaw0, p00, radius), c0, strength * edge0 * movement0);
                vertex(b, matrix, sphere(yaw1, p10, radius), c0, strength * edge0 * movement1);
                vertex(b, matrix, sphere(yaw1, p11, radius), c1, strength * edge1 * movement1);
                vertex(b, matrix, sphere(yaw0, p01, radius), c1, strength * edge1 * movement0);
            }
        }
    }

    private static float nebulaCenter(float u, float phase, double seconds, boolean animated) {
        float t = animated ? (float) seconds : 0f;
        return 0.18f
                + 0.14f * (float) Math.sin(u * 6.2f + phase + t * 0.07f)
                + 0.075f * (float) Math.sin(u * 15.8f - phase * 1.6f - t * 0.11f)
                + 0.035f * (float) Math.sin(u * 31f + phase * 0.7f + t * 0.16f);
    }

    private static int gradient(int[] colors, float t) {
        if (colors.length == 1) return colors[0];
        t = MathHelper.clamp(t, 0f, 1f) * (colors.length - 1);
        int i = Math.min(colors.length - 2, (int) t);
        return mix(colors[i], colors[i + 1], t - i);
    }

    private static void tangentQuad(BufferBuilder b, Matrix4f m, Vec center, Vec right, Vec up,
                                    float offsetX, float offsetY, float width, float height, int rgb, float alpha) {
        Vec c = add(center, add(scale(right, offsetX), scale(up, offsetY)));
        Vec rx = scale(right, width * 0.5f), uy = scale(up, height * 0.5f);
        vertex(b, m, add(add(c, scale(rx, -1)), scale(uy, -1)), rgb, alpha);
        vertex(b, m, add(c, add(scale(rx, -1), uy)), rgb, alpha);
        vertex(b, m, add(c, add(rx, uy)), rgb, alpha);
        vertex(b, m, add(c, add(rx, scale(uy, -1))), rgb, alpha);
    }

    private static void tangentDiamond(BufferBuilder b, Matrix4f m, Vec center, Vec right, Vec up,
                                       float width, float height, float rotation, int rgb, float alpha) {
        float c = (float) Math.cos(rotation), s = (float) Math.sin(rotation);
        Vec r = add(scale(right, c), scale(up, s));
        Vec u = add(scale(up, c), scale(right, -s));
        Vec rx = scale(r, width * 0.5f), uy = scale(u, height * 0.5f);
        Vec top = add(center, uy), rightPoint = add(center, rx), bottom = add(center, scale(uy, -1)), left = add(center, scale(rx, -1));
        vertex(b, m, top, rgb, alpha);
        vertex(b, m, left, rgb, alpha);
        vertex(b, m, bottom, rgb, alpha);
        vertex(b, m, rightPoint, rgb, alpha);
    }

    private static void vertex(BufferBuilder b, Matrix4f m, Vec p, int rgb, float alpha) {
        float a = MathHelper.clamp(alpha, 0f, 1f);
        float r = ((rgb >> 16) & 255) / 255f;
        float g = ((rgb >> 8) & 255) / 255f;
        float bl = (rgb & 255) / 255f;
        b.vertex(m, p.x, p.y, p.z).color(r, g, bl, a);
    }

    private static Vec sphere(double yaw, double pitch, float radius) {
        return scale(direction(yaw, pitch), radius);
    }

    private static Vec direction(double yaw, double pitch) {
        float cp = (float) Math.cos(pitch);
        return new Vec((float) (Math.sin(yaw) * cp), (float) Math.sin(pitch), (float) (Math.cos(yaw) * cp));
    }

    private static Particle[] makeParticles(long seed, int count, boolean galaxy) {
        Random random = new Random(seed);
        Particle[] items = new Particle[count];
        for (int i = 0; i < count; i++) {
            float yaw = random.nextFloat() * (float) (Math.PI * 2.0);
            float pitch;
            if (galaxy) {
                pitch = (random.nextFloat() * 2f - 1f) * 1.20f;
            } else {
                // The golden flecks are spread from the horizon into the upper dome,
                // like the warm, floating light pieces in the Plintus screenshots.
                pitch = -0.07f + random.nextFloat() * 0.96f;
            }
            boolean large = random.nextFloat() < (galaxy ? 0.07f : 0.14f);
            float size = galaxy ? (large ? 0.45f + random.nextFloat() * 0.95f : 0.12f + random.nextFloat() * 0.32f)
                    : (large ? 0.75f + random.nextFloat() * 1.45f : 0.16f + random.nextFloat() * 0.70f);
            float alpha = large ? 0.70f + random.nextFloat() * 0.30f : 0.25f + random.nextFloat() * 0.68f;
            int[] colors = galaxy
                    ? new int[]{0xF4E9FF, 0xC5A1FF, 0x9FBCFF, 0xE0C7FF}
                    : new int[]{0xFFCF56, 0xFFC144, 0xF8A92F, 0xFFE79A, 0xE99A27};
            items[i] = new Particle(yaw, pitch, size, alpha, 0.3f + random.nextFloat() * 1.9f,
                    random.nextFloat() * 6.28f, random.nextFloat() * 3.14f,
                    colors[random.nextInt(colors.length)], large, random.nextInt(2));
        }
        return items;
    }

    private static Cloud[] makeClouds() {
        Random random = new Random(0xC10D5);
        Cloud[] clouds = new Cloud[46];
        for (int i = 0; i < clouds.length; i++) {
            int pieces = 4 + random.nextInt(5);
            float[] jitter = new float[pieces + 4];
            for (int j = 0; j < jitter.length; j++) jitter[j] = random.nextFloat();
            clouds[i] = new Cloud(random.nextFloat() * (float) (Math.PI * 2.0),
                    -0.03f + random.nextFloat() * 0.36f,
                    8.0f + random.nextFloat() * 15.0f,
                    1.4f + random.nextFloat() * 3.7f,
                    pieces, jitter);
        }
        return clouds;
    }


    // ================================================================ extra animated skies (modes 9-12)

    /** Starts a batch that is never empty, so end() cannot throw on a frame where nothing is visible. */
    private static BufferBuilder beginBatch() {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        tangentQuad(b, new Matrix4f(), new Vec(0, 100, 0), new Vec(1, 0, 0), new Vec(0, 0, 1), 0, 0, 0.01f, 0.01f, 0, 0f);
        return b;
    }

    private static Vec rightOf(Vec dir) { return normalize(new Vec(dir.z, 0, -dir.x)); }
    private static Vec upOf(Vec dir, Vec right) { return normalize(cross(dir, right)); }

    /** Meteors: shooting stars with glowing tails crossing a deep blue night. */
    private static void drawMeteors(Matrix4f matrix, double seconds, float power, boolean animated) {
        BufferBuilder b = beginBatch();
        if (animated) {
            for (int i = 0; i < 9; i++) {
                double period = 3.2 + (i * 1.37) % 3.1;
                double cyc = seconds / period + i * 0.211;
                double u = cyc - Math.floor(cyc);
                if (u > 0.2) continue;
                float v = (float) (u / 0.2);
                long idx = (long) Math.floor(cyc);
                float seed = (float) (((idx * 7919L + i * 104729L) & 1023L) / 1023.0);
                float yaw0 = seed * 6.2832f;
                float pitch0 = 0.45f + ((seed * 13.7f) % 1f) * 0.75f;
                float dyaw = (seed > 0.5f ? 1f : -1f) * (0.35f + ((seed * 7.3f) % 1f) * 0.3f);
                float dpitch = -0.30f - ((seed * 3.1f) % 1f) * 0.2f;
                float fade = (float) Math.sin(v * Math.PI);
                for (int s = 0; s < 14; s++) {
                    float k = s / 14f;
                    float vv = Math.max(0f, v - k * 0.18f);
                    Vec dir = direction(yaw0 + dyaw * vv, pitch0 + dpitch * vv);
                    Vec r = rightOf(dir), up = upOf(dir, r);
                    float a = (1f - k) * (1f - k) * fade * power;
                    float size = 1.9f * (1f - k * 0.65f);
                    int col = s == 0 ? 0xFFFFFF : mix(0xE8F4FF, 0x6FA8FF, k);
                    Vec c = scale(dir, 147f);
                    tangentDiamond(b, matrix, c, r, up, size, size, 0.785f, col, a);
                    if (s < 3) tangentDiamond(b, matrix, c, r, up, size * 3.2f, size * 3.2f, 0.785f, 0x9CC8FF, a * 0.15f);
                }
            }
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    // ================================================================ Winter neon sky

    private record Puff(float ox, float oy, float r, float tone) {}
    private record WCloud(float yaw, float pitch, float drift, Puff[] puffs) {}
    private record Flake(float yaw, float pitch, float size, float spin, float phase, float speed, float bob) {}

    private static final WCloud[] WCLOUDS = makeWinterClouds();
    private static final Flake[] FLAKES = makeFlakes();
    private static final Particle[] SPARKS = makeSparks();

    /**
     * Winter neon: a frosty white sky with an iridescent colour shimmer, fluffy clouds, long glowing
     * swirls, drifting crystal snowflakes, frost mandala patterns and twinkling four-point stars.
     * Everything is tinted by the "Цвет неона" palette.
     */
    private static void drawWinter(Matrix4f m, double t, float power, boolean animated) {
        SkyModule sky = SkyModule.instance;
        drawWinterShimmer(m, t, power, animated);
        drawWinterSparks(m, t, power, animated);
        if (sky.patterns.get()) drawWinterPatterns(m, t, power, animated);
        drawWinterLight(m, t, power, animated);
        drawWinterClouds(m, t, power, animated);
        drawWinterSwirls(m, t, power, animated);
        if (sky.snow.get()) drawWinterFlakes(m, t, power, animated);
    }

    /** Oil-slick style colour wash over the whole dome that slowly drifts through the neon palette. */
    private static void drawWinterShimmer(Matrix4f m, double t, float power, boolean animated) {
        SkyModule sky = SkyModule.instance;
        BufferBuilder b = beginBatch();
        boolean lite = dev.clith.module.Optimization.liteSky();
        int lat = lite ? 14 : 26, lon = lite ? 36 : 72;
        double tt = animated ? t : 0.0;
        double pMin = -0.10, pMax = Math.PI * 0.5;
        for (int i = 0; i < lat; i++) {
            double p0 = pMin + (pMax - pMin) * i / lat, p1 = pMin + (pMax - pMin) * (i + 1) / lat;
            for (int j = 0; j < lon; j++) {
                double a0 = Math.PI * 2 * j / lon, a1 = Math.PI * 2 * (j + 1) / lon;
                shimmerVertex(b, m, sky, a0, p0, tt, power);
                shimmerVertex(b, m, sky, a1, p0, tt, power);
                shimmerVertex(b, m, sky, a1, p1, tt, power);
                shimmerVertex(b, m, sky, a0, p1, tt, power);
            }
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    private static void shimmerVertex(BufferBuilder b, Matrix4f m, SkyModule sky, double yaw, double pitch, double t, float power) {
        float k = (float) (yaw / (Math.PI * 2) * 2.0 + pitch * 0.9 + t * 0.018);
        int col = sky.neonColor(k, t, 1.25f, 1f);
        float wave = 0.5f + 0.5f * (float) Math.sin(yaw * 3.0 + pitch * 4.2 - t * 0.22);
        float wave2 = 0.5f + 0.5f * (float) Math.sin(yaw * 5.0 - pitch * 2.0 + t * 0.15);
        float v = (float) ((pitch + 0.10) / (Math.PI * 0.5 + 0.10));
        float env = (float) Math.pow(Math.sin(Math.PI * MathHelper.clamp(v, 0f, 1f)), 0.55);
        float a = power * (0.07f + 0.17f * wave * (0.5f + 0.5f * wave2)) * env;
        vertex(b, m, sphere(yaw, pitch, 174.5f), col, a);
    }

    // ------------------------------------------------------------ fluffy clouds

    private static WCloud[] makeWinterClouds() {
        Random r = new Random(0x57A7E);
        WCloud[] out = new WCloud[26];
        for (int i = 0; i < out.length; i++) {
            float pitch = -0.02f + (float) Math.pow(r.nextFloat(), 1.7) * 0.85f;
            float width = (0.10f + r.nextFloat() * 0.20f) * 150f;
            int n = 7 + r.nextInt(5);
            Puff[] puffs = new Puff[n];
            for (int j = 0; j < n; j++) {
                float u = ((j + 0.5f) / n) * 2f - 1f + (r.nextFloat() - 0.5f) * 0.18f;
                float radius = width * (0.15f + 0.11f * r.nextFloat()) * (1f - 0.42f * Math.abs(u));
                float oy = width * 0.20f * (0.30f + 0.70f * (1f - u * u)) * (0.55f + 0.45f * r.nextFloat());
                puffs[j] = new Puff(u * width * 0.5f, oy, radius, r.nextFloat());
            }
            out[i] = new WCloud(r.nextFloat() * (float) (Math.PI * 2), pitch, 0.0035f + r.nextFloat() * 0.0065f, puffs);
        }
        return out;
    }

    private static void drawWinterClouds(Matrix4f m, double t, float power, boolean animated) {
        SkyModule sky = SkyModule.instance;
        BufferBuilder b = beginBatch();
        int count = dev.clith.module.Optimization.liteSky() ? 14 : WCLOUDS.length;
        for (int i = 0; i < count; i++) {
            WCloud c = WCLOUDS[i];
            double yaw = c.yaw + (animated ? t * c.drift : 0.0);
            float pitch = c.pitch + (animated ? 0.012f * (float) Math.sin(t * 0.07 + i) : 0f);
            Vec dir = direction(yaw, pitch);
            Vec r = rightOf(dir), u = upOf(dir, r);
            Vec cen = scale(dir, 150f);
            int rim = sky.neonColor(i * 0.21f, t, 1.1f, 1f);
            for (Puff p : c.puffs) { // cool blue-grey underside
                softDisc(b, m, cen, r, u, p.ox, p.oy - p.r * 0.38f, p.r * 1.05f, 0x8798C8, 0.36f * power, 0f, 8);
            }
            for (Puff p : c.puffs) { // white body with a soft edge
                softDisc(b, m, cen, r, u, p.ox, p.oy, p.r, mix(0xDDE7FA, 0xFFFFFF, p.tone), 0.66f * power, 0.10f * power, 8);
            }
            for (Puff p : c.puffs) { // sunlit top and neon rim light
                softDisc(b, m, cen, r, u, p.ox - p.r * 0.14f, p.oy + p.r * 0.32f, p.r * 0.62f, 0xFFFFFF, 0.55f * power, 0f, 8);
                softDisc(b, m, cen, r, u, p.ox, p.oy, p.r * 1.4f, rim, 0.12f * power, 0f, 8);
            }
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    // ------------------------------------------------------------ swirling light ribbons

    private static void drawWinterSwirls(Matrix4f m, double t, float power, boolean animated) {
        SkyModule sky = SkyModule.instance;
        BufferBuilder b = beginBatch();
        int ribbons = 6;
        int segs = dev.clith.module.Optimization.liteSky() ? 40 : 72;
        float[] yaw = new float[segs + 1], pit = new float[segs + 1], wid = new float[segs + 1];
        float[] nYaw = new float[segs + 1], nPit = new float[segs + 1];
        float[] layerWidth = {3.6f, 1.5f, 0.5f};
        float[] layerAlpha = {0.12f, 0.30f, 0.95f};
        for (int i = 0; i < ribbons; i++) {
            float ph = i * 1.913f;
            float y0 = i * 1.0472f + 0.4f + (animated ? 0.12f * (float) Math.sin(t * 0.07 + ph) : 0f);
            float p0 = 0.12f + (i % 3) * 0.17f;
            float amp = 0.20f + (i % 2) * 0.08f;
            float span = 2.2f + (i % 3) * 0.5f;
            float wBase = 0.010f + (i % 3) * 0.004f;
            float flow = animated ? (float) (t * 0.12) : 0f;
            float tilt = (i % 2 == 0 ? 1f : -1f) * 0.18f;
            for (int s = 0; s <= segs; s++) {
                float u = s / (float) segs;
                yaw[s] = y0 + (u - 0.5f) * span;
                pit[s] = MathHelper.clamp(p0 + amp * (float) Math.sin(u * 7.854f + ph + flow) + tilt * (u - 0.5f), 0.01f, 1.45f);
                wid[s] = wBase * (float) Math.pow(Math.max(0.0, Math.sin(Math.PI * u)), 0.8)
                        * (0.75f + 0.25f * (float) Math.sin(u * 9f + ph - t * 0.6));
            }
            for (int s = 0; s <= segs; s++) {
                int s0 = Math.max(0, s - 1), s1 = Math.min(segs, s + 1);
                float cp = (float) Math.cos(pit[s]);
                float dy = (yaw[s1] - yaw[s0]) * cp, dp = pit[s1] - pit[s0];
                float len = (float) Math.sqrt(dy * dy + dp * dp);
                if (len < 1.0e-6f) len = 1f;
                nYaw[s] = -dp / len / Math.max(0.2f, cp);
                nPit[s] = dy / len;
            }
            for (int layer = 0; layer < 3; layer++) {
                float radius = 160f - layer * 0.25f;
                for (int s = 0; s < segs; s++) {
                    for (int side = -1; side <= 1; side += 2) {
                        // two soft strips per layer: transparent edge -> bright centre line
                        float u0 = s / (float) segs, u1 = (s + 1) / (float) segs;
                        float a0 = ribbonAlpha(u0, ph, t, animated, layerAlpha[layer], power);
                        float a1 = ribbonAlpha(u1, ph, t, animated, layerAlpha[layer], power);
                        int c0 = ribbonColor(sky, layer, i, u0, t), c1 = ribbonColor(sky, layer, i, u1, t);
                        float w0 = wid[s] * layerWidth[layer], w1 = wid[s + 1] * layerWidth[layer];
                        vertex(b, m, sphere(yaw[s] + nYaw[s] * w0 * side, pit[s] + nPit[s] * w0 * side, radius), c0, 0f);
                        vertex(b, m, sphere(yaw[s + 1] + nYaw[s + 1] * w1 * side, pit[s + 1] + nPit[s + 1] * w1 * side, radius), c1, 0f);
                        vertex(b, m, sphere(yaw[s + 1], pit[s + 1], radius), c1, a1);
                        vertex(b, m, sphere(yaw[s], pit[s], radius), c0, a0);
                    }
                }
            }
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    private static float ribbonAlpha(float u, float ph, double t, boolean animated, float base, float power) {
        float ends = (float) Math.pow(Math.max(0.0, Math.sin(Math.PI * u)), 0.6);
        float pulse = animated ? 0.55f + 0.45f * (float) Math.sin(u * 11f - t * 1.3 + ph) : 1f;
        return base * power * ends * pulse;
    }

    private static int ribbonColor(SkyModule sky, int layer, int i, float u, double t) {
        int neon = sky.neonColor(i * 0.2f + u * 0.6f, t, layer == 0 ? 1.5f : 1.0f, 1f);
        return layer == 2 ? mix(0xFFFFFF, neon, 0.2f) : mix(neon, 0xFFFFFF, layer == 1 ? 0.35f : 0.1f);
    }

    // ------------------------------------------------------------ snowflakes, stars, light

    private static Flake[] makeFlakes() {
        Random r = new Random(0xF1A4E);
        Flake[] out = new Flake[90];
        for (int i = 0; i < out.length; i++) {
            out[i] = new Flake(r.nextFloat() * (float) (Math.PI * 2), -0.02f + r.nextFloat() * 1.25f,
                    1.6f + (float) Math.pow(r.nextFloat(), 1.6) * 5.2f,
                    (r.nextFloat() - 0.5f) * 0.5f, r.nextFloat() * 6.2832f,
                    0.0015f + r.nextFloat() * 0.004f, 0.01f + r.nextFloat() * 0.03f);
        }
        return out;
    }

    private static Particle[] makeSparks() {
        Random r = new Random(0x51A55);
        Particle[] out = new Particle[420];
        for (int i = 0; i < out.length; i++) {
            boolean large = r.nextFloat() < 0.10f;
            out[i] = new Particle(r.nextFloat() * (float) (Math.PI * 2), -0.03f + r.nextFloat() * 1.58f,
                    large ? 0.8f + r.nextFloat() * 1.0f : 0.25f + r.nextFloat() * 0.5f,
                    large ? 0.8f + r.nextFloat() * 0.2f : 0.35f + r.nextFloat() * 0.6f,
                    0.3f + r.nextFloat() * 1.9f, r.nextFloat() * 6.28f, r.nextFloat() * 3.14f,
                    0xFFFFFF, large, r.nextInt(3));
        }
        return out;
    }

    private static void drawWinterFlakes(Matrix4f m, double t, float power, boolean animated) {
        SkyModule sky = SkyModule.instance;
        BufferBuilder b = beginBatch();
        int div = dev.clith.module.Optimization.liteSky() ? 7 : 5;
        int n = Math.min(FLAKES.length, Math.max(8, sky.stars.getInt() / div));
        for (int i = 0; i < n; i++) {
            Flake f = FLAKES[i];
            double yaw = f.yaw + (animated ? t * f.speed : 0.0);
            double pitch = f.pitch + (animated ? f.bob * Math.sin(t * 0.3 + f.phase) : 0.0);
            Vec dir = direction(yaw, pitch);
            Vec r = rightOf(dir), u = upOf(dir, r);
            Vec cen = scale(dir, 146f);
            float tw = animated ? 0.65f + 0.35f * (float) Math.sin(t * (0.8 + f.speed * 30.0) + f.phase) : 1f;
            int col = mix(0xFFFFFF, sky.neonColor(i * 0.13f, t, 0.9f, 1f), 0.38f);
            softDisc(b, m, cen, r, u, 0, 0, f.size * 1.9f, col, 0.17f * power * tw, 0f, 8);
            snowflakeTan(b, m, cen, r, u, f.size, f.phase + (animated ? (float) (t * f.spin) : 0f),
                    0xFFFFFF, Math.min(1f, 0.9f * tw * (0.35f + power * 0.65f)));
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    private static void drawWinterSparks(Matrix4f m, double t, float power, boolean animated) {
        SkyModule sky = SkyModule.instance;
        BufferBuilder b = beginBatch();
        int count = Math.min(SPARKS.length, Math.max(40, sky.stars.getInt() / (dev.clith.module.Optimization.liteSky() ? 2 : 1)));
        for (int i = 0; i < count; i++) {
            Particle p = SPARKS[i];
            Vec dir = direction(p.yaw(), p.pitch());
            Vec r = rightOf(dir), u = upOf(dir, r);
            Vec cen = scale(dir, 148f);
            float tw = animated ? 0.20f + 0.80f * (0.5f + 0.5f * (float) Math.sin(t * p.speed() * 1.6 + p.phase())) : 1f;
            float a = MathHelper.clamp(p.alpha() * power * tw, 0f, 1f);
            int col = p.kind() == 0 ? 0xFFFFFF : mix(0xFFFFFF, sky.neonColor(i * 0.07f, t, 1.2f, 1f), 0.55f);
            float s = p.size();
            if (p.large()) {
                float rot = p.rotation() + (animated ? (float) (t * 0.03) : 0f);
                tangentDiamond(b, m, cen, r, u, s * 0.34f, s * 3.4f, rot, col, a);
                tangentDiamond(b, m, cen, r, u, s * 0.34f, s * 3.4f, rot + 1.5708f, col, a);
                tangentDiamond(b, m, cen, r, u, s * 0.9f, s * 0.9f, rot + 0.785f, 0xFFFFFF, a);
                softDisc(b, m, cen, r, u, 0, 0, s * 2.6f, col, a * 0.22f, 0f, 8);
            } else {
                tangentDiamond(b, m, cen, r, u, s, s, p.rotation(), col, a);
            }
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    /** A cold, bright light source with an iridescent halo, flare cross and soft glow. */
    private static void drawWinterLight(Matrix4f m, double t, float power, boolean animated) {
        SkyModule sky = SkyModule.instance;
        BufferBuilder b = beginBatch();
        Vec dir = direction(1.05, 0.62);
        Vec r = rightOf(dir), u = upOf(dir, r);
        Vec cen = scale(dir, 149f);
        double tt = animated ? t : 0.0;
        float pulse = 0.92f + 0.08f * (float) Math.sin(tt * 0.9);
        int tint = sky.neonColor(0.1f, t, 0.8f, 1f);
        softDisc(b, m, cen, r, u, 0, 0, 58f, tint, 0.20f * power * pulse, 0f, 16);
        softDisc(b, m, cen, r, u, 0, 0, 30f, 0xFFFFFF, 0.30f * power * pulse, 0f, 16);
        softDisc(b, m, cen, r, u, 0, 0, 11f, 0xFFFFFF, 0.95f * pulse, 0.12f, 16);
        int segs = 72;
        for (int i = 0; i < segs; i++) {
            int col = sky.neonColor(i / (float) segs * 1.4f, t, 1.2f, 1f);
            arcQuad(b, m, cen, r, u, 24f, 26.2f, i * Math.PI * 2 / segs, (i + 1) * Math.PI * 2 / segs, col, 0.34f * power);
            arcQuad(b, m, cen, r, u, 36f, 36.8f, i * Math.PI * 2 / segs, (i + 1) * Math.PI * 2 / segs, col, 0.18f * power);
        }
        float rot = (float) (tt * 0.02);
        tangentDiamond(b, m, cen, r, u, 3.2f, 120f, rot, 0xFFFFFF, 0.50f * power);
        tangentDiamond(b, m, cen, r, u, 3.2f, 120f, rot + 1.5708f, 0xFFFFFF, 0.50f * power);
        tangentDiamond(b, m, cen, r, u, 2.0f, 64f, rot + 0.785f, tint, 0.34f * power);
        tangentDiamond(b, m, cen, r, u, 2.0f, 64f, rot + 2.356f, tint, 0.34f * power);
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    // ------------------------------------------------------------ frost mandala patterns

    private static void drawWinterPatterns(Matrix4f m, double t, float power, boolean animated) {
        SkyModule sky = SkyModule.instance;
        BufferBuilder b = beginBatch();
        float[][] spec = {
                {0.55f, 1.02f, 0.50f, 1f},
                {3.50f, 0.86f, 0.36f, -1f},
                {5.40f, 0.62f, 0.28f, 1f},
                {2.20f, 0.46f, 0.22f, -1f}
        };
        double tt = animated ? t : 0.0;
        int n = dev.clith.module.Optimization.liteSky() ? 2 : spec.length;
        for (int k = 0; k < n; k++) {
            Vec dir = direction(spec[k][0], spec[k][1]);
            Vec r = rightOf(dir), u = upOf(dir, r);
            Vec cen = scale(dir, 147f);
            float R = spec[k][2] * 147f;
            float rot = (float) (tt * 0.035 * spec[k][3]);
            int c1 = sky.neonColor(k * 0.3f, t, 0.8f, 1f);
            int c2 = sky.neonColor(k * 0.3f + 0.4f, t, 1.1f, 1f);
            float a = power * (0.85f + 0.15f * (float) Math.sin(tt * 0.5 + k));

            ringTan(b, m, cen, r, u, R * 0.30f, 0.55f, c1, 0.34f * a, 48, 0, rot);
            ringTan(b, m, cen, r, u, R * 0.56f, 0.45f, c2, 0.28f * a, 64, 3, rot * -1.4f);
            ringTan(b, m, cen, r, u, R * 0.80f, 0.45f, c1, 0.24f * a, 80, 0, rot * 0.6f);
            ringTan(b, m, cen, r, u, R, 0.7f, c2, 0.32f * a, 96, 0, 0f);
            for (int j = 0; j < 12; j++) {
                float ang = rot * 1.3f + j * (float) (Math.PI / 6);
                polarDiamond(b, m, cen, r, u, ang, R * 0.34f, R * 0.56f, R * 0.045f, c2, 0.30f * a);
                polarDiamond(b, m, cen, r, u, -rot * 1.1f + (j + 0.5f) * (float) (Math.PI / 6), R * 0.60f, R * 0.80f, R * 0.032f, c1, 0.24f * a);
            }
            for (int j = 0; j < 6; j++) {
                float ang = rot * 0.5f + j * (float) (Math.PI / 3);
                lineTan(b, m, cen, r, u, (float) Math.cos(ang) * R * 0.08f, (float) Math.sin(ang) * R * 0.08f,
                        (float) Math.cos(ang) * R * 0.98f, (float) Math.sin(ang) * R * 0.98f, 0.35f, c1, 0.14f * a);
            }
            snowflakeTan(b, m, cen, r, u, R * 0.26f, rot * 2f, 0xFFFFFF, 0.55f * a);
            softDisc(b, m, cen, r, u, 0, 0, R * 0.2f, c1, 0.18f * a, 0f, 10);
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    // ------------------------------------------------------------ tangent-plane drawing helpers

    /** Raw vertex (no Vec allocation). */
    private static void vtx(BufferBuilder b, Matrix4f m, float x, float y, float z, int rgb, float alpha) {
        b.vertex(m, x, y, z).color(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f,
                MathHelper.clamp(alpha, 0f, 1f));
    }

    /** Soft round disc (triangle fan): aC at the centre, aE at the rim. */
    private static void softDisc(BufferBuilder b, Matrix4f m, Vec cen, Vec r, Vec u, float ox, float oy,
                                 float rad, int rgb, float aC, float aE, int segs) {
        float cx = cen.x() + r.x() * ox + u.x() * oy;
        float cy = cen.y() + r.y() * ox + u.y() * oy;
        float cz = cen.z() + r.z() * ox + u.z() * oy;
        float px = 0f, py = 0f, pz = 0f;
        for (int i = 0; i <= segs; i++) {
            double a = Math.PI * 2 * i / segs;
            float x = (float) Math.cos(a) * rad, y = (float) Math.sin(a) * rad;
            float qx = cx + r.x() * x + u.x() * y;
            float qy = cy + r.y() * x + u.y() * y;
            float qz = cz + r.z() * x + u.z() * y;
            if (i > 0) {
                vtx(b, m, cx, cy, cz, rgb, aC);
                vtx(b, m, px, py, pz, rgb, aE);
                vtx(b, m, qx, qy, qz, rgb, aE);
                vtx(b, m, qx, qy, qz, rgb, aE);
            }
            px = qx;
            py = qy;
            pz = qz;
        }
    }

    /** Ring segment between two radii and two angles on the tangent plane. */
    private static void arcQuad(BufferBuilder b, Matrix4f m, Vec cen, Vec r, Vec u, float r0, float r1,
                                double a0, double a1, int rgb, float alpha) {
        float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
        planeVertex(b, m, cen, r, u, c0 * r0, s0 * r0, rgb, alpha);
        planeVertex(b, m, cen, r, u, c0 * r1, s0 * r1, rgb, alpha);
        planeVertex(b, m, cen, r, u, c1 * r1, s1 * r1, rgb, alpha);
        planeVertex(b, m, cen, r, u, c1 * r0, s1 * r0, rgb, alpha);
    }

    private static void planeVertex(BufferBuilder b, Matrix4f m, Vec cen, Vec r, Vec u, float x, float y, int rgb, float alpha) {
        vtx(b, m, cen.x() + r.x() * x + u.x() * y, cen.y() + r.y() * x + u.y() * y, cen.z() + r.z() * x + u.z() * y, rgb, alpha);
    }

    /** Thin line between two tangent-plane points. */
    private static void lineTan(BufferBuilder b, Matrix4f m, Vec cen, Vec r, Vec u,
                                float x0, float y0, float x1, float y1, float th, int rgb, float alpha) {
        float dx = x1 - x0, dy = y1 - y0;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 1.0e-6f) return;
        float nx = -dy / len * th * 0.5f, ny = dx / len * th * 0.5f;
        planeVertex(b, m, cen, r, u, x0 - nx, y0 - ny, rgb, alpha);
        planeVertex(b, m, cen, r, u, x1 - nx, y1 - ny, rgb, alpha);
        planeVertex(b, m, cen, r, u, x1 + nx, y1 + ny, rgb, alpha);
        planeVertex(b, m, cen, r, u, x0 + nx, y0 + ny, rgb, alpha);
    }

    /** Ring of small quads. skip > 0 leaves gaps: skip segments on, skip segments off (dashed pattern). */
    private static void ringTan(BufferBuilder b, Matrix4f m, Vec cen, Vec r, Vec u, float rad, float th,
                                int rgb, float alpha, int segs, int skip, float rot) {
        for (int i = 0; i < segs; i++) {
            if (skip > 0 && (i / skip) % 2 == 1) continue;
            arcQuad(b, m, cen, r, u, rad - th * 0.5f, rad + th * 0.5f,
                    rot + Math.PI * 2 * i / segs, rot + Math.PI * 2 * (i + 1) / segs, rgb, alpha);
        }
    }

    /** Diamond petal pointing along angle from rIn to rOut. */
    private static void polarDiamond(BufferBuilder b, Matrix4f m, Vec cen, Vec r, Vec u, float ang,
                                     float rIn, float rOut, float halfW, int rgb, float alpha) {
        float c = (float) Math.cos(ang), s = (float) Math.sin(ang);
        float mid = (rIn + rOut) * 0.5f;
        planeVertex(b, m, cen, r, u, c * rOut, s * rOut, rgb, alpha);
        planeVertex(b, m, cen, r, u, c * mid - s * halfW, s * mid + c * halfW, rgb, alpha);
        planeVertex(b, m, cen, r, u, c * rIn, s * rIn, rgb, alpha);
        planeVertex(b, m, cen, r, u, c * mid + s * halfW, s * mid - c * halfW, rgb, alpha);
    }

    /** Six-armed crystal snowflake on the sky's tangent plane. */
    private static void snowflakeTan(BufferBuilder b, Matrix4f m, Vec cen, Vec r, Vec u, float size, float rot, int rgb, float alpha) {
        float th = Math.max(0.16f, size * 0.07f);
        float[] at = {0.46f, 0.74f};
        float[] len = {0.34f, 0.22f};
        for (int k = 0; k < 6; k++) {
            float ang = rot + k * (float) (Math.PI / 3);
            float c = (float) Math.cos(ang), s = (float) Math.sin(ang);
            lineTan(b, m, cen, r, u, c * size * 0.1f, s * size * 0.1f, c * size, s * size, th, rgb, alpha);
            for (int j = 0; j < 2; j++) {
                float bx = c * size * at[j], by = s * size * at[j];
                for (int side = -1; side <= 1; side += 2) {
                    float ba = ang + side * (float) (Math.PI / 3);
                    lineTan(b, m, cen, r, u, bx, by, bx + (float) Math.cos(ba) * size * len[j],
                            by + (float) Math.sin(ba) * size * len[j], th * 0.85f, rgb, alpha);
                }
            }
        }
    }

    private static int mix(int a, int b, float t) {
        t = MathHelper.clamp(t, 0f, 1f);
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return (r << 16) | (g << 8) | bl;
    }

    private static Vec add(Vec a, Vec b) { return new Vec(a.x + b.x, a.y + b.y, a.z + b.z); }
    private static Vec scale(Vec v, float s) { return new Vec(v.x * s, v.y * s, v.z * s); }
    private static Vec cross(Vec a, Vec b) { return new Vec(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x); }
    private static float length(Vec v) { return (float) Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z); }
    private static Vec normalize(Vec v) { float n = length(v); return n < 1.0e-6f ? new Vec(1, 0, 0) : scale(v, 1f / n); }

    private record Vec(float x, float y, float z) {}
    private record Particle(float yaw, float pitch, float size, float alpha, float speed, float phase,
                            float rotation, int color, boolean large, int kind) {}
    private record Cloud(float yaw, float pitch, float width, float height, int pieces, float[] jitter) {}
}
