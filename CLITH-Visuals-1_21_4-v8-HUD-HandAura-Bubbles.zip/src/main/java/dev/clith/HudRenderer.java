package dev.clith;

import dev.clith.gui.Draw;
import dev.clith.gui.Fonts;
import dev.clith.gui.ThemeManager;
import dev.clith.module.Module;
import dev.clith.module.ModuleManager;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

/** Glass HUD: watermark, info panel, keystrokes and an animated module list. */
public class HudRenderer {
    private static final int TEXT = ThemeManager.TEXT;
    private static final int MUTED = ThemeManager.MUTED;

    /** Per-module animation state for the module list. */
    private static final class Entry {
        float presence;      // 0 hidden .. 1 fully shown
        float y = Float.NaN; // smoothed vertical position
        int width;
    }

    private static final Map<Module, Entry> ENTRIES = new IdentityHashMap<>();
    /** 0 W, 1 A, 2 S, 3 D, 4 space, 5 LMB, 6 RMB. */
    private static final float[] KEYS = new float[7];
    private static long last = System.nanoTime();
    private static float fadeIn;

    public static void init() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> render(context));
    }

    private static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null) return;

        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1_000_000_000f);
        last = now;
        fadeIn = Draw.approach(fadeIn, 1f, 3.5f, dt);
        float a = Draw.ease(fadeIn);

        int y = 6;

        // Top-centre status strip inspired by the reference HUD.
        if (ModuleManager.statusHud != null && ModuleManager.statusHud.isEnabled()) {
            ModuleManager.statusHud.draw(ctx, mc, a);
        }

        // First-person hand aura uses an animated multicolour palette.
        if (ModuleManager.handAura != null && ModuleManager.handAura.isEnabled()) {
            ModuleManager.handAura.draw(ctx);
        }

        // Watermark (module "Watermark")
        if (ModuleManager.watermark.isEnabled()) y = ModuleManager.watermark.draw(ctx, y, a);

        // FPS / coordinates / direction
        if (ModuleManager.infoHud.isEnabled()) y = infoPanel(ctx, mc, y, a);

        // Keystrokes
        if (ModuleManager.keystrokes.isEnabled()) keystrokes(ctx, mc, y, dt, a);

        // Module list (right side, longest first)
        if (ModuleManager.moduleListHud.isEnabled()) moduleList(ctx, dt, a);
    }

    // ------------------------------------------------------------------ info panel

    private static int infoPanel(DrawContext ctx, MinecraftClient mc, int y, float a) {
        List<String[]> rows = new ArrayList<>();
        if (ModuleManager.infoHud.showFps.get()) rows.add(new String[]{"FPS", String.valueOf(mc.getCurrentFps())});
        if (ModuleManager.infoHud.showCoords.get()) {
            rows.add(new String[]{"XYZ", String.format("%.1f  %.1f  %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ())});
        }
        if (ModuleManager.infoHud.showDirection.get()) rows.add(new String[]{"DIR", direction(mc.player.getHorizontalFacing())});
        if (rows.isEmpty()) return y;

        int labelW = 0, valueW = 0;
        for (String[] r : rows) {
            labelW = Math.max(labelW, Fonts.width(r[0]));
            valueW = Math.max(valueW, Fonts.width(r[1]));
        }
        int rowH = 12;
        int w = 14 + labelW + 10 + valueW + 12;
        int h = rows.size() * rowH + 9;
        int x1 = 8;
        Draw.panel(ctx, x1, y, x1 + w, y + h, 6, a);
        Draw.gradBar(ctx, x1 + 4, y + 6, y + h - 6, 2, 0.95f * a, 0f);
        int ty = y + 5;
        for (String[] r : rows) {
            Fonts.draw(ctx, r[0], x1 + 12, ty, ThemeManager.primary(), 0.95f * a);
            Fonts.draw(ctx, r[1], x1 + 12 + labelW + 10, ty, TEXT, a);
            ty += rowH;
        }
        return y + h + 6;
    }

    // ------------------------------------------------------------------ keystrokes

    private static void keystrokes(DrawContext ctx, MinecraftClient mc, int y, float dt, float a) {
        boolean[] down = {
                mc.options.forwardKey.isPressed(), mc.options.leftKey.isPressed(), mc.options.backKey.isPressed(),
                mc.options.rightKey.isPressed(), mc.options.jumpKey.isPressed(),
                mc.options.attackKey.isPressed(), mc.options.useKey.isPressed()};
        for (int i = 0; i < KEYS.length; i++) KEYS[i] = Draw.approach(KEYS[i], down[i] ? 1f : 0f, down[i] ? 24f : 12f, dt);

        int s = 22, gap = 3;
        int bx = 8, by = Math.max(y + 2, ctx.getScaledWindowHeight() / 2 - 40);
        keyBox(ctx, bx + s + gap, by, s, s, "W", KEYS[0], a);
        keyBox(ctx, bx, by + s + gap, s, s, "A", KEYS[1], a);
        keyBox(ctx, bx + s + gap, by + s + gap, s, s, "S", KEYS[2], a);
        keyBox(ctx, bx + 2 * (s + gap), by + s + gap, s, s, "D", KEYS[3], a);
        int row3 = by + 2 * (s + gap);
        int half = (3 * s + 2 * gap - gap) / 2;
        keyBox(ctx, bx, row3, half, 18, "ЛКМ", KEYS[5], a);
        keyBox(ctx, bx + half + gap, row3, 3 * s + 2 * gap - half - gap, 18, "ПКМ", KEYS[6], a);
        keyBox(ctx, bx, row3 + 18 + gap, 3 * s + 2 * gap, 16, "ПРОБЕЛ", KEYS[4], a);
    }

    private static void keyBox(DrawContext ctx, int x, int y, int w, int h, String label, float p, float a) {
        int off = Math.round(p);
        int y1 = y + off, y2 = y1 + h;
        Draw.glass(ctx, x, y1, x + w, y2, 5, a);
        if (p > 0.01f) {
            Draw.halo(ctx, x, y1, x + w, y2, 5, ThemeManager.primary(), p * a);
            Draw.rr(ctx, x, y1, x + w, y2, 5, Draw.col(ThemeManager.primary(), 0.50f * p * a));
        }
        Draw.outline(ctx, x, y1, x + w, y2, 5, (0.45f + 0.55f * p) * a);
        int tc = Draw.lerp(MUTED, 0xFFFFFF, p);
        int tw = Fonts.widthBold(label);
        if (tw > w - 4) Fonts.draw(ctx, label, x + (w - Fonts.width(label)) / 2, y1 + (h - 8) / 2, tc, a);
        else Fonts.drawBold(ctx, label, x + (w - tw) / 2, y1 + (h - 8) / 2, tc, a);
    }

    // ------------------------------------------------------------------ module list

    private static int entryWidth(Module m) {
        int w = Fonts.widthBold(m.name) + 18;
        String suf = m.suffix();
        if (suf != null) w += 6 + Fonts.width(suf);
        return w;
    }

    private static void moduleList(DrawContext ctx, float dt, float a) {
        List<Module> shown = new ArrayList<>();
        for (Module m : ModuleManager.MODULES) {
            if (!m.listed) continue;
            Entry e = ENTRIES.computeIfAbsent(m, k -> new Entry());
            e.presence = Draw.approach(e.presence, m.isEnabled() ? 1f : 0f, 9f, dt);
            if (m.isEnabled() && e.presence < 0.02f) e.presence = 0.02f;
            if (e.presence > 0.015f) {
                e.width = entryWidth(m);
                shown.add(m);
            }
        }
        shown.sort(Comparator.comparingInt((Module m) -> ENTRIES.get(m).width).reversed());

        int screenW = ctx.getScaledWindowWidth();
        float ty = 8;
        int n = shown.size();
        for (int i = 0; i < n; i++) {
            Module m = shown.get(i);
            Entry e = ENTRIES.get(m);
            if (Float.isNaN(e.y)) e.y = ty;
            e.y = Draw.approach(e.y, ty, 14f, dt);
            float p = Draw.ease(e.presence);
            float k = n > 1 ? (float) i / (n - 1) : 0f;

            int w = e.width;
            int slide = (int) ((1f - p) * (w + 14));
            int x2 = screenW - 8 + slide;
            int x1 = x2 - w;
            int y1 = Math.round(e.y), y2 = y1 + 17;
            float al = p * a;

            int c = ThemeManager.gradient(k * 0.8f);
            Draw.glass(ctx, x1, y1, x2, y2, 5, al);
            Draw.outline(ctx, x1, y1, x2, y2, 5, 0.55f * al);
            Draw.gradBar(ctx, x2 - 3, y1 + 3, y2 - 3, 2, 0.95f * al, k);
            Fonts.drawBold(ctx, m.name, x1 + 7, y1 + 4, c, al);
            String suf = m.suffix();
            if (suf != null) Fonts.draw(ctx, suf, x1 + 7 + Fonts.widthBold(m.name) + 6, y1 + 4, MUTED, al * 0.9f);
            ty += (17 + 3) * p;
        }
    }

    private static String direction(Direction d) {
        return switch (d) {
            case NORTH -> "Север  (-Z)";
            case SOUTH -> "Юг  (+Z)";
            case EAST -> "Восток  (+X)";
            case WEST -> "Запад  (-X)";
            default -> d.asString();
        };
    }
}
