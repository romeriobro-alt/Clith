package dev.clith.mixin;

import dev.clith.module.CustomFog;
import dev.clith.module.SkyModule;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Fog;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BackgroundRenderer.class)
public abstract class BackgroundRendererFogMixin {
    @Inject(method = "applyFog", at = @At("RETURN"), cancellable = true, require = 0)
    private static void clith$fog(CallbackInfoReturnable<Fog> cir) {
        Fog fog = cir.getReturnValue();
        SkyModule sky = SkyModule.instance;
        if (sky != null && sky.isEnabled() && sky.matchFog.get()) {
            fog = SkyModule.customSkyActive() ? sky.tintFog(fog) : sky.edgeFog(fog);
        }
        CustomFog f = CustomFog.instance;
        if (f != null && f.isEnabled()) fog = f.apply(fog);
        cir.setReturnValue(fog);
    }
}
