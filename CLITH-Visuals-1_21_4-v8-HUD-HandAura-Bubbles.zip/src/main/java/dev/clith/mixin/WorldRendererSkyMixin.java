package dev.clith.mixin;

import dev.clith.module.SkyModule;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Fog;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.FrameGraphBuilder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Stops Minecraft's vanilla sun/moon/star sky pass when CLITH's custom sky is selected. */
@Mixin(WorldRenderer.class)
public abstract class WorldRendererSkyMixin {
    @Inject(method = "renderSky", at = @At("HEAD"), cancellable = true)
    private void clith$replaceVanillaSky(FrameGraphBuilder frameGraphBuilder, Camera camera, float tickDelta, Fog fog, CallbackInfo ci) {
        if (SkyModule.customSkyActive()) {
            ci.cancel();
        }
    }
}
