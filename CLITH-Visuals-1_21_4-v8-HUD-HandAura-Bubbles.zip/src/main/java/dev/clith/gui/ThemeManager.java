package dev.clith.gui;

/**
 * Animated palette presets for the CLITH interface. Colours slowly travel through the selected
 * palette. Everything is allocation free, so it is safe to call every frame.
 */
public final class ThemeManager {
    public enum Theme {
        ICE("Ice", 0x8EE8FF, 0xB79CFF),
        AURORA("Aurora", 0x7CFFD4, 0x8AA4FF),
        SAKURA("Sakura", 0xFFA8D8, 0xC9A4FF),
        VIOLET("Violet", 0xA78BFA, 0x3B82F6),
        OCEAN("Ocean", 0x38BDF8, 0x6366F1),
        EMERALD("Emerald", 0x34D399, 0x14B8A6),
        ROSE("Rose", 0xFB7185, 0xA855F7),
        AMBER("Amber", 0xFBBF24, 0xF97316);

        public final String label;
        public final int primary;
        public final int secondary;

        Theme(String label, int primary, int secondary) {
            this.label = label;
            this.primary = primary;
            this.secondary = secondary;
        }
    }

    // Text / surface colours shared by the whole interface (winter glass look).
    public static final int TEXT = 0xF4F8FF;
    public static final int MUTED = 0xA9B8D6;
    public static final int DIM = 0x6F7FA3;
    public static final int GLASS = 0x0A1126;

    private static Theme current = Theme.ICE;
    private static long animationStart = System.nanoTime();

    private ThemeManager() {}

    public static Theme current() { return current; }

    public static void set(Theme theme) {
        if (theme != null) { current = theme; animationStart = System.nanoTime(); }
    }

    public static Theme next() {
        Theme[] values = Theme.values();
        set(values[(current.ordinal() + 1) % values.length]);
        return current;
    }

    public static double seconds() {
        return (System.nanoTime() - animationStart) / 1_000_000_000.0;
    }

    /** Smoothly animates between the two colours in the active theme. */
    private static float phase() {
        return (float) (0.5 - 0.5 * Math.cos(seconds() * 0.8));
    }

    public static int primary() { return Draw.lerp(current.primary, current.secondary, phase()); }

    public static int secondary() { return Draw.lerp(current.secondary, current.primary, phase()); }

    /** Accent without animation (for small static details). */
    public static int accent() { return current.primary; }

    /**
     * Moving gradient. It is a triangle wave, so it goes primary -> secondary -> primary and
     * never jumps at the wrap-around point.
     */
    public static int gradient(float t) {
        float shift = (float) ((System.nanoTime() / 1_000_000_000.0 * 0.16) % 1.0);
        float u = (t + shift) % 1f;
        if (u < 0f) u += 1f;
        float tri = 1f - Math.abs(2f * u - 1f);
        return Draw.lerp(current.primary, current.secondary, tri);
    }
}
