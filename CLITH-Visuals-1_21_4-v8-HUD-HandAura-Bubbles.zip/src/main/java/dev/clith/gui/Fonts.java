package dev.clith.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

/**
 * CLITH's bundled Inter fonts (clean, Plintus-like sans) instead of the default pixel font.
 * Text objects and widths are cached: building a styled Text and measuring it every frame for
 * every label was the main per-frame cost of the old interface.
 */
public final class Fonts {
    public static final Identifier UI = Identifier.of("clith", "ui");
    public static final Identifier BOLD = Identifier.of("clith", "bold");

    private static final int CACHE_LIMIT = 768;
    private static final Map<String, Text> UI_TEXT = new HashMap<>();
    private static final Map<String, Text> BOLD_TEXT = new HashMap<>();
    private static final Map<String, Integer> UI_WIDTH = new HashMap<>();
    private static final Map<String, Integer> BOLD_WIDTH = new HashMap<>();

    private Fonts() {}

    public static Text ui(String s) {
        Text t = UI_TEXT.get(s);
        if (t == null) {
            if (UI_TEXT.size() > CACHE_LIMIT) { UI_TEXT.clear(); UI_WIDTH.clear(); }
            t = Text.literal(s).setStyle(Style.EMPTY.withFont(UI));
            UI_TEXT.put(s, t);
        }
        return t;
    }

    public static Text bold(String s) {
        Text t = BOLD_TEXT.get(s);
        if (t == null) {
            if (BOLD_TEXT.size() > CACHE_LIMIT) { BOLD_TEXT.clear(); BOLD_WIDTH.clear(); }
            t = Text.literal(s).setStyle(Style.EMPTY.withFont(BOLD));
            BOLD_TEXT.put(s, t);
        }
        return t;
    }

    /** Drop cached measurements (called when resources reload, the font may have changed). */
    public static void clearCache() {
        UI_TEXT.clear();
        BOLD_TEXT.clear();
        UI_WIDTH.clear();
        BOLD_WIDTH.clear();
    }

    public static int width(String s) {
        Integer w = UI_WIDTH.get(s);
        if (w == null) {
            w = MinecraftClient.getInstance().textRenderer.getWidth(ui(s));
            UI_WIDTH.put(s, w);
        }
        return w;
    }

    public static int widthBold(String s) {
        Integer w = BOLD_WIDTH.get(s);
        if (w == null) {
            w = MinecraftClient.getInstance().textRenderer.getWidth(bold(s));
            BOLD_WIDTH.put(s, w);
        }
        return w;
    }

    /** Plain text, no shadow (cleaner on glass panels). */
    public static void draw(DrawContext c, String s, int x, int y, int rgb, float alpha) {
        if (alpha < 0.03f || s == null || s.isEmpty()) return;
        c.drawText(MinecraftClient.getInstance().textRenderer, ui(s), x, y, Draw.col(rgb, alpha), false);
    }

    public static void drawBold(DrawContext c, String s, int x, int y, int rgb, float alpha) {
        if (alpha < 0.03f || s == null || s.isEmpty()) return;
        c.drawText(MinecraftClient.getInstance().textRenderer, bold(s), x, y, Draw.col(rgb, alpha), false);
    }

    public static void drawRight(DrawContext c, String s, int xRight, int y, int rgb, float alpha) {
        draw(c, s, xRight - width(s), y, rgb, alpha);
    }

    public static void drawBoldRight(DrawContext c, String s, int xRight, int y, int rgb, float alpha) {
        drawBold(c, s, xRight - widthBold(s), y, rgb, alpha);
    }

    public static void drawCentered(DrawContext c, String s, int cx, int y, int rgb, float alpha) {
        draw(c, s, cx - width(s) / 2, y, rgb, alpha);
    }

    public static void drawBoldCentered(DrawContext c, String s, int cx, int y, int rgb, float alpha) {
        drawBold(c, s, cx - widthBold(s) / 2, y, rgb, alpha);
    }

    /** Soft glow under a text: the same string drawn faintly one pixel around. */
    public static void drawBoldGlow(DrawContext c, String s, int x, int y, int rgb, float alpha) {
        drawBold(c, s, x - 1, y, rgb, alpha * 0.16f);
        drawBold(c, s, x + 1, y, rgb, alpha * 0.16f);
        drawBold(c, s, x, y - 1, rgb, alpha * 0.16f);
        drawBold(c, s, x, y + 1, rgb, alpha * 0.16f);
        drawBold(c, s, x, y, rgb, alpha);
    }

    /** Bold text with a moving two-colour theme gradient. */
    public static void shimmer(DrawContext c, String s, int x, int y, float time, float alpha) {
        int n = s.length();
        for (int i = 0; i < n; i++) {
            String ch = String.valueOf(s.charAt(i));
            float t = ((float) i / Math.max(1, n) + time * 0.35f) % 1f;
            drawBold(c, ch, x, y, ThemeManager.gradient(Math.abs(t * 2f - 1f)), alpha);
            x += widthBold(ch);
        }
    }

    /** Bold text with a static theme gradient. */
    public static void gradient(DrawContext c, String s, int x, int y, float alpha) {
        int n = s.length();
        for (int i = 0; i < n; i++) {
            String ch = String.valueOf(s.charAt(i));
            float t = n > 1 ? (float) i / (n - 1) : 0f;
            drawBold(c, ch, x, y, ThemeManager.gradient(t), alpha);
            x += widthBold(ch);
        }
    }
}
