package dev.clith.gui;

import net.minecraft.client.gui.DrawContext;

/** Drawing / animation helpers shared by the menu and the HUD: glass panels, glowing borders, switches. */
public final class Draw {
    private Draw() {}

    // ------------------------------------------------------------------ basic shapes

    /** Rounded rectangle built from filled strips. */
    public static void rr(DrawContext c, int x1, int y1, int x2, int y2, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min((x2 - x1) / 2, (y2 - y1) / 2)));
        c.fill(x1, y1 + r, x2, y2 - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int dx = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            c.fill(x1 + dx, y1 + i, x2 - dx, y1 + i + 1, color);
            c.fill(x1 + dx, y2 - i - 1, x2 - dx, y2 - i, color);
        }
    }

    public static int col(int rgb, float alpha) {
        return ((int) (clamp01(alpha) * 255f) << 24) | (rgb & 0xFFFFFF);
    }

    public static int lerp(int a, int b, float t) {
        t = clamp01(t);
        int r = (int) (((a >> 16) & 0xFF) + ((((b >> 16) & 0xFF) - ((a >> 16) & 0xFF)) * t));
        int g = (int) (((a >> 8) & 0xFF) + ((((b >> 8) & 0xFF) - ((a >> 8) & 0xFF)) * t));
        int bl = (int) ((a & 0xFF) + (((b & 0xFF) - (a & 0xFF)) * t));
        return (r << 16) | (g << 8) | bl;
    }

    public static float clamp01(float v) {
        return v < 0f ? 0f : Math.min(v, 1f);
    }

    public static float approach(float cur, float target, float speed, float dt) {
        return cur + (target - cur) * (1f - (float) Math.exp(-speed * dt));
    }

    public static float ease(float t) {
        float u = 1f - clamp01(t);
        return 1f - u * u * u;
    }

    public static float smooth(float t) {
        t = clamp01(t);
        return t * t * (3f - 2f * t);
    }

    /** Overshooting ease used for pop-in animations. */
    public static float back(float t) {
        t = clamp01(t);
        float c1 = 1.70158f, c3 = c1 + 1f;
        float u = t - 1f;
        return 1f + c3 * u * u * u + c1 * u * u;
    }

    /** Small triangle: pointing down (up=false) or up (up=true). */
    public static void chevron(DrawContext c, int cx, int cy, boolean up, int color) {
        for (int i = 0; i < 3; i++) {
            int half = up ? i : 2 - i;
            c.fill(cx - half, cy + i, cx + half + 1, cy + i + 1, color);
        }
    }

    // ------------------------------------------------------------------ glass interface

    /** Translucent frosted panel: dark tinted body plus a soft white sheen on the top edge. */
    public static void glass(DrawContext c, int x1, int y1, int x2, int y2, int r, float a) {
        if (a < 0.01f) return;
        rr(c, x1, y1, x2, y2, r, col(ThemeManager.GLASS, 0.52f * a));
        int sheen = Math.min((y2 - y1) / 2, 16);
        if (sheen > 2 && x2 - x1 > 2 * r + 2) {
            c.fillGradient(x1 + r, y1 + 1, x2 - r, y1 + 1 + sheen, col(0xFFFFFF, 0.085f * a), col(0xFFFFFF, 0f));
        }
    }

    /** Soft coloured halo around a panel built from a few expanding translucent layers. */
    public static void halo(DrawContext c, int x1, int y1, int x2, int y2, int r, int rgb, float a) {
        if (a < 0.01f) return;
        for (int i = 3; i >= 1; i--) {
            rr(c, x1 - i * 2, y1 - i * 2, x2 + i * 2, y2 + i * 2, r + i * 2, col(rgb, a * 0.045f));
        }
    }

    /** 1px rounded border that carries the moving theme gradient. */
    public static void outline(DrawContext c, int x1, int y1, int x2, int y2, int r, float a) {
        if (a < 0.01f) return;
        r = Math.max(0, Math.min(r, Math.min((x2 - x1) / 2, (y2 - y1) / 2)));
        float w = Math.max(1, x2 - x1), h = Math.max(1, y2 - y1);
        for (int x = x1 + r; x < x2 - r; x += 6) {
            int xe = Math.min(x2 - r, x + 6);
            float t = (x - x1) / w;
            c.fill(x, y1, xe, y1 + 1, col(ThemeManager.gradient(t), 0.85f * a));
            c.fill(x, y2 - 1, xe, y2, col(ThemeManager.gradient(t + 0.5f), 0.55f * a));
        }
        for (int y = y1 + r; y < y2 - r; y += 6) {
            int ye = Math.min(y2 - r, y + 6);
            float t = (y - y1) / h;
            c.fill(x1, y, x1 + 1, ye, col(ThemeManager.gradient(1f - t), 0.7f * a));
            c.fill(x2 - 1, y, x2, ye, col(ThemeManager.gradient(t + 0.25f), 0.7f * a));
        }
        int top = col(ThemeManager.gradient(0f), 0.85f * a);
        int topR = col(ThemeManager.gradient(0.98f), 0.85f * a);
        int bot = col(ThemeManager.gradient(0.5f), 0.55f * a);
        int botR = col(ThemeManager.gradient(0.52f), 0.55f * a);
        int prev = r;
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int dx = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            int end = Math.max(prev, dx + 1);
            c.fill(x1 + dx, y1 + i, x1 + end, y1 + i + 1, top);
            c.fill(x2 - end, y1 + i, x2 - dx, y1 + i + 1, topR);
            c.fill(x1 + dx, y2 - i - 1, x1 + end, y2 - i, bot);
            c.fill(x2 - end, y2 - i - 1, x2 - dx, y2 - i, botR);
            prev = dx;
        }
    }

    /** Glass + halo + gradient border in one call. */
    public static void panel(DrawContext c, int x1, int y1, int x2, int y2, int r, float a) {
        halo(c, x1, y1, x2, y2, r, ThemeManager.primary(), a);
        glass(c, x1, y1, x2, y2, r, a);
        outline(c, x1, y1, x2, y2, r, a);
    }

    /** Horizontal line coloured by the moving theme gradient. */
    public static void gradLine(DrawContext c, int x1, int y, int x2, int thick, float a) {
        float w = Math.max(1, x2 - x1);
        for (int x = x1; x < x2; x += 4) {
            int xe = Math.min(x2, x + 4);
            c.fill(x, y, xe, y + thick, col(ThemeManager.gradient((x - x1) / w), a));
        }
    }

    /** Vertical bar coloured by the moving theme gradient. */
    public static void gradBar(DrawContext c, int x, int y1, int y2, int thick, float a, float offset) {
        float h = Math.max(1, y2 - y1);
        for (int y = y1; y < y2; y += 3) {
            int ye = Math.min(y2, y + 3);
            c.fill(x, y, x + thick, ye, col(ThemeManager.gradient((y - y1) / h + offset), a));
        }
    }

    /** Animated toggle: on is 0..1 (animate it with approach()). */
    public static void toggle(DrawContext c, int x, int y, int w, int h, float on, float a) {
        int accent = ThemeManager.primary();
        int track = lerp(0x2A3350, accent, on);
        rr(c, x, y, x + w, y + h, h / 2, col(track, (0.55f + 0.40f * on) * a));
        if (on > 0.02f) halo(c, x, y, x + w, y + h, h / 2, accent, a * on * 0.9f);
        int knob = h - 4;
        int kx = x + 2 + (int) ((w - knob - 4) * on);
        rr(c, kx, y + 2, kx + knob, y + h - 2, knob / 2, col(lerp(0xC9D3EA, 0xFFFFFF, on), a));
    }

    /** Four-point sparkle made of 1px lines, for tiny decorative stars. */
    public static void sparkle(DrawContext c, int x, int y, int size, int rgb, float a) {
        if (a < 0.02f) return;
        c.fill(x - size, y, x + size + 1, y + 1, col(rgb, a * 0.8f));
        c.fill(x, y - size, x + 1, y + size + 1, col(rgb, a * 0.8f));
        c.fill(x, y, x + 1, y + 1, col(0xFFFFFF, a));
    }
}
