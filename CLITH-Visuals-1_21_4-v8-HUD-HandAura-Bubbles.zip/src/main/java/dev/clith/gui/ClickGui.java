package dev.clith.gui;

import dev.clith.Config;
import dev.clith.module.Category;
import dev.clith.module.Module;
import dev.clith.module.ModuleManager;
import dev.clith.module.setting.BoolSetting;
import dev.clith.module.setting.ColorSetting;
import dev.clith.module.setting.ModeSetting;
import dev.clith.module.setting.Setting;
import dev.clith.module.setting.SliderSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static dev.clith.gui.Draw.*;

/**
 * CLITH ClickGUI: frosted translucent glass in the colours of the active theme, three columns
 * (categories / modules / settings), animated switches, hover glows, a sliding tab marker and drifting
 * snow sparkles behind the content.
 */
public final class ClickGui extends Screen {
    private static final int TEXT = ThemeManager.TEXT;
    private static final int MUTED = ThemeManager.MUTED;
    private static final int DIM = ThemeManager.DIM;
    private static final int SIDEBAR = 132;
    private static final int ROW_H = 31;

    private static Category selectedCategory = Category.VISUAL;

    private record Hit(int x1, int y1, int x2, int y2, Runnable action, SliderSetting slider) {
        boolean contains(double x, double y) { return x >= x1 && x < x2 && y >= y1 && y < y2; }
    }

    private record ColorHit(int x1, int y1, int x2, int y2, ColorSetting setting, boolean hueStrip) {
        boolean contains(double x, double y) { return x >= x1 && x < x2 && y >= y1 && y < y2; }
    }

    private final List<Hit> hits = new ArrayList<>();
    private final List<ColorHit> colorHits = new ArrayList<>();

    // animation state (everything eases towards its target every frame)
    private final Map<Object, Float> hover = new IdentityHashMap<>();
    private final Map<Object, Float> selAnim = new IdentityHashMap<>();
    private final Map<Object, Float> onAnim = new IdentityHashMap<>();
    private final Map<SliderSetting, Float> sliderAnim = new IdentityHashMap<>();
    private final Map<ModeSetting, float[]> chipAnim = new IdentityHashMap<>();
    private final float[] tabHover = new float[Category.values().length];
    private float tabMarkerY = Float.NaN;
    private float detailFade = 1f;
    private Module lastDetailModule;

    private Module selectedModule;
    private String search = "";
    private boolean searchFocused;
    private boolean closing;
    private float open;
    private float dt;
    private long last = System.nanoTime();
    private float scrollModules;
    private float scrollModulesTarget;
    private float scrollSettings;
    private float scrollSettingsTarget;
    private SliderSetting dragging;
    private ColorHit draggingColor;
    private int dragX1, dragX2;
    private int accent, accent2;

    // Last-frame layout coordinates used by mouse and scroll input.
    private int px, py, pw, ph, sideX1, sideX2, listX1, listX2, detailX1, detailX2;
    private int listY1, listY2, detailY1, detailY2;

    public ClickGui() {
        super(Text.literal("CLITH"));
        List<Module> modules = ModuleManager.inCategory(selectedCategory);
        selectedModule = modules.isEmpty() ? null : modules.get(0);
    }

    @Override public boolean shouldPause() { return false; }

    @Override public void close() { closing = true; }

    @Override
    public void removed() {
        Config.save();
        super.removed();
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT || keyCode == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        if (searchFocused) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!search.isEmpty()) search = search.substring(0, search.length() - 1);
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_DELETE) {
                search = "";
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_A && (modifiers & GLFW.GLFW_MOD_CONTROL) != 0) {
                search = "";
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ENTER) {
                searchFocused = false;
                return true;
            }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchFocused && !Character.isISOControl(chr) && search.length() < 48) {
            search += chr;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (closing) return true;
        if (button == 0) {
            for (ColorHit ch : colorHits) {
                if (!ch.contains(mouseX, mouseY)) continue;
                searchFocused = false;
                draggingColor = ch;
                dragColor(mouseX, mouseY);
                return true;
            }
        }
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.contains(mouseX, mouseY)) continue;
            if (h.slider != null && button == 0) {
                dragging = h.slider;
                dragX1 = h.x1;
                dragX2 = h.x2;
                dragTo(mouseX);
                return true;
            }
            if (button == 0 && h.action != null) {
                searchFocused = false;
                h.action.run(); // the search-field action turns focus back on
            }
            return true;
        }
        searchFocused = false;
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingColor != null) {
            dragColor(mouseX, mouseY);
            return true;
        }
        if (dragging != null) {
            dragTo(mouseX);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = null;
        draggingColor = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (mouseX >= listX1 && mouseX < listX2 && mouseY >= listY1 && mouseY < listY2) {
            scrollModulesTarget = Math.max(0f, scrollModulesTarget - (float) verticalAmount * 28f);
            return true;
        }
        if (mouseX >= detailX1 && mouseX < detailX2 && mouseY >= detailY1 && mouseY < detailY2) {
            scrollSettingsTarget = Math.max(0f, scrollSettingsTarget - (float) verticalAmount * 24f);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    private void dragColor(double mouseX, double mouseY) {
        ColorHit c = draggingColor;
        if (c == null) return;
        float fx = (float) Math.max(0, Math.min(1, (mouseX - c.x1()) / Math.max(1, c.x2() - c.x1())));
        if (c.hueStrip()) {
            c.setting().setHue(fx);
        } else {
            float fy = (float) Math.max(0, Math.min(1, (mouseY - c.y1()) / Math.max(1, c.y2() - c.y1())));
            c.setting().setSV(fx, 1f - fy);
        }
    }

    private void dragTo(double mouseX) {
        if (dragging == null || dragX2 <= dragX1) return;
        dragging.setFraction((float) ((mouseX - dragX1) / (dragX2 - dragX1)));
    }

    private void setCategory(Category category) {
        selectedCategory = category;
        scrollModules = 0f;
        scrollModulesTarget = 0f;
        scrollSettings = 0f;
        scrollSettingsTarget = 0f;
        List<Module> modules = filteredModules();
        selectedModule = modules.isEmpty() ? null : modules.get(0);
    }

    private List<Module> filteredModules() {
        String query = search.trim().toLowerCase(Locale.ROOT);
        List<Module> out = new ArrayList<>();
        for (Module m : ModuleManager.inCategory(selectedCategory)) {
            if (query.isEmpty() || m.name.toLowerCase(Locale.ROOT).contains(query)
                    || m.description.toLowerCase(Locale.ROOT).contains(query)
                    || m.id.toLowerCase(Locale.ROOT).contains(query)) out.add(m);
        }
        return out;
    }

    // ------------------------------------------------------------------ animation helpers

    private float anim(Map<Object, Float> map, Object key, float target, float speed) {
        float cur = map.getOrDefault(key, target);
        cur = approach(cur, target, speed, dt);
        map.put(key, cur);
        return cur;
    }

    private static boolean inside(int mx, int my, int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx < x2 && my >= y1 && my < y2;
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        dt = Math.min((now - last) / 1_000_000_000f, 0.08f);
        last = now;
        open = approach(open, closing ? 0f : 1f, 11f, dt);
        if (closing && open < 0.02f) {
            MinecraftClient.getInstance().setScreen(null);
            return;
        }
        float e = ease(open);
        float eSide = ease(clamp01(open * 1.25f));
        float eList = ease(clamp01(open * 1.25f - 0.12f));
        float eDetail = ease(clamp01(open * 1.25f - 0.24f));
        accent = ThemeManager.primary();
        accent2 = ThemeManager.secondary();
        hits.clear();
        colorHits.clear();

        super.renderBackground(ctx, mouseX, mouseY, delta);
        ctx.fill(0, 0, width, height, col(0x050A18, 0.22f * e));

        pw = Math.min(748, width - 26);
        ph = Math.min(438, height - 22);
        px = (width - pw) / 2;
        py = (height - ph) / 2 + (int) ((1f - e) * 16f);
        sideX1 = px + 8;
        sideX2 = px + Math.min(SIDEBAR, Math.max(110, pw / 4));
        listX1 = sideX2 + 10;
        int listWidth = Math.max(118, Math.min(196, pw - (sideX2 - px) - 36 - 220));
        listX2 = listX1 + listWidth;
        detailX1 = listX2 + 10;
        detailX2 = px + pw - 10;
        listY1 = py + 58;
        listY2 = py + ph - 12;
        detailY1 = py + 10;
        detailY2 = py + ph - 10;

        // Frosted glass shell with a halo and the moving gradient border.
        panel(ctx, px, py, px + pw, py + ph, 10, e);
        drawSnow(ctx, e);
        glass(ctx, sideX1, py + 8, sideX2, py + ph - 8, 7, 0.55f * eSide);
        glass(ctx, listX1, py + 8, listX2, py + ph - 8, 7, 0.55f * eList);
        glass(ctx, detailX1, detailY1, detailX2, detailY2, 7, 0.55f * eDetail);
        outline(ctx, sideX1, py + 8, sideX2, py + ph - 8, 7, 0.22f * eSide);
        outline(ctx, listX1, py + 8, listX2, py + ph - 8, 7, 0.22f * eList);
        outline(ctx, detailX1, detailY1, detailX2, detailY2, 7, 0.22f * eDetail);

        renderSidebar(ctx, mouseX, mouseY, eSide);
        renderModuleList(ctx, mouseX, mouseY, eList);
        renderSettings(ctx, mouseX, mouseY, eDetail);
    }

    /** Slow falling snow sparkles behind the content. */
    private void drawSnow(DrawContext ctx, float e) {
        double t = ThemeManager.seconds();
        ctx.enableScissor(px + 2, py + 2, px + pw - 2, py + ph - 2);
        for (int i = 0; i < 34; i++) {
            double fx = (i * 0.6180339887) % 1.0;
            double fy0 = (i * 0.7548776662) % 1.0;
            double spd = 0.012 + (i % 5) * 0.006;
            double fy = (fy0 + t * spd) % 1.0;
            double sway = Math.sin(t * 0.6 + i * 1.7) * 0.012;
            int x = px + (int) ((fx + sway) * pw);
            int y = py + (int) (fy * ph);
            float tw = 0.35f + 0.65f * (float) (0.5 + 0.5 * Math.sin(t * (1.2 + (i % 4) * 0.5) + i));
            int c = i % 3 == 0 ? accent : (i % 3 == 1 ? accent2 : 0xFFFFFF);
            if (i % 4 == 0) sparkle(ctx, x, y, 2, c, 0.55f * tw * e);
            else ctx.fill(x, y, x + 1, y + 1, col(c, 0.5f * tw * e));
        }
        ctx.disableScissor();
    }

    private void renderSidebar(DrawContext ctx, int mouseX, int mouseY, float e) {
        // Logo: sparkle + shimmering wordmark. Clicking it cycles through the colour themes.
        double t = ThemeManager.seconds();
        int lx = sideX1 + 12, ly = py + 18;
        float pulse = 0.65f + 0.35f * (float) Math.sin(t * 2.0);
        rr(ctx, lx - 2, ly - 1, lx + 21, ly + 22, 6, col(accent, 0.16f * e));
        sparkle(ctx, lx + 10, ly + 10, 6, accent, (0.7f + 0.3f * pulse) * e);
        sparkle(ctx, lx + 10, ly + 10, 3, 0xFFFFFF, e);
        Fonts.shimmer(ctx, "CLITH", sideX1 + 40, py + 20, (float) t, e);
        Fonts.draw(ctx, "VISUAL CLIENT  1.21.4", sideX1 + 12, py + 45, DIM, e);
        hits.add(new Hit(sideX1 + 8, py + 14, sideX2 - 8, py + 42, ThemeManager::next, null));

        int searchX1 = sideX1 + 9, searchX2 = sideX2 - 9;
        int searchY = py + 65;
        boolean searchHover = inside(mouseX, mouseY, searchX1, searchY, searchX2, searchY + 24);
        float sf = anim(hover, "search", searchFocused ? 1f : (searchHover ? 0.5f : 0f), 14f);
        rr(ctx, searchX1, searchY, searchX2, searchY + 24, 6, col(lerp(0x141B33, 0x1C2850, sf), 0.85f * e));
        if (sf > 0.02f) outline(ctx, searchX1, searchY, searchX2, searchY + 24, 6, sf * e);
        int iconColor = col(lerp(MUTED, accent, sf), e);
        ctx.fill(searchX1 + 9, searchY + 7, searchX1 + 15, searchY + 8, iconColor);
        ctx.fill(searchX1 + 9, searchY + 13, searchX1 + 15, searchY + 14, iconColor);
        ctx.fill(searchX1 + 9, searchY + 8, searchX1 + 10, searchY + 13, iconColor);
        ctx.fill(searchX1 + 14, searchY + 8, searchX1 + 15, searchY + 13, iconColor);
        ctx.fill(searchX1 + 14, searchY + 13, searchX1 + 18, searchY + 17, iconColor);
        String searchText = search.isEmpty() ? "Поиск..." : search;
        if (searchFocused && ((int) (t * 2) & 1) == 0) searchText += "|";
        Fonts.draw(ctx, searchText, searchX1 + 24, searchY + 8, search.isEmpty() && !searchFocused ? DIM : TEXT, e);
        hits.add(new Hit(searchX1, searchY, searchX2, searchY + 24, () -> searchFocused = true, null));

        int tabY0 = searchY + 36;
        int tabH = 29;
        Category[] cats = Category.values();
        int selIndex = selectedCategory.ordinal();
        float targetMarker = tabY0 + selIndex * (tabH + 4);
        if (Float.isNaN(tabMarkerY)) tabMarkerY = targetMarker;
        tabMarkerY = approach(tabMarkerY, targetMarker, 16f, dt);
        int x1 = sideX1 + 8, x2 = sideX2 - 8;
        int my = Math.round(tabMarkerY);
        rr(ctx, x1, my, x2, my + tabH, 6, col(accent, 0.16f * e));
        outline(ctx, x1, my, x2, my + tabH, 6, 0.55f * e);
        gradBar(ctx, x1 + 1, my + 6, my + tabH - 6, 2, e, 0f);

        int tabY = tabY0;
        for (int i = 0; i < cats.length; i++) {
            Category category = cats[i];
            boolean selected = category == selectedCategory;
            boolean over = inside(mouseX, mouseY, x1, tabY, x2, tabY + tabH);
            tabHover[i] = approach(tabHover[i], over || selected ? 1f : 0f, 14f, dt);
            if (!selected && tabHover[i] > 0.02f) rr(ctx, x1, tabY, x2, tabY + tabH, 6, col(0xFFFFFF, 0.06f * tabHover[i] * e));
            int dot = lerp(0x4B567A, accent, tabHover[i]);
            rr(ctx, x1 + 10, tabY + 10, x1 + 19, tabY + 19, 3, col(dot, e));
            Fonts.draw(ctx, category.title, x1 + 27, tabY + 10, lerp(0xB3BED8, 0xFFFFFF, tabHover[i]), e);
            int enabled = 0;
            for (Module module : ModuleManager.inCategory(category)) if (module.isEnabled()) enabled++;
            Fonts.drawRight(ctx, String.valueOf(enabled), x2 - 8, tabY + 10, selected ? accent : DIM, e);
            final Category target = category;
            hits.add(new Hit(x1, tabY, x2, tabY + tabH, () -> setCategory(target), null));
            tabY += tabH + 4;
        }

        // Theme swatches
        ThemeManager.Theme[] themes = ThemeManager.Theme.values();
        int swY = py + ph - 66;
        Fonts.draw(ctx, "ТЕМА  ·  " + ThemeManager.current().label.toUpperCase(Locale.ROOT), sideX1 + 13, swY - 14, DIM, e);
        int sx = sideX1 + 13;
        int swSize = 11, swGap = Math.max(3, (sideX2 - sideX1 - 26 - themes.length * swSize) / Math.max(1, themes.length - 1));
        for (ThemeManager.Theme th : themes) {
            boolean cur = th == ThemeManager.current();
            boolean over = inside(mouseX, mouseY, sx - 2, swY - 2, sx + swSize + 2, swY + swSize + 2);
            float h = anim(hover, th, cur || over ? 1f : 0f, 14f);
            if (h > 0.02f) rr(ctx, sx - 2, swY - 2, sx + swSize + 2, swY + swSize + 2, 7, col(0xFFFFFF, (cur ? 0.35f : 0.16f) * h * e));
            rr(ctx, sx, swY, sx + swSize, swY + swSize, 5, col(th.primary, e));
            rr(ctx, sx + 3, swY + 3, sx + swSize - 3, swY + swSize - 3, 2, col(th.secondary, e));
            final ThemeManager.Theme target = th;
            hits.add(new Hit(sx - 2, swY - 2, sx + swSize + 2, swY + swSize + 2, () -> ThemeManager.set(target), null));
            sx += swSize + swGap;
        }

        int footerY = py + ph - 36;
        ctx.fill(sideX1 + 10, footerY, sideX2 - 10, footerY + 1, col(0xFFFFFF, 0.08f * e));
        Fonts.draw(ctx, "RSHIFT  ·  ЗАКРЫТЬ", sideX1 + 13, footerY + 12, DIM, e);
    }

    private void renderModuleList(DrawContext ctx, int mouseX, int mouseY, float e) {
        Fonts.draw(ctx, "КАТЕГОРИЯ", listX1 + 12, py + 19, DIM, e);
        Fonts.drawBold(ctx, selectedCategory.title, listX1 + 12, py + 32, TEXT, e);
        gradLine(ctx, listX1 + 10, py + 49, listX2 - 10, 1, 0.6f * e);

        List<Module> modules = filteredModules();
        if (selectedModule == null || !ModuleManager.inCategory(selectedCategory).contains(selectedModule)) {
            selectedModule = modules.isEmpty() ? null : modules.get(0);
        }
        if (!search.isEmpty() && (selectedModule == null || !modules.contains(selectedModule)) && !modules.isEmpty()) {
            selectedModule = modules.get(0);
        }

        int visibleH = listY2 - listY1;
        int totalH = modules.size() * ROW_H;
        float maxScroll = Math.max(0, totalH - visibleH);
        scrollModulesTarget = Math.min(scrollModulesTarget, maxScroll);
        scrollModules = approach(scrollModules, scrollModulesTarget, 16f, dt);

        ctx.enableScissor(listX1 + 5, listY1, listX2 - 5, listY2);
        int y = listY1 - (int) scrollModules;
        for (Module module : modules) {
            boolean selected = module == selectedModule;
            boolean over = mouseY >= listY1 && mouseY < listY2 && inside(mouseX, mouseY, listX1 + 7, y, listX2 - 7, y + ROW_H);
            float hv = anim(hover, module, over ? 1f : 0f, 14f);
            float sel = anim(selAnim, module, selected ? 1f : 0f, 14f);
            float on = anim(onAnim, module, module.isEnabled() ? 1f : 0f, 12f);
            if (y + ROW_H > listY1 && y < listY2) {
                if (hv > 0.02f) rr(ctx, listX1 + 7, y + 1, listX2 - 7, y + ROW_H - 2, 6, col(0xFFFFFF, 0.06f * hv * e));
                if (sel > 0.02f) {
                    rr(ctx, listX1 + 7, y + 1, listX2 - 7, y + ROW_H - 2, 6, col(accent, 0.16f * sel * e));
                    outline(ctx, listX1 + 7, y + 1, listX2 - 7, y + ROW_H - 2, 6, 0.45f * sel * e);
                    gradBar(ctx, listX1 + 8, y + 8, y + ROW_H - 9, 2, sel * e, 0f);
                }
                int nameColor = lerp(0x8996B4, TEXT, Math.max(on, sel));
                Fonts.draw(ctx, module.name, listX1 + 17 + (int) (3 * sel), y + 10, nameColor, e);
                int switchX = listX2 - 41, switchY = y + 9;
                toggle(ctx, switchX, switchY, 28, 14, on, e);
                hits.add(new Hit(listX1 + 7, Math.max(y + 1, listY1), listX2 - 7, Math.min(y + ROW_H - 2, listY2),
                        () -> selectedModule = module, null));
                hits.add(new Hit(switchX - 3, Math.max(y + 3, listY1), switchX + 31, Math.min(y + ROW_H - 1, listY2), module::toggle, null));
            }
            y += ROW_H;
        }
        ctx.disableScissor();

        if (modules.isEmpty()) {
            Fonts.draw(ctx, "Ничего не найдено", listX1 + 13, listY1 + 12, MUTED, e);
        }
        if (maxScroll > 0) {
            int barH = Math.max(18, visibleH * visibleH / Math.max(totalH, 1));
            int barY = listY1 + (int) ((visibleH - barH) * (scrollModules / maxScroll));
            rr(ctx, listX2 - 4, barY, listX2 - 2, barY + barH, 1, col(accent, 0.7f * e));
        }
    }

    private void renderSettings(DrawContext ctx, int mouseX, int mouseY, float e) {
        int innerX = detailX1 + 14;
        int innerRight = detailX2 - 14;
        int innerW = Math.max(70, innerRight - innerX);

        if (selectedModule != lastDetailModule) {
            lastDetailModule = selectedModule;
            detailFade = 0f;
            scrollSettings = 0f;
            scrollSettingsTarget = 0f;
        }
        detailFade = approach(detailFade, 1f, 12f, dt);
        float f = ease(clamp01(detailFade));
        float ea = e * f;
        int slide = (int) ((1f - f) * 7f);

        if (selectedModule == null) {
            Fonts.drawBold(ctx, "Настройки", innerX, detailY1 + 20, TEXT, ea);
            Fonts.draw(ctx, "Выбери модуль в центральной колонке", innerX, detailY1 + 48, MUTED, ea);
            return;
        }

        Module module = selectedModule;
        int top = detailY1 + slide;
        Fonts.draw(ctx, "МОДУЛЬ", innerX, top + 10, DIM, ea);
        Fonts.drawBold(ctx, module.name, innerX, top + 26, TEXT, ea);
        float on = anim(onAnim, module, module.isEnabled() ? 1f : 0f, 12f);
        toggle(ctx, innerRight - 30, top + 26, 30, 15, on, ea);
        hits.add(new Hit(innerRight - 34, detailY1 + 22, innerRight + 2, detailY1 + 46, module::toggle, null));

        List<String> description = wrap(module.description, innerW, 2);
        int descY = top + 49;
        for (String line : description) {
            Fonts.draw(ctx, line, innerX, descY, MUTED, ea);
            descY += 12;
        }
        gradLine(ctx, innerX, top + 77, innerRight, 1, 0.55f * ea);
        Fonts.draw(ctx, "НАСТРОЙКИ", innerX, top + 88, DIM, ea);
        Fonts.drawRight(ctx, module.settings.size() + " ПАРАМ.", innerRight, top + 88, DIM, ea);

        int settingsTop = detailY1 + 108;
        int settingsBottom = detailY2 - 12;
        int viewportH = Math.max(20, settingsBottom - settingsTop);
        int settingsContentH = settingsHeight(module, innerW);
        float maxScroll = Math.max(0, settingsContentH - viewportH);
        scrollSettingsTarget = Math.min(scrollSettingsTarget, maxScroll);
        scrollSettings = approach(scrollSettings, scrollSettingsTarget, 16f, dt);

        ctx.enableScissor(detailX1 + 8, settingsTop, detailX2 - 8, settingsBottom);
        int y = settingsTop - (int) scrollSettings + slide;
        for (Setting setting : module.settings) {
            if (setting instanceof BoolSetting bool) y = drawBool(ctx, bool, innerX, innerRight, y, ea, settingsTop, settingsBottom);
            else if (setting instanceof SliderSetting slider) y = drawSlider(ctx, slider, innerX, innerRight, y, ea, mouseX, mouseY, settingsTop, settingsBottom);
            else if (setting instanceof ModeSetting mode) y = drawMode(ctx, mode, innerX, innerRight, y, ea, mouseX, mouseY, settingsTop, settingsBottom);
            else if (setting instanceof ColorSetting color) y = drawColor(ctx, color, innerX, innerRight, y, ea, settingsTop, settingsBottom);
        }
        ctx.disableScissor();

        if (module.settings.isEmpty()) {
            Fonts.draw(ctx, "У этого модуля нет параметров", innerX, settingsTop + 8, MUTED, ea);
        }
        if (maxScroll > 0) {
            int barH = Math.max(18, viewportH * viewportH / settingsContentH);
            int barY = settingsTop + (int) ((viewportH - barH) * (scrollSettings / maxScroll));
            rr(ctx, detailX2 - 5, barY, detailX2 - 3, barY + barH, 1, col(accent, 0.7f * e));
        }
    }

    private int drawBool(DrawContext ctx, BoolSetting setting, int x1, int x2, int y, float e, int clipTop, int clipBottom) {
        int h = 30;
        float on = anim(onAnim, setting, setting.get() ? 1f : 0f, 12f);
        Fonts.draw(ctx, setting.name, x1, y + 9, lerp(0xA6B2CE, TEXT, on), e);
        toggle(ctx, x2 - 28, y + 7, 28, 14, on, e);
        if (y + h > clipTop && y < clipBottom) {
            hits.add(new Hit(x1, Math.max(y, clipTop), x2, Math.min(y + h, clipBottom), setting::toggle, null));
        }
        return y + h;
    }

    private int drawSlider(DrawContext ctx, SliderSetting setting, int x1, int x2, int y, float e,
                           int mouseX, int mouseY, int clipTop, int clipBottom) {
        int h = 39;
        float shown = sliderAnim.getOrDefault(setting, setting.fraction());
        shown = approach(shown, setting.fraction(), 22f, dt);
        sliderAnim.put(setting, shown);
        int trackY = y + 23;
        boolean active = dragging == setting || inside(mouseX, mouseY, x1, trackY - 7, x2, trackY + 11);
        float hv = anim(hover, setting, active ? 1f : 0f, 14f);

        Fonts.draw(ctx, setting.name, x1, y + 3, lerp(0xA6B2CE, TEXT, hv), e);
        Fonts.drawRight(ctx, setting.display(), x2, y + 3, lerp(accent, 0xFFFFFF, hv * 0.5f), e);
        rr(ctx, x1, trackY, x2, trackY + 4, 2, col(0x232C4A, 0.95f * e));
        int fw = (int) ((x2 - x1) * shown);
        if (fw > 0) {
            rr(ctx, x1, trackY, x1 + Math.max(4, fw), trackY + 4, 2, col(accent, e));
            rr(ctx, x1, trackY + 1, x1 + Math.max(4, fw), trackY + 2, 1, col(0xFFFFFF, 0.35f * e));
        }
        int kx = x1 + fw;
        if (hv > 0.02f) halo(ctx, kx - 4, trackY - 2, kx + 4, trackY + 6, 4, accent, hv * e);
        int ks = 3 + Math.round(hv);
        rr(ctx, kx - ks - 1, trackY + 2 - ks - 1, kx + ks + 1, trackY + 2 + ks + 1, ks + 1, col(0xFFFFFF, e));
        if (y + h > clipTop && y < clipBottom) hits.add(new Hit(x1, trackY - 6, x2, trackY + 10, null, setting));
        return y + h;
    }

    private int drawMode(DrawContext ctx, ModeSetting setting, int x1, int x2, int y, float e,
                         int mouseX, int mouseY, int clipTop, int clipBottom) {
        Fonts.draw(ctx, setting.name, x1, y + 3, 0xC3CDE4, e);
        float[] anims = chipAnim.computeIfAbsent(setting, s -> new float[s.modes.length]);
        int chipY = y + 20;
        int x = x1;
        int rowH = 20;
        for (int i = 0; i < setting.modes.length; i++) {
            String mode = setting.modes[i];
            int w = Math.min(x2 - x1, Fonts.width(mode) + 18);
            if (x > x1 && x + w > x2) {
                x = x1;
                chipY += rowH + 5;
            }
            boolean selected = i == setting.index();
            int y2 = chipY + rowH;
            boolean over = inside(mouseX, mouseY, x, Math.max(chipY, clipTop), x + w, Math.min(y2, clipBottom));
            anims[i] = approach(anims[i], selected ? 1f : (over ? 0.35f : 0f), 14f, dt);
            float a = anims[i];
            rr(ctx, x, chipY, x + w, y2, 6, col(lerp(0x1A2340, accent, a * 0.45f), (0.80f + 0.15f * a) * e));
            if (a > 0.5f) outline(ctx, x, chipY, x + w, y2, 6, (a - 0.5f) * 2f * e);
            Fonts.draw(ctx, mode, x + 9, chipY + 6, lerp(0xA6B2CE, 0xFFFFFF, a), e);
            if (y2 > clipTop && chipY < clipBottom) {
                int idx = i;
                hits.add(new Hit(x, Math.max(chipY, clipTop), x + w, Math.min(y2, clipBottom), () -> setting.set(idx), null));
            }
            x += w + 5;
        }
        return chipY + rowH + 8;
    }

    private static final int PAL_H = 58, HUE_H = 10, COLOR_H = 22 + PAL_H + 8 + HUE_H + 10;

    /** Palette: saturation/brightness square on top, hue strip below, hex + swatch in the header. */
    private int drawColor(DrawContext ctx, ColorSetting setting, int x1, int x2, int y, float e,
                          int clipTop, int clipBottom) {
        Fonts.draw(ctx, setting.name, x1, y + 3, 0xC3CDE4, e);
        int rgb = setting.rgb();
        Fonts.drawRight(ctx, String.format("#%06X", rgb), x2 - 22, y + 3, lerp(accent, 0xFFFFFF, 0.3f), e);
        rr(ctx, x2 - 17, y + 1, x2, y + 14, 4, col(0xFFFFFF, 0.35f * e));
        rr(ctx, x2 - 16, y + 2, x2 - 1, y + 13, 3, col(rgb, e));

        int sx1 = x1, sx2 = x2, sy1 = y + 20, sy2 = sy1 + PAL_H;
        int w = sx2 - sx1;
        int step = 2;
        for (int cx = 0; cx < w; cx += step) {
            float sat = (cx + step * 0.5f) / w;
            int top = 0xFF000000 | MathHelper.hsvToRgb(setting.hue(), sat, 1f);
            int xa = sx1 + cx, xb = Math.min(sx2, xa + step);
            ctx.fillGradient(xa, sy1, xb, sy2, withAlpha(top, e), withAlpha(0xFF000000, e));
        }
        int pxm = sx1 + (int) (setting.sat() * w);
        int pym = sy1 + (int) ((1f - setting.val()) * PAL_H);
        ctx.fill(pxm - 4, pym - 1, pxm + 5, pym + 2, col(0x000000, e));
        ctx.fill(pxm - 1, pym - 4, pxm + 2, pym + 5, col(0x000000, e));
        ctx.fill(pxm - 3, pym, pxm + 4, pym + 1, col(0xFFFFFF, e));
        ctx.fill(pxm, pym - 3, pxm + 1, pym + 4, col(0xFFFFFF, e));

        int hy1 = sy2 + 8, hy2 = hy1 + HUE_H;
        for (int cx = 0; cx < w; cx += step) {
            int c = 0xFF000000 | MathHelper.hsvToRgb((cx + step * 0.5f) / w, 1f, 1f);
            ctx.fill(sx1 + cx, hy1, Math.min(sx2, sx1 + cx + step), hy2, withAlpha(c, e));
        }
        int hx = sx1 + (int) (setting.hue() * w);
        ctx.fill(hx - 2, hy1 - 2, hx + 3, hy2 + 2, col(0xFFFFFF, e));
        ctx.fill(hx - 1, hy1 - 1, hx + 2, hy2 + 1, col(setting.rgb(), e));

        if (sy2 > clipTop && sy1 < clipBottom) colorHits.add(new ColorHit(sx1, Math.max(sy1, clipTop), sx2, Math.min(sy2, clipBottom), setting, false));
        if (hy2 > clipTop && hy1 < clipBottom) colorHits.add(new ColorHit(sx1, Math.max(hy1 - 3, clipTop), sx2, Math.min(hy2 + 3, clipBottom), setting, true));
        return y + COLOR_H;
    }

    private static int withAlpha(int argb, float alpha) {
        int a = (int) (((argb >>> 24) & 255) * Math.max(0f, Math.min(1f, alpha)));
        return (a << 24) | (argb & 0xFFFFFF);
    }

    private int settingsHeight(Module module, int width) {
        int h = 0;
        for (Setting setting : module.settings) {
            if (setting instanceof BoolSetting) h += 30;
            else if (setting instanceof SliderSetting) h += 39;
            else if (setting instanceof ColorSetting) h += COLOR_H;
            else if (setting instanceof ModeSetting mode) {
                int x = 0, rows = 1;
                for (String item : mode.modes) {
                    int w = Math.min(width, Fonts.width(item) + 18);
                    if (x > 0 && x + w > width) { rows++; x = 0; }
                    x += w + 5;
                }
                h += 20 + rows * 25 + 3;
            }
        }
        return h;
    }

    private static List<String> wrap(String text, int width, int maxLines) {
        List<String> lines = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : text.split("\\s+")) {
            String next = line.isEmpty() ? word : line + " " + word;
            if (!line.isEmpty() && Fonts.width(next) > width) {
                lines.add(line.toString());
                line.setLength(0);
                line.append(word);
                if (lines.size() >= maxLines) break;
            } else {
                if (!line.isEmpty()) line.append(' ');
                line.append(word);
            }
        }
        if (lines.size() < maxLines && !line.isEmpty()) lines.add(line.toString());
        if (lines.size() > maxLines) return lines.subList(0, maxLines);
        return lines;
    }
}
