package dev.clith;

import dev.clith.module.ModuleManager;
import dev.clith.render.ClithSkyRenderer;
import dev.clith.render.VisualRenderer;
import net.fabricmc.api.ClientModInitializer;

public class ClithClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        HudRenderer.init();
        ClithSkyRenderer.init();
        VisualRenderer.init();
        HudExtras.init();
    }
}
