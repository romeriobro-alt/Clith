package dev.clith.module;

import dev.clith.gui.Draw;
import dev.clith.gui.Fonts;
import dev.clith.module.setting.BoolSetting;
import dev.clith.module.setting.ModeSetting;
import dev.clith.module.setting.SliderSetting;
import dev.clith.render.Gfx;
import dev.clith.render.VisualRenderer;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/** Sparks, shockwave ring and floating damage numbers on every hit. */
public class HitEffects extends Module implements WorldEffect {
    public final ModeSetting color = add(new ModeSetting("Цвет", 2, Gfx.COLOR_MODES));
    public final ModeSetting style = add(new ModeSetting("Стиль", 1, "Искры", "Искры + кольцо"));
    public final SliderSetting count = add(new SliderSetting("Количество", 16, 4, 40, 1));
    public final SliderSetting size = add(new SliderSetting("Размер", 1.0, 0.5, 2.0, 0.1));
    public final BoolSetting numbers = add(new BoolSetting("Цифры урона", true));

    private record Spark(double x, double y, double z, double vx, double vy, double vz, double born, double life, double size, float hue) {}
    private record Ring(double x, double y, double z, double born) {}
    private record Popup(double x, double y, double z, double born, float dmg) {}
    private static final class Pending {
        final LivingEntity e; final float before; int ticks; final Vec3d pos;
        Pending(LivingEntity e, float before, Vec3d pos) { this.e = e; this.before = before; this.pos = pos; }
    }

    private final Random rnd = new Random();
    private final List<Spark> sparks = new ArrayList<>();
    private final List<Ring> rings = new ArrayList<>();
    private final List<Popup> popups = new ArrayList<>();
    private final List<Pending> pending = new ArrayList<>();

    public HitEffects() {
        super("Hit Effects", "hiteffects", GLFW.GLFW_KEY_UNKNOWN, Category.VISUAL, "Искры, кольцо и цифры урона при ударе");
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient() && isEnabled() && entity instanceof LivingEntity le && le != mc.player) onHit(le);
            return ActionResult.PASS;
        });
    }

    private void onHit(LivingEntity e) {
        Vec3d pos = e.getPos().add(0, e.getHeight() * 0.65, 0);
        if (mc.crosshairTarget instanceof EntityHitResult ehr && ehr.getEntity() == e) pos = ehr.getPos();
        double now = Gfx.now();
        int n = count.getInt();
        for (int i = 0; i < n && sparks.size() < 400; i++) {
            double yaw = rnd.nextDouble() * Math.PI * 2, pitch = (rnd.nextDouble() - 0.35) * Math.PI * 0.8;
            double sp = 1.6 + rnd.nextDouble() * 3.4;
            sparks.add(new Spark(pos.x, pos.y, pos.z,
                    Math.cos(yaw) * Math.cos(pitch) * sp, Math.sin(pitch) * sp + 0.8, Math.sin(yaw) * Math.cos(pitch) * sp,
                    now, 0.45 + rnd.nextDouble() * 0.45, (0.05 + rnd.nextDouble() * 0.07) * size.get(), rnd.nextFloat()));
        }
        if (style.index() == 1 && rings.size() < 12) rings.add(new Ring(pos.x, pos.y, pos.z, now));
        if (numbers.get()) pending.add(new Pending(e, e.getHealth() + e.getAbsorptionAmount(), pos));
    }

    @Override
    public void onDisable() {
        sparks.clear(); rings.clear(); popups.clear(); pending.clear();
    }

    @Override
    public void onTick() {
        Iterator<Pending> it = pending.iterator();
        while (it.hasNext()) {
            Pending p = it.next();
            p.ticks++;
            float now = p.e.getHealth() + p.e.getAbsorptionAmount();
            if (now < p.before - 0.01f) {
                popups.add(new Popup(p.pos.x, p.pos.y + 0.3, p.pos.z, Gfx.now(), p.before - now));
                it.remove();
            } else if (p.ticks > 10 || p.e.isRemoved()) {
                it.remove();
            }
        }
    }

    @Override
    public void renderWorld(Gfx g, float tickDelta, double now) {
        int mode = color.index();
        sparks.removeIf(s -> now - s.born() > s.life());
        for (Spark s : sparks) {
            double t = now - s.born();
            float k = (float) (t / s.life());
            double x = s.x() + s.vx() * t, y = s.y() + s.vy() * t - 0.5 * 7.0 * t * t, z = s.z() + s.vz() * t;
            float a = (1f - k);
            int c = Gfx.color(mode, s.hue());
            g.glow(x, y, z, s.size() * 3.2 * (1f - 0.4f * k), c, a * 0.8f);
            g.billboard(x, y, z, s.size() * 0.55, 0, 0xFFFFFF, a);
        }
        rings.removeIf(r -> now - r.born() > 0.4);
        for (Ring r : rings) {
            float k = (float) ((now - r.born()) / 0.4);
            double rad = 0.15 + 0.95 * Draw.ease(k);
            g.billboardRing(r.x(), r.y(), r.z(), Math.max(0.01, rad - 0.07 * (1f - k)), rad, 40, Gfx.color(mode, 0.2f), 0f, (1f - k) * 0.9f);
        }
    }

    /** Floating damage numbers, projected from world space. Called from the HUD pass. */
    public void renderHud(DrawContext ctx) {
        if (!numbers.get() || popups.isEmpty()) return;
        double now = Gfx.now();
        popups.removeIf(p -> now - p.born() > 1.1);
        for (Popup p : popups) {
            double age = now - p.born();
            float k = (float) (age / 1.1);
            float[] s = VisualRenderer.project(p.x(), p.y() + age * 0.7, p.z(), ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight());
            if (s == null) continue;
            float d = p.dmg();
            String txt = "-" + (d == Math.floor(d) ? String.valueOf((int) d) : String.format(Locale.ROOT, "%.1f", d));
            int c = Draw.lerp(0xBFEFFF, 0xFF5C7A, Math.min(1f, d / 10f));
            float a = k < 0.6f ? 1f : 1f - (k - 0.6f) / 0.4f;
            Fonts.drawBold(ctx, txt, (int) (s[0] - Fonts.widthBold(txt) / 2f), (int) s[1], c, a);
        }
    }
}
