package dev.clith.module;

import dev.clith.module.setting.BoolSetting;
import dev.clith.module.setting.ModeSetting;
import dev.clith.module.setting.SliderSetting;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.particle.ParticlesMode;
import org.lwjgl.glfw.GLFW;

/**
 * Lowers heavy video options and CLITH's own sky cost while enabled, and puts the player's original
 * values back on disable (and when the game closes, so options.txt is never left with reduced values).
 */
public class Optimization extends Module {
    public static Optimization instance;

    public final ModeSetting level = add(new ModeSetting("Уровень", 1, "Лёгкий", "Средний", "Максимум"));
    public final SliderSetting viewCap = add(new SliderSetting("Макс. дальность, чанки", 10, 4, 24, 1));
    public final BoolSetting lowParticles = add(new BoolSetting("Меньше частиц", true));
    public final BoolSetting liteSky = add(new BoolSetting("Лёгкое небо", true));

    private boolean applied;
    private GraphicsMode oGraphics;
    private CloudRenderMode oClouds;
    private ParticlesMode oParticles;
    private boolean oAo, oShadows;
    private int oBlend, oView, oSim;
    private double oEntityDist;

    public Optimization() {
        super("Optimization", "optimization", GLFW.GLFW_KEY_V, Category.PERFORMANCE, "Снижает нагрузку: графика, частицы, дальность, небо");
        instance = this;
    }

    /** True when the sky should render at reduced resolution. */
    public static boolean liteSky() {
        return instance != null && instance.isEnabled() && instance.liteSky.get();
    }

    @Override
    public String suffix() {
        return level.get();
    }

    @Override
    public void onEnable() {
        if (mc.options == null) return;
        snapshot();
        apply();
    }

    @Override
    public void onDisable() {
        restore();
    }

    @Override
    public void onSettingChanged() {
        if (isEnabled() && applied) {
            restore();
            snapshot();
            apply();
        }
    }

    private void snapshot() {
        GameOptions o = mc.options;
        oGraphics = o.getGraphicsMode().getValue();
        oClouds = o.getCloudRenderMode().getValue();
        oParticles = o.getParticles().getValue();
        oAo = o.getAo().getValue();
        oShadows = o.getEntityShadows().getValue();
        oBlend = o.getBiomeBlendRadius().getValue();
        oView = o.getViewDistance().getValue();
        oSim = o.getSimulationDistance().getValue();
        oEntityDist = o.getEntityDistanceScaling().getValue();
        applied = true;
    }

    private void apply() {
        GameOptions o = mc.options;
        int lvl = level.index();
        int cap = viewCap.getInt();

        o.getGraphicsMode().setValue(GraphicsMode.FAST);
        o.getEntityShadows().setValue(false);
        if (lowParticles.get()) o.getParticles().setValue(lvl >= 2 ? ParticlesMode.MINIMAL : ParticlesMode.DECREASED);

        if (lvl >= 1) {
            o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
            o.getBiomeBlendRadius().setValue(0);
            o.getEntityDistanceScaling().setValue(Math.min(oEntityDist, 0.75));
            o.getViewDistance().setValue(Math.min(oView, cap));
        }
        if (lvl >= 2) {
            o.getAo().setValue(false);
            o.getEntityDistanceScaling().setValue(Math.min(oEntityDist, 0.5));
            o.getViewDistance().setValue(Math.min(oView, Math.min(cap, 6)));
            o.getSimulationDistance().setValue(Math.min(oSim, 6));
        }
    }

    private void restore() {
        if (!applied || mc.options == null) return;
        GameOptions o = mc.options;
        o.getGraphicsMode().setValue(oGraphics);
        o.getCloudRenderMode().setValue(oClouds);
        o.getParticles().setValue(oParticles);
        o.getAo().setValue(oAo);
        o.getEntityShadows().setValue(oShadows);
        o.getBiomeBlendRadius().setValue(oBlend);
        o.getViewDistance().setValue(oView);
        o.getSimulationDistance().setValue(oSim);
        o.getEntityDistanceScaling().setValue(oEntityDist);
        applied = false;
    }
}
