package dev.clith.module;

import dev.clith.gui.Draw;
import dev.clith.module.setting.BoolSetting;
import dev.clith.module.setting.ModeSetting;
import dev.clith.module.setting.SliderSetting;
import dev.clith.render.Gfx;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.block.BlockState;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.shape.VoxelShape;
import org.lwjgl.glfw.GLFW;

/** Animated, glowing outline for the block you look at. */
public class BlockOutlineFx extends Module implements WorldEffect {
    public final ModeSetting color = add(new ModeSetting("Цвет", 0, Gfx.COLOR_MODES));
    public final SliderSetting thickness = add(new SliderSetting("Толщина", 0.03, 0.01, 0.08, 0.005));
    public final SliderSetting fill = add(new SliderSetting("Заливка", 0.14, 0.0, 0.5, 0.02));
    public final BoolSetting smooth = add(new BoolSetting("Плавное движение", true));
    public final BoolSetting hideVanilla = add(new BoolSetting("Скрыть обычную рамку", true));

    private double[] cur; // minX,minY,minZ,maxX,maxY,maxZ
    private float alpha;

    public BlockOutlineFx() {
        super("Block Outline", "blockoutline", GLFW.GLFW_KEY_UNKNOWN, Category.VISUAL, "Красивая подсветка блока под прицелом");
        WorldRenderEvents.BEFORE_BLOCK_OUTLINE.register((ctx, hit) -> !(isEnabled() && hideVanilla.get()));
    }

    @Override
    public void onDisable() {
        cur = null;
        alpha = 0f;
    }

    @Override
    public void renderWorld(Gfx g, float tickDelta, double now) {
        double[] want = null;
        if (mc.world != null && mc.crosshairTarget instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) {
            BlockPos pos = bhr.getBlockPos();
            BlockState st = mc.world.getBlockState(pos);
            VoxelShape shape = st.getOutlineShape(mc.world, pos);
            if (!shape.isEmpty()) {
                Box b = shape.getBoundingBox().offset(pos);
                want = new double[]{b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ};
            }
        }
        alpha = Draw.approach(alpha, want != null ? 1f : 0f, 14f, g.dt);
        if (want != null) {
            if (cur == null || !smooth.get() || Math.abs(cur[0] - want[0]) + Math.abs(cur[2] - want[2]) > 8) {
                cur = want;
            } else {
                float k = 1f - (float) Math.exp(-22f * g.dt);
                for (int i = 0; i < 6; i++) cur[i] += (want[i] - cur[i]) * k;
            }
        }
        if (cur == null || alpha < 0.02f) return;

        double e = 0.004;
        double x0 = cur[0] - e, y0 = cur[1] - e, z0 = cur[2] - e, x1 = cur[3] + e, y1 = cur[4] + e, z1 = cur[5] + e;
        int mode = color.index();
        float pulse = 0.85f + 0.15f * (float) Math.sin(now * 3.0);
        if (fill.get() > 0.001) g.box(x0, y0, z0, x1, y1, z1, Gfx.color(mode, (float) (now * 0.15)), (float) fill.get() * alpha * pulse);
        g.boxEdges(x0, y0, z0, x1, y1, z1, thickness.get(), mode, alpha * pulse, (float) (now * 0.2));
    }
}
