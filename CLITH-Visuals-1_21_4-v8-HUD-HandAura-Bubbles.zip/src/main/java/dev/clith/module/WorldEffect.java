package dev.clith.module;

import dev.clith.render.Gfx;

/** A module that draws in world space. Called once per frame while the module is enabled. */
public interface WorldEffect {
    void renderWorld(Gfx g, float tickDelta, double now);
}
