package dev.clith.module;

import dev.clith.gui.Draw;
import dev.clith.module.setting.ModeSetting;
import dev.clith.module.setting.SliderSetting;
import dev.clith.render.Gfx;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/** Marker around the entity you last hit. */
public class TargetEsp extends Module implements WorldEffect {
    public final ModeSetting color = add(new ModeSetting("Цвет", 0, Gfx.COLOR_MODES));
    public final ModeSetting style = add(new ModeSetting("Стиль", 0, "Кольцо", "Кристалл", "Круг у ног"));
    public final SliderSetting hold = add(new SliderSetting("Держать, с", 3.0, 1.0, 8.0, 0.5));

    private LivingEntity target;
    private double lastHit;
    private float alpha;

    public TargetEsp() {
        super("Target ESP", "targetesp", GLFW.GLFW_KEY_UNKNOWN, Category.VISUAL, "Маркер вокруг цели, которую ты бьёшь");
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient() && isEnabled() && entity instanceof LivingEntity le && le != mc.player) {
                target = le;
                lastHit = Gfx.now();
            }
            return ActionResult.PASS;
        });
    }

    @Override
    public void onDisable() {
        target = null;
        alpha = 0f;
    }

    @Override
    public void renderWorld(Gfx g, float tickDelta, double now) {
        if (target == null) return;
        boolean valid = target.isAlive() && !target.isRemoved() && now - lastHit < hold.get();
        alpha = Draw.approach(alpha, valid ? 1f : 0f, 9f, g.dt);
        if (!valid && alpha < 0.02f) { target = null; return; }

        Vec3d p = target.getLerpedPos(tickDelta);
        double h = target.getHeight(), w = target.getWidth();
        double rad = w * 0.5 + 0.35;
        int mode = color.index();
        float a = alpha;

        switch (style.index()) {
            case 0 -> {
                for (int k = 0; k < 7; k++) {
                    double ph = now * 1.9 - k * 0.2;
                    double yy = p.y + 0.08 + (h - 0.1) * (0.5 + 0.5 * Math.sin(ph));
                    float ka = a * 0.9f * (1f - k / 7f);
                    g.band(p.x, p.z, yy - 0.07, yy, rad, 48, now * 0.9, mode, ka * 0.25f, ka, (float) (now * 0.15));
                }
                g.ringFlat(p.x, p.y + 0.03, p.z, rad - 0.05, rad, 64, now * 1.2, mode, a * 0.35f, a * 0.8f, (float) (now * 0.15), 4);
            }
            case 1 -> {
                double cy = p.y + h + 0.6 + 0.08 * Math.sin(now * 2.0);
                double rot = now * 2.2, r = 0.17, ht = 0.27;
                for (int i = 0; i < 4; i++) {
                    double a0 = rot + i * Math.PI / 2, a1 = rot + (i + 1) * Math.PI / 2;
                    double x0 = p.x + Math.cos(a0) * r, z0 = p.z + Math.sin(a0) * r;
                    double x1 = p.x + Math.cos(a1) * r, z1 = p.z + Math.sin(a1) * r;
                    int c0 = Gfx.color(mode, i / 4f + (float) (now * 0.2));
                    int c1 = Gfx.color(mode, (i + 1) / 4f + (float) (now * 0.2));
                    int ct = Gfx.color(mode, (float) (now * 0.2));
                    g.tri(p.x, cy + ht, p.z, ct, a, x0, cy, z0, c0, a * 0.85f, x1, cy, z1, c1, a * 0.85f);
                    g.tri(p.x, cy - ht, p.z, ct, a, x1, cy, z1, c1, a * 0.85f, x0, cy, z0, c0, a * 0.85f);
                }
                g.glow(p.x, cy, p.z, 0.55, Gfx.color(mode, (float) (now * 0.2)), a * 0.35f);
            }
            default -> {
                double pulse = rad + 0.08 * Math.sin(now * 3.0);
                g.disk(p.x, p.y + 0.03, p.z, pulse, 48, mode, a * 0.04f, a * 0.35f, (float) (now * 0.15));
                g.ringFlat(p.x, p.y + 0.035, p.z, pulse - 0.07, pulse, 64, now * 1.4, mode, a * 0.6f, a, (float) (now * 0.15), 5);
            }
        }
    }
}
