package dev.clith.module;

import org.lwjgl.glfw.GLFW;

/** WASD / jump overlay (drawn by HudRenderer). */
public class Keystrokes extends Module {
    public Keystrokes() {
        super("Keystrokes", "keystrokes", GLFW.GLFW_KEY_UNKNOWN, Category.HUD, "Нажатые клавиши движения на экране");
        listed = false;
    }
}
