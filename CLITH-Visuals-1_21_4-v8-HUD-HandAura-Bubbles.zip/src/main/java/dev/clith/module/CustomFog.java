package dev.clith.module;

import dev.clith.module.setting.ColorSetting;
import dev.clith.module.setting.ModeSetting;
import dev.clith.module.setting.SliderSetting;
import net.minecraft.client.render.Fog;
import org.lwjgl.glfw.GLFW;

/** Custom fog colour and distance. The actual hook lives in BackgroundRendererFogMixin. */
public class CustomFog extends Module {
    public static CustomFog instance;

    public final ModeSetting tint = add(new ModeSetting("Цвет", 6, "Обычный", "Янтарь", "Фиолет", "Океан", "Ночь", "Сакура", "Палитра"));
    public final ColorSetting palette = add(new ColorSetting("Палитра", 0x6FA8DC));
    public final SliderSetting distance = add(new SliderSetting("Дальность", 0.7, 0.2, 1.5, 0.05));

    public CustomFog() {
        super("Custom Fog", "customfog", GLFW.GLFW_KEY_UNKNOWN, Category.VISUAL, "Свой цвет (палитра) и дальность тумана");
        instance = this;
    }

    /** Fog colour chosen here, or -1 when the module is off / set to "Обычный". The sky dome uses it too, so the horizon has no seam. */
    public static int overrideColor() {
        CustomFog f = instance;
        if (f == null || !f.isEnabled()) return -1;
        return switch (f.tint.index()) {
            case 1 -> 0xC9833A;
            case 2 -> 0x6B4BB8;
            case 3 -> 0x3A8FD0;
            case 4 -> 0x080B1C;
            case 5 -> 0xE58AB4;
            case 6 -> f.palette.rgb();
            default -> -1;
        };
    }

    /** Returns the tweaked fog. Underwater / lava / blindness fogs (very short) are left alone. */
    public Fog apply(Fog fog) {
        if (fog == null || fog.end() < 20f || fog.end() > 1.0e7f) return fog;
        float d = (float) distance.get();
        float r = fog.red(), g = fog.green(), b = fog.blue();
        int rgb = overrideColor();
        if (rgb != -1) {
            r = ((rgb >> 16) & 255) / 255f;
            g = ((rgb >> 8) & 255) / 255f;
            b = (rgb & 255) / 255f;
        }
        return new Fog(fog.start() * d, fog.end() * d, fog.shape(), r, g, b, fog.alpha());
    }
}
