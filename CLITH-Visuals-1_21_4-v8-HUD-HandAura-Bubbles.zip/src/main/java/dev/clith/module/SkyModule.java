package dev.clith.module;

import dev.clith.module.setting.BoolSetting;
import dev.clith.module.setting.ColorSetting;
import dev.clith.module.setting.ModeSetting;
import dev.clith.module.setting.SliderSetting;
import dev.clith.render.ClithSkyRenderer;
import net.minecraft.client.render.Fog;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/** Client-side animated sky presets. Aurora, Nebula, End Beams, Galaxy, Plintus, Meteors and Winter Neon replace vanilla sky. */
public class SkyModule extends Module {
    public static SkyModule instance;

    /** Index of the "Meteors" preset. */
    public static final int METEORS = 9;
    /** Index of the "Зимний неон" preset. */
    public static final int WINTER = 10;

    public final ModeSetting mode = add(new ModeSetting("Небо", WINTER,
            "Aurora", "Nebula", "End Beams", "Галактика", "Plintus", "Ночь", "Закат", "Рассвет", "День",
            "Meteors", "Зимний неон"));
    public final ColorSetting neon = add(new ColorSetting("Цвет неона", 0x8FE3FF));
    public final BoolSetting iridescent = add(new BoolSetting("Перелив", true));
    public final BoolSetting patterns = add(new BoolSetting("Узоры", true));
    public final BoolSetting snow = add(new BoolSetting("Снежинки", true));
    public final SliderSetting intensity = add(new SliderSetting("Свечение", 0.85, 0.1, 1.5, 0.05));
    public final SliderSetting stars = add(new SliderSetting("Частицы", 220, 40, 420, 20));
    public final BoolSetting animated = add(new BoolSetting("Анимация", true));
    public final ModeSetting light = add(new ModeSetting("Освещение мира", 0, "Яркое", "Закатное", "Ночное"));
    public final BoolSetting matchFog = add(new BoolSetting("Туман в цвет неба", true));

    private static final long[] TIMES = {18000, 18000, 18000, 18000, 12800, 18000, 12800, 23000, 6000, 6000, 6000};
    /** World light for the CLITH skies: the sky is only a picture, so the world stays bright by default. */
    private static final long[] LIGHT_TIMES = {6000, 12500, 18000};

    public SkyModule() {
        super("Sky", "sky", GLFW.GLFW_KEY_K, Category.VISUAL, "Анимированное небо: зимний неон, Aurora, Nebula, End Beams, Galaxy и другие");
        instance = this;
    }

    /** True when CLITH is replacing the vanilla sky with its own visual sky. */
    public static boolean customSkyActive() {
        return instance != null && instance.isEnabled() && (instance.mode.index() <= 4 || instance.mode.index() >= METEORS);
    }

    /**
     * Pastel neon colour taken from the "Цвет неона" palette. With "Перелив" the hue slowly travels around the
     * palette colour, so the winter sky shimmers like frost in the light. k offsets the hue per element.
     */
    public int neonColor(float k, double t, float satMul, float val) {
        float h = neon.hue();
        if (iridescent.get()) h += k * 0.12f + 0.10f * (float) Math.sin(t * 0.11 + k * 2.3);
        h -= (float) Math.floor(h);
        float s = MathHelper.clamp(neon.sat() * satMul, 0f, 1f);
        return MathHelper.hsvToRgb(h, s, MathHelper.clamp(val, 0f, 1f)) & 0xFFFFFF;
    }

    @Override public String suffix() { return mode.get(); }

    @Override public void onTick() {
        if (mc.world == null) return;
        long t = customSkyActive() ? LIGHT_TIMES[light.index()] : TIMES[mode.index()];
        if (t >= 0) mc.world.setTime(mc.world.getTime(), t, false);
    }

    /** Tints the world fog with the sky's horizon colour and finishes the fade slightly before the last loaded chunk, so there is no visible edge. */
    public Fog tintFog(Fog fog) {
        if (fog == null || fog.end() < 20f || fog.end() > 1.0e7f) return fog;
        int c = ClithSkyRenderer.horizonColor(mode.index());
        return new Fog(fog.start() * 0.8f, fog.end() * 0.93f, fog.shape(),
                ((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f, fog.alpha());
    }

    /** Vanilla-based skies (Ночь, Закат, Рассвет, День): keep vanilla fog colour, only finish the fade before the chunk edge. */
    public Fog edgeFog(Fog fog) {
        if (fog == null || fog.end() < 20f || fog.end() > 1.0e7f) return fog;
        return new Fog(fog.start() * 0.8f, fog.end() * 0.93f, fog.shape(), fog.red(), fog.green(), fog.blue(), fog.alpha());
    }
}
