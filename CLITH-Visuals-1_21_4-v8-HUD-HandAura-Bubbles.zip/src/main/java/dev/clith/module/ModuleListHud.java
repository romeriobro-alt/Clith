package dev.clith.module;

import org.lwjgl.glfw.GLFW;

/** Module list on the right side (drawn by HudRenderer). */
public class ModuleListHud extends Module {
    public ModuleListHud() {
        super("Module list", "modulelist", GLFW.GLFW_KEY_J, Category.HUD, "Список включённых модулей справа");
        listed = false;
    }
}
