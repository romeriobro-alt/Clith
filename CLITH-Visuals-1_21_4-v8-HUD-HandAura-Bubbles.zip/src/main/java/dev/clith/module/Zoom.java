package dev.clith.module;

import dev.clith.module.setting.SliderSetting;
import org.lwjgl.glfw.GLFW;

public class Zoom extends Module {
    private final SliderSetting fov = add(new SliderSetting("FOV при зуме", 30, 10, 60, 1));
    private Integer previousFov;
    private boolean wasDown;

    public Zoom() {
        super("Zoom", "zoom", GLFW.GLFW_KEY_Z, Category.VISUAL, "Приближение, пока держишь клавишу");
    }

    /** Hold the key to zoom, release to go back. The menu can also toggle it. */
    @Override
    public void handleKey() {
        while (key.wasPressed()) { /* clear queued presses */ }
        boolean down = key.isPressed();
        if (down != wasDown) {
            wasDown = down;
            setEnabled(down);
        }
    }

    @Override
    public void onEnable() {
        previousFov = mc.options.getFov().getValue();
        mc.options.getFov().setValue(fov.getInt());
    }

    @Override
    public void onSettingChanged() {
        if (isEnabled() && previousFov != null) mc.options.getFov().setValue(fov.getInt());
    }

    @Override
    public void onDisable() {
        if (previousFov != null) {
            mc.options.getFov().setValue(previousFov);
            previousFov = null;
        }
    }
}
