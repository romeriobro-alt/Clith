package dev.clith.module;

import dev.clith.gui.Draw;
import dev.clith.module.setting.ModeSetting;
import dev.clith.module.setting.SliderSetting;
import dev.clith.render.Gfx;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Expanding ring under the feet whenever you jump. */
public class JumpCircles extends Module implements WorldEffect {
    public final ModeSetting color = add(new ModeSetting("Цвет", 0, Gfx.COLOR_MODES));
    public final ModeSetting style = add(new ModeSetting("Стиль", 0, "Кольцо", "Двойное", "Диск"));
    public final SliderSetting radius = add(new SliderSetting("Размер", 1.8, 0.6, 4.0, 0.1));
    public final SliderSetting life = add(new SliderSetting("Время, с", 1.0, 0.3, 2.5, 0.1));
    public final SliderSetting width = add(new SliderSetting("Толщина", 0.28, 0.08, 0.8, 0.02));

    private record Circle(double x, double y, double z, double born) {}

    private final List<Circle> circles = new ArrayList<>();
    private boolean wasOnGround = true;

    public JumpCircles() {
        super("Jump Circles", "jumpcircles", GLFW.GLFW_KEY_UNKNOWN, Category.VISUAL, "Кольца под ногами при прыжке");
    }

    @Override
    public void onDisable() {
        circles.clear();
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        boolean og = mc.player.isOnGround();
        if (wasOnGround && !og && mc.player.getVelocity().y > 0.1 && circles.size() < 24) {
            circles.add(new Circle(mc.player.getX(), mc.player.getY() + 0.03, mc.player.getZ(), Gfx.now()));
        }
        wasOnGround = og;
    }

    @Override
    public void renderWorld(Gfx g, float tickDelta, double now) {
        double len = life.get();
        circles.removeIf(c -> now - c.born() > len);
        for (Circle c : circles) {
            float age = (float) ((now - c.born()) / len);
            float e = Draw.ease(age);
            float fade = (1f - age) * (1f - age * 0.4f);
            double r = radius.get() * (0.2 + 0.8 * e);
            double w = width.get() * (1.0 - 0.55 * age);
            float hue = age * 0.35f;
            switch (style.index()) {
                case 0 -> g.ringFlat(c.x(), c.y(), c.z(), Math.max(0.01, r - w), r, 64, 0, color.index(), 0f, 0.95f * fade, hue, 0);
                case 1 -> {
                    g.ringFlat(c.x(), c.y(), c.z(), Math.max(0.01, r - w), r, 64, 0, color.index(), 0f, 0.95f * fade, hue, 0);
                    double r2 = r * 0.62;
                    g.ringFlat(c.x(), c.y() + 0.005, c.z(), Math.max(0.01, r2 - w * 0.7), r2, 64, 0, color.index(), 0f, 0.7f * fade, hue + 0.3f, 0);
                }
                default -> {
                    g.disk(c.x(), c.y(), c.z(), r, 48, color.index(), 0.02f * fade, 0.55f * fade, hue);
                    g.ringFlat(c.x(), c.y() + 0.005, c.z(), Math.max(0.01, r - w * 0.5), r, 64, 0, color.index(), 0.4f * fade, 1f * fade, hue, 0);
                }
            }
        }
    }
}
