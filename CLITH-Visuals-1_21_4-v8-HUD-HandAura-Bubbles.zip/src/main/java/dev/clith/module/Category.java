package dev.clith.module;

public enum Category {
    VISUAL("Визуал"),
    PERFORMANCE("Скорость"),
    HUD("Интерфейс"),
    PLAYER("Игрок");

    public final String title;

    Category(String title) {
        this.title = title;
    }
}
