package dev.clith.module;

import dev.clith.gui.Draw;
import dev.clith.gui.Fonts;
import dev.clith.gui.ThemeManager;
import dev.clith.module.setting.BoolSetting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import org.lwjgl.glfw.GLFW;

/** Armor pieces with durability in a glass panel above the hotbar. */
public class ArmorHud extends Module {
    public final BoolSetting percent = add(new BoolSetting("Проценты", true));

    private float shown;
    private long last = System.nanoTime();

    public ArmorHud() {
        super("Armor HUD", "armorhud", GLFW.GLFW_KEY_UNKNOWN, Category.HUD, "Броня и прочность над хотбаром");
        listed = false;
    }

    public void draw(DrawContext ctx) {
        if (mc.player == null) return;
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1_000_000_000f);
        last = now;

        int count = 0;
        for (int i = 3; i >= 0; i--) if (!mc.player.getInventory().getArmorStack(i).isEmpty()) count++;
        shown = Draw.approach(shown, count > 0 ? 1f : 0f, 10f, dt);
        if (count == 0 || shown < 0.03f) return;

        float a = Draw.ease(shown);
        int slotW = percent.get() ? 44 : 24;
        int total = count * slotW;
        int x = ctx.getScaledWindowWidth() / 2 - total / 2;
        int y = ctx.getScaledWindowHeight() - 78 + (int) ((1f - a) * 8f);
        Draw.panel(ctx, x - 6, y - 5, x + total + 2, y + 24, 7, a);
        for (int i = 3; i >= 0; i--) {
            ItemStack st = mc.player.getInventory().getArmorStack(i);
            if (st.isEmpty()) continue;
            ctx.drawItem(st, x, y - 1);
            if (st.isItemBarVisible()) {
                int bar = st.getItemBarStep();
                int bx = x + 1, by = y + 17;
                Draw.rr(ctx, bx, by, bx + 14, by + 3, 1, Draw.col(0x000000, 0.45f * a));
                Draw.rr(ctx, bx, by, bx + Math.max(1, bar + 1), by + 3, 1, Draw.col(st.getItemBarColor(), 0.95f * a));
                if (percent.get()) {
                    String t = Math.round(100f * (st.getMaxDamage() - st.getDamage()) / st.getMaxDamage()) + "%";
                    Fonts.draw(ctx, t, x + 19, y + 3, ThemeManager.TEXT, a);
                }
            }
            x += slotW;
        }
    }
}
