package dev.clith.module;

import dev.clith.gui.Draw;
import dev.clith.gui.Fonts;
import dev.clith.gui.ThemeManager;
import dev.clith.module.setting.BoolSetting;
import dev.clith.module.setting.ModeSetting;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/** Top-left watermark. Change TEXT to put your own name in it. */
public class Watermark extends Module {
    public static final String TEXT = "Clith";

    public final ModeSetting style = add(new ModeSetting("Стиль", 0, "Панель", "Минимал"));
    public final BoolSetting showFps = add(new BoolSetting("FPS", true));
    public final BoolSetting showTime = add(new BoolSetting("Время", false));

    public Watermark() {
        super("Watermark", "watermark", GLFW.GLFW_KEY_UNKNOWN, Category.HUD, "Надпись с названием клиента в углу");
        listed = false;
    }

    /** Draws at (8, y) and returns the next free y. */
    public int draw(DrawContext ctx, int y, float a) {
        StringBuilder sb = new StringBuilder("1.21.4");
        if (showFps.get()) sb.append("  ·  ").append(mc.getCurrentFps()).append(" fps");
        if (showTime.get()) sb.append("  ·  ").append(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")));
        String sub = sb.toString();
        int nameW = Fonts.widthBold(TEXT);
        double t = ThemeManager.seconds();
        if (style.index() == 0) {
            int x1 = 8;
            int w = 12 + 8 + nameW + 9 + Fonts.width(sub) + 12;
            int h = 22;
            Draw.panel(ctx, x1, y, x1 + w, y + h, 7, a);
            // pulsing snowflake-ish dot
            float pulse = 0.55f + 0.45f * (float) Math.sin(t * 2.2);
            int dx = x1 + 11, dy = y + h / 2;
            Draw.sparkle(ctx, dx, dy, 3, ThemeManager.primary(), (0.6f + 0.4f * pulse) * a);
            Fonts.shimmer(ctx, TEXT, x1 + 20, y + 7, (float) t, a);
            int sepX = x1 + 20 + nameW + 5;
            ctx.fill(sepX, y + 6, sepX + 1, y + h - 6, Draw.col(0xFFFFFF, 0.16f * a));
            Fonts.draw(ctx, sub, sepX + 6, y + 7, ThemeManager.MUTED, a);
            // thin travelling highlight along the bottom edge
            int span = w - 16;
            int hx = x1 + 8 + (int) ((t * 0.35 % 1.0) * span);
            for (int i = -14; i <= 14; i++) {
                int px = hx + i;
                if (px < x1 + 8 || px > x1 + 8 + span) continue;
                ctx.fill(px, y + h - 2, px + 1, y + h - 1, Draw.col(0xFFFFFF, (1f - Math.abs(i) / 14f) * 0.55f * a));
            }
            return y + h + 6;
        }
        Fonts.drawBoldGlow(ctx, TEXT, 10, y + 3, ThemeManager.primary(), a);
        Fonts.draw(ctx, sub, 10 + nameW + 7, y + 3, ThemeManager.MUTED, a);
        return y + 16 + 4;
    }
}
