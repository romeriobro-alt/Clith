package dev.clith.module;

import dev.clith.gui.Draw;
import dev.clith.module.setting.ModeSetting;
import dev.clith.module.setting.SliderSetting;
import dev.clith.render.Gfx;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Movement trail: gradient ribbon, flat traces, or animated soap bubbles. */
public class Trails extends Module implements WorldEffect {
    public final ModeSetting color = add(new ModeSetting("Цвет", 1, Gfx.COLOR_MODES));
    public final ModeSetting style = add(new ModeSetting("Стиль", 2, "Лента", "Следы", "Пузыри"));
    public final SliderSetting length = add(new SliderSetting("Длина, с", 1.5, 0.5, 4.0, 0.1));
    public final SliderSetting height = add(new SliderSetting("Высота", 1.3, 0.1, 2.2, 0.05));
    public final SliderSetting thick = add(new SliderSetting("Ширина ленты", 0.5, 0.1, 1.4, 0.05));
    public final SliderSetting bubbleSize = add(new SliderSetting("Размер пузырьков", 1.0, 0.45, 1.8, 0.05));

    private record Point(double x, double y, double z, double t) {}
    private record Bubble(double x, double y, double z, double vx, double vy, double vz,
                          double born, double life, double size, double rot, float hue) {}

    private final List<Point> points = new ArrayList<>();
    private final List<Bubble> bubbles = new ArrayList<>();
    private final Random random = new Random();
    private Vec3d lastPos;
    private double lastBubbleAt;

    public Trails() {
        super("Trails", "trails", GLFW.GLFW_KEY_UNKNOWN, Category.VISUAL, "Градиентный шлейф и анимированные пузыри за игроком");
    }

    @Override
    public void onDisable() {
        points.clear();
        bubbles.clear();
        lastPos = null;
        lastBubbleAt = 0;
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        Vec3d p = mc.player.getPos();
        double now = Gfx.now();
        Vec3d prev = lastPos;
        if (prev == null) {
            points.add(new Point(p.x, p.y, p.z, now));
            lastPos = p;
            return;
        }

        double dx = p.x - prev.x, dy = p.y - prev.y, dz = p.z - prev.z;
        double distSq = dx * dx + dy * dy + dz * dz;
        if (distSq > 0.0009) points.add(new Point(p.x, p.y, p.z, now));

        // Spawn bubbles only while moving. Their independent lifetime and velocity make them rise,
        // wobble, grow a little and fade rather than looking like static circles on a line.
        if (style.index() == 2 && distSq > 0.0004 && now - lastBubbleAt >= 0.045) {
            lastBubbleAt = now;
            spawnBubble(p, now);
            if (random.nextFloat() < 0.32f) spawnBubble(p.add((random.nextDouble() - 0.5) * 0.35, 0.18, (random.nextDouble() - 0.5) * 0.35), now);
        }
        lastPos = p;
        if (points.size() > 400) points.remove(0);
        if (bubbles.size() > 180) bubbles.subList(0, bubbles.size() - 180).clear();
    }

    private void spawnBubble(Vec3d p, double now) {
        double life = length.get() * (0.8 + random.nextDouble() * 0.35);
        double size = (0.065 + random.nextDouble() * 0.055) * bubbleSize.get();
        bubbles.add(new Bubble(
                p.x + (random.nextDouble() - 0.5) * 0.34,
                p.y + 0.18 + random.nextDouble() * 0.78,
                p.z + (random.nextDouble() - 0.5) * 0.34,
                (random.nextDouble() - 0.5) * 0.11,
                0.20 + random.nextDouble() * 0.24,
                (random.nextDouble() - 0.5) * 0.11,
                now, life, size, random.nextDouble() * Math.PI * 2, random.nextFloat()));
    }

    @Override
    public void renderWorld(Gfx g, float tickDelta, double now) {
        if (mc.player == null) return;
        double life = length.get();
        points.removeIf(pt -> now - pt.t() > life);

        if (style.index() == 2) {
            renderBubbles(g, now);
            return;
        }
        if (points.isEmpty()) return;
        Vec3d cur = mc.player.getLerpedPos(tickDelta);
        int n = points.size();
        int mode = color.index();
        boolean flat = style.index() == 1;
        double h = height.get();
        double tw = thick.get();
        for (int i = 0; i < n; i++) {
            Point a = points.get(i);
            double bx, by, bz, bt;
            if (i + 1 < n) { Point b = points.get(i + 1); bx = b.x(); by = b.y(); bz = b.z(); bt = b.t(); }
            else { bx = cur.x; by = cur.y; bz = cur.z; bt = now; }
            float fa = (float) Math.max(0, 1.0 - (now - a.t()) / life);
            float fb = (float) Math.max(0, 1.0 - (now - bt) / life);
            int ca = Gfx.color(mode, (float) (i * 0.04 + now * 0.15));
            int cb = Gfx.color(mode, (float) ((i + 1) * 0.04 + now * 0.15));
            if (!flat) {
                double lo = h - tw / 2, hi = h + tw / 2, e = Math.min(0.04, tw * 0.12);
                float oa = fa * 0.95f, ob = fb * 0.95f;
                g.v(a.x(), a.y() + lo, a.z(), ca, 0f);
                g.v(bx, by + lo, bz, cb, 0f);
                g.v(bx, by + lo + e, bz, cb, ob);
                g.v(a.x(), a.y() + lo + e, a.z(), ca, oa);
                g.v(a.x(), a.y() + lo + e, a.z(), ca, oa);
                g.v(bx, by + lo + e, bz, cb, ob);
                g.v(bx, by + hi - e, bz, cb, ob);
                g.v(a.x(), a.y() + hi - e, a.z(), ca, oa);
                g.v(a.x(), a.y() + hi - e, a.z(), ca, oa);
                g.v(bx, by + hi - e, bz, cb, ob);
                g.v(bx, by + hi, bz, cb, 0f);
                g.v(a.x(), a.y() + hi, a.z(), ca, 0f);
            } else {
                double dx = bx - a.x(), dz = bz - a.z();
                double len = Math.sqrt(dx * dx + dz * dz);
                if (len < 1e-4) continue;
                double px = -dz / len * 0.17, pz = dx / len * 0.17;
                g.v(a.x() - px, a.y() + 0.03, a.z() - pz, ca, fa * 0.9f);
                g.v(a.x() + px, a.y() + 0.03, a.z() + pz, ca, fa * 0.9f);
                g.v(bx + px, by + 0.03, bz + pz, cb, fb * 0.9f);
                g.v(bx - px, by + 0.03, bz - pz, cb, fb * 0.9f);
            }
        }
    }

    private void renderBubbles(Gfx g, double now) {
        bubbles.removeIf(b -> now - b.born() >= b.life());
        int mode = color.index();
        for (Bubble b : bubbles) {
            double age = now - b.born();
            float k = (float) (age / b.life());
            float appear = Draw.smooth((float) (age / 0.10));
            float vanish = 1f - Draw.smooth((k - 0.42f) / 0.58f);
            float alpha = appear * vanish * 0.92f;
            if (alpha < 0.015f) continue;

            double x = b.x() + b.vx() * age + Math.sin(age * 2.6 + b.rot()) * 0.018;
            double y = b.y() + b.vy() * age + Math.sin(age * 3.4 + b.rot()) * 0.025;
            double z = b.z() + b.vz() * age + Math.cos(age * 2.2 + b.rot()) * 0.018;
            double breathe = 0.86 + 0.15 * Math.sin(age * 4.4 + b.rot());
            double radius = b.size() * (0.92 + 0.28 * k) * breathe;
            float hue = (float) (b.hue() + age * 0.065);
            int c = Gfx.color(mode, hue);

            g.glow(x, y, z, radius * 1.8, c, alpha * 0.17f);
            g.bubble(x, y, z, radius, b.rot() + age * 0.65, mode, hue, alpha);
        }
    }
}
