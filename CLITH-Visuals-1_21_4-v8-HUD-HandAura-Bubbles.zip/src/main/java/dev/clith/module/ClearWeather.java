package dev.clith.module;

import org.lwjgl.glfw.GLFW;

public class ClearWeather extends Module {
    public ClearWeather() {
        super("Clear Weather", "clearweather", GLFW.GLFW_KEY_UNKNOWN, Category.VISUAL, "Убирает дождь и грозу (только у тебя на экране)");
    }

    @Override
    public void onTick() {
        if (mc.world == null) return;
        mc.world.setRainGradient(0f);
        mc.world.setThunderGradient(0f);
    }
}
