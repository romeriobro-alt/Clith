package dev.clith.module;

import dev.clith.module.setting.Setting;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    public final String name;
    public final String id;
    public final String description;
    public final Category category;
    public final KeyBinding key;
    public final List<Setting> settings = new ArrayList<>();

    /** Show this module in the on-screen module list. */
    public boolean listed = true;
    private boolean enabled;

    protected Module(String name, String id, int glfwKey, Category category, String description) {
        this.name = name;
        this.id = id;
        this.category = category;
        this.description = description;
        this.key = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.clith." + id, InputUtil.Type.KEYSYM, glfwKey, "category.clith"));
    }

    protected <T extends Setting> T add(T setting) {
        setting.owner = this;
        settings.add(setting);
        return setting;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    /** Called every client tick to read the keybind. Default: press to toggle. */
    public void handleKey() {
        while (key.wasPressed()) toggle();
    }

    /** Short gray text after the name in the module list (e.g. current mode). */
    public String suffix() {
        return null;
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    public void onSettingChanged() {}
}
