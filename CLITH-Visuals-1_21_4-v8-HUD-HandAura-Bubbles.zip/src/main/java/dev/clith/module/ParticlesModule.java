package dev.clith.module;

import dev.clith.gui.Draw;
import dev.clith.module.setting.BoolSetting;
import dev.clith.module.setting.ColorSetting;
import dev.clith.module.setting.ModeSetting;
import dev.clith.module.setting.SliderSetting;
import dev.clith.render.Gfx;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Soft glowing world particles (stars, snowflakes, hearts, orbs, diamonds, rings and soap bubbles) that float around the
 * player, trail behind them or orbit as an aura. They are drawn by CLITH itself, not by the vanilla
 * particle system, so the colour is a free palette and nothing is limited by vanilla sprites.
 */
public class ParticlesModule extends Module implements WorldEffect {
    private static final int SHAPES = 7;

    public final ModeSetting style = add(new ModeSetting("Режим", 1, "Вокруг", "Шлейф", "Аура", "Вокруг + Шлейф"));
    public final ModeSetting shape = add(new ModeSetting("Форма", 6,
            "Свечение", "Звёзды", "Снежинки", "Сердца", "Ромбы", "Кольца", "Мыльные пузыри", "Микс"));
    public final ModeSetting motion = add(new ModeSetting("Движение", 0, "Парение", "Падение", "Подъём", "Вихрь"));
    public final ModeSetting paint = add(new ModeSetting("Окраска", 1, "Один цвет", "Градиент", "Радуга", "Тема"));
    public final ColorSetting color1 = add(new ColorSetting("Палитра", 0x9BE7FF));
    public final ColorSetting color2 = add(new ColorSetting("Палитра 2", 0xC4A5FF));
    public final SliderSetting amount = add(new SliderSetting("Количество", 80, 10, 300, 5));
    public final SliderSetting size = add(new SliderSetting("Размер", 1.0, 0.3, 3.0, 0.1));
    public final SliderSetting speed = add(new SliderSetting("Скорость", 1.0, 0.2, 3.0, 0.1));
    public final SliderSetting range = add(new SliderSetting("Радиус, блоки", 10, 3, 24, 1));
    public final SliderSetting glow = add(new SliderSetting("Свечение", 0.9, 0.0, 1.5, 0.05));
    public final BoolSetting twinkle = add(new BoolSetting("Мерцание", true));

    private static final class P {
        double x, y, z;          // world position (ignored while follow is true)
        double vx, vy, vz;
        boolean follow;          // orbits the player (aura)
        double ang, rad, yOff, omega;
        float age, life, size, rot, rotSpeed, tone, phase;
        int shape;
    }

    private final List<P> list = new ArrayList<>();
    private final Random rnd = new Random();
    private double ambientAcc, trailAcc, auraAcc;
    private Vec3d lastPos;

    public ParticlesModule() {
        super("Particles", "particles", GLFW.GLFW_KEY_P, Category.VISUAL, "Красивые светящиеся частицы в мире: цвет выбирается палитрой");
    }

    @Override
    public String suffix() {
        return shape.get();
    }

    @Override
    public void onDisable() {
        list.clear();
        lastPos = null;
    }

    @Override
    public void renderWorld(Gfx g, float tickDelta, double now) {
        if (mc.player == null || mc.world == null) return;
        Vec3d pl = mc.player.getLerpedPos(tickDelta);
        float dt = g.dt;
        float sp = (float) speed.get();

        spawn(pl, dt, sp);
        update(pl, dt, sp);

        boolean tw = twinkle.get();
        float gl = (float) glow.get();
        double camX = g.cx, camY = g.cy, camZ = g.cz;
        double rng = range.get();
        for (P p : list) {
            double x, y, z;
            if (p.follow) {
                x = pl.x + Math.cos(p.ang) * p.rad;
                z = pl.z + Math.sin(p.ang) * p.rad;
                y = pl.y + p.yOff;
            } else {
                x = p.x; y = p.y; z = p.z;
            }
            double dx = x - camX, dy = y - camY, dz = z - camZ;
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

            float fadeIn = Draw.smooth(p.age / 0.6f);
            float fadeOut = Draw.smooth((p.life - p.age) / Math.max(0.4f, p.life * 0.4f));
            float near = Draw.smooth((float) ((dist - 0.7) / 1.8));
            float far = 1f - Draw.smooth((float) ((dist - rng * 0.7) / Math.max(1.0, rng * 0.3)));
            float a = fadeIn * fadeOut * near * far;
            if (a < 0.01f) continue;
            if (tw) a *= 0.72f + 0.28f * (float) Math.sin(now * (2.4 + p.tone * 3.0) + p.phase);

            float pop = 0.55f + 0.45f * Draw.back(p.age / 0.5f);
            double s = 0.075 * size.get() * p.size * pop;
            int c = pickColor(p, now);
            int core = Draw.lerp(c, 0xFFFFFF, 0.6f);

            if (gl > 0.01f) g.glow(x, y, z, s * 3.0, c, Math.min(1f, a * 0.34f * gl));
            switch (p.shape) {
                case 0 -> {
                    g.glow(x, y, z, s * 1.5, c, Math.min(1f, a * 0.9f));
                    g.glow(x, y, z, s * 0.65, core, a);
                }
                case 1 -> {
                    g.sparkle(x, y, z, s * 2.2, p.rot, c, a);
                    g.sparkle(x, y, z, s * 1.0, p.rot + Math.PI / 4, core, a * 0.9f);
                }
                case 2 -> {
                    g.snowflake(x, y, z, s * 1.9, p.rot, core, a);
                    g.glow(x, y, z, s * 0.5, c, a * 0.8f);
                }
                case 3 -> {
                    g.heart(x, y, z, s * 1.5, 0.25 * Math.sin(now * 1.5 + p.phase), c, a * 0.95f);
                    g.heart(x - 0.12 * s, y + 0.18 * s, z, s * 0.5, 0.25 * Math.sin(now * 1.5 + p.phase), core, a * 0.7f);
                }
                case 4 -> {
                    g.billboard(x, y, z, s * 0.95, p.rot + Math.PI / 4, c, a * 0.9f);
                    g.billboard(x, y, z, s * 0.42, p.rot + Math.PI / 4, core, a);
                }
                case 5 -> {
                    g.billboardRing(x, y, z, s * 0.95, s * 1.4, 18, c, a * 0.95f, a * 0.35f);
                    g.glow(x, y, z, s * 0.45, core, a * 0.8f);
                }
                case 6 -> {
                    double breathe = 0.88 + 0.12 * Math.sin(now * 4.0 + p.phase);
                    g.glow(x, y, z, s * 1.55 * breathe, c, a * 0.18f);
                    g.bubble(x, y, z, s * 1.2 * breathe, p.rot + p.age * 0.45, c, core, a);
                }
            }
        }
    }

    // ------------------------------------------------------------------ colour

    private int pickColor(P p, double now) {
        switch (paint.index()) {
            case 0:
                return Draw.lerp(color1.rgb(), 0xFFFFFF, p.tone * 0.22f);
            case 1: {
                float k = 0.5f + 0.5f * (float) Math.sin(p.tone * 6.2832f + now * 0.8);
                return Draw.lerp(color1.rgb(), color2.rgb(), k);
            }
            case 2:
                return MathHelper.hsvToRgb((float) ((p.tone + now * 0.08) % 1.0), 0.55f, 1f) & 0xFFFFFF;
            default:
                return Gfx.color(0, (float) (p.tone + now * 0.1));
        }
    }

    // ------------------------------------------------------------------ simulation

    private int cap() {
        int base = amount.getInt();
        if (Optimization.liteSky()) base = Math.max(10, base * 2 / 3);
        return Math.min(base * 2 + 40, 700);
    }

    private P make(float life) {
        P p = new P();
        p.life = life;
        p.size = 0.65f + rnd.nextFloat() * 0.9f;
        p.rot = rnd.nextFloat() * 6.2832f;
        p.rotSpeed = (rnd.nextFloat() - 0.5f) * 1.6f;
        p.tone = rnd.nextFloat();
        p.phase = rnd.nextFloat() * 6.2832f;
        p.shape = shape.index() == SHAPES ? rnd.nextInt(SHAPES) : shape.index();
        return p;
    }

    private void spawn(Vec3d pl, float dt, float sp) {
        int mode = style.index();
        int limit = cap();
        int target = amount.getInt();
        boolean around = mode == 0 || mode == 3;
        boolean trail = mode == 1 || mode == 3;
        boolean aura = mode == 2;

        if (around) {
            ambientAcc += dt * target / 5.5;           // keeps roughly "amount" particles alive
            int guard = 0;
            while (ambientAcc >= 1.0 && guard++ < 12) {
                ambientAcc -= 1.0;
                if (list.size() >= limit) break;
                double r = range.get() * Math.sqrt(rnd.nextDouble());
                double a = rnd.nextDouble() * Math.PI * 2;
                P p = make((3.5f + rnd.nextFloat() * 4.5f) / (0.6f + 0.4f * sp));
                p.x = pl.x + Math.cos(a) * r;
                p.z = pl.z + Math.sin(a) * r;
                double fallStart = motion.index() == 1 ? 1.0 + rnd.nextDouble() * 7.0 : -1.0 + rnd.nextDouble() * 6.5;
                p.y = pl.y + fallStart;
                double w = 0.25 * sp;
                p.vx = (rnd.nextDouble() - 0.5) * w;
                p.vz = (rnd.nextDouble() - 0.5) * w;
                switch (motion.index()) {
                    case 1 -> p.vy = -(0.45 + rnd.nextDouble() * 0.5) * sp;
                    case 2 -> p.vy = (0.25 + rnd.nextDouble() * 0.45) * sp;
                    default -> p.vy = (rnd.nextDouble() - 0.45) * 0.12 * sp;
                }
                list.add(p);
            }
        }

        if (trail) {
            boolean moving = lastPos != null && lastPos.squaredDistanceTo(pl) > 0.0004;
            if (moving) trailAcc += dt * target * 0.45; else trailAcc = Math.min(trailAcc, 1.0);
            int guard = 0;
            while (trailAcc >= 1.0 && guard++ < 10) {
                trailAcc -= 1.0;
                if (list.size() >= limit) break;
                P p = make((1.0f + rnd.nextFloat() * 1.1f) / (0.6f + 0.4f * sp));
                p.size *= 1.15f;
                p.x = pl.x + (rnd.nextDouble() - 0.5) * 0.7;
                p.y = pl.y + 0.05 + rnd.nextDouble() * 0.5;
                p.z = pl.z + (rnd.nextDouble() - 0.5) * 0.7;
                p.vx = (rnd.nextDouble() - 0.5) * 0.35;
                p.vz = (rnd.nextDouble() - 0.5) * 0.35;
                p.vy = (0.18 + rnd.nextDouble() * 0.4) * sp;
                list.add(p);
            }
        }

        if (aura) {
            auraAcc += dt * target * 0.35;
            int guard = 0;
            double h = mc.player.getHeight();
            while (auraAcc >= 1.0 && guard++ < 10) {
                auraAcc -= 1.0;
                if (list.size() >= limit) break;
                P p = make((2.2f + rnd.nextFloat() * 1.8f) / (0.6f + 0.4f * sp));
                p.follow = true;
                p.ang = rnd.nextDouble() * Math.PI * 2;
                p.rad = 0.65 + rnd.nextDouble() * 0.55;
                p.yOff = rnd.nextDouble() * h;
                p.omega = (1.2 + rnd.nextDouble() * 1.2) * sp * (motion.index() == 1 ? -1 : 1);
                p.vy = (motion.index() == 1 ? -0.35 : 0.3 + rnd.nextDouble() * 0.35) * sp;
                list.add(p);
            }
        }
        lastPos = pl;
    }

    private void update(Vec3d pl, float dt, float sp) {
        boolean swirl = motion.index() == 3;
        for (int i = list.size() - 1; i >= 0; i--) {
            P p = list.get(i);
            p.age += dt;
            if (p.age >= p.life) { list.remove(i); continue; }
            p.rot += p.rotSpeed * dt;
            if (p.follow) {
                p.ang += p.omega * dt;
                p.yOff += p.vy * dt;
                continue;
            }
            // gentle wandering so the motion never looks mechanical
            double w = Math.sin(p.age * 1.7 + p.phase) * 0.18 * sp;
            p.x += (p.vx + w * 0.6) * dt;
            p.z += (p.vz + Math.cos(p.age * 1.3 + p.phase) * 0.18 * sp * 0.6) * dt;
            p.y += (p.vy + Math.sin(p.age * 1.1 + p.phase * 2.0) * 0.05 * sp) * dt;
            if (swirl) {
                double dx = p.x - pl.x, dz = p.z - pl.z;
                double ang = 0.6 * sp * dt;
                double ca = Math.cos(ang), sa = Math.sin(ang);
                p.x = pl.x + dx * ca - dz * sa;
                p.z = pl.z + dx * sa + dz * ca;
            }
        }
        if (list.size() > cap() + 40) list.subList(0, list.size() - cap()).clear();
    }
}
