package dev.clith.module.setting;

public class SliderSetting extends Setting {
    public final double min, max, step;
    private double value;

    public SliderSetting(String name, double value, double min, double max, double step) {
        super(name);
        this.value = value;
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public double get() {
        return value;
    }

    public int getInt() {
        return (int) Math.round(value);
    }

    public float fraction() {
        return (float) ((value - min) / (max - min));
    }

    public void set(double v) {
        v = Math.max(min, Math.min(max, v));
        if (step > 0) v = Math.round(v / step) * step;
        v = Math.max(min, Math.min(max, v));
        if (v == value) return;
        value = v;
        changed();
    }

    public void setFraction(float f) {
        set(min + (max - min) * Math.max(0f, Math.min(1f, f)));
    }

    public String display() {
        return step >= 1 ? String.valueOf((int) Math.round(value)) : String.format("%.1f", value);
    }

    @Override
    public String save() {
        return String.valueOf(value);
    }

    @Override
    public void load(String s) {
        try {
            double v = Double.parseDouble(s.trim());
            value = Math.max(min, Math.min(max, v));
        } catch (NumberFormatException ignored) {
        }
    }
}
