package dev.clith.module.setting;

import net.minecraft.util.math.MathHelper;

/** Free colour picked from a palette (hue strip + saturation/brightness square). Stored as RRGGBB hex. */
public class ColorSetting extends Setting {
    private float h, s, v;

    public ColorSetting(String name, int rgb) {
        super(name);
        fromRgb(rgb);
    }

    public int rgb() {
        return MathHelper.hsvToRgb(h, s, v) & 0xFFFFFF;
    }

    public float hue() { return h; }
    public float sat() { return s; }
    public float val() { return v; }

    public void setHue(float nh) {
        nh = MathHelper.clamp(nh, 0f, 0.9999f);
        if (nh == h) return;
        h = nh;
        changed();
    }

    public void setSV(float ns, float nv) {
        ns = MathHelper.clamp(ns, 0f, 1f);
        nv = MathHelper.clamp(nv, 0f, 1f);
        if (ns == s && nv == v) return;
        s = ns;
        v = nv;
        changed();
    }

    private void fromRgb(int rgb) {
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        float d = max - min;
        v = max;
        s = max <= 0f ? 0f : d / max;
        if (d <= 1.0e-5f) {
            // grey: keep the previous hue so the hue strip does not jump
        } else if (max == r) {
            h = ((g - b) / d / 6f + 1f) % 1f;
        } else if (max == g) {
            h = ((b - r) / d + 2f) / 6f;
        } else {
            h = ((r - g) / d + 4f) / 6f;
        }
    }

    @Override
    public String save() {
        return String.format("%06X", rgb());
    }

    @Override
    public void load(String str) {
        try {
            fromRgb(Integer.parseInt(str.trim().replace("#", ""), 16) & 0xFFFFFF);
        } catch (NumberFormatException ignored) {
        }
    }
}
