package dev.clith.module.setting;

import dev.clith.module.Module;

public abstract class Setting {
    public final String name;
    public Module owner;

    protected Setting(String name) {
        this.name = name;
    }

    protected void changed() {
        if (owner != null) owner.onSettingChanged();
    }

    /** Value as text for the config file. */
    public abstract String save();

    public abstract void load(String s);
}
