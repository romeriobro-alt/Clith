package dev.clith.module.setting;

public class ModeSetting extends Setting {
    public final String[] modes;
    private int index;

    public ModeSetting(String name, int defaultIndex, String... modes) {
        super(name);
        this.modes = modes;
        this.index = defaultIndex;
    }

    public int index() {
        return index;
    }

    public String get() {
        return modes[index];
    }

    public void set(int i) {
        int n = modes.length;
        i = ((i % n) + n) % n;
        if (i == index) return;
        index = i;
        changed();
    }

    public void next() {
        set(index + 1);
    }

    public void prev() {
        set(index - 1);
    }

    @Override
    public String save() {
        return String.valueOf(index);
    }

    @Override
    public void load(String s) {
        try {
            int i = Integer.parseInt(s.trim());
            if (i >= 0 && i < modes.length) index = i;
        } catch (NumberFormatException ignored) {
        }
    }
}
