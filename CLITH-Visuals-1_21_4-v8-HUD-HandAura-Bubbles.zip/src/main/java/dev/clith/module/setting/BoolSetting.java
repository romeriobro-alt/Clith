package dev.clith.module.setting;

public class BoolSetting extends Setting {
    private boolean value;

    public BoolSetting(String name, boolean value) {
        super(name);
        this.value = value;
    }

    public boolean get() {
        return value;
    }

    public void toggle() {
        value = !value;
        changed();
    }

    @Override
    public String save() {
        return String.valueOf(value);
    }

    @Override
    public void load(String s) {
        value = Boolean.parseBoolean(s.trim());
    }
}
