package dev.clith.module;

import org.lwjgl.glfw.GLFW;

public class ToggleSprint extends Module {
    public ToggleSprint() {
        super("Toggle Sprint", "togglesprint", GLFW.GLFW_KEY_UNKNOWN, Category.PLAYER, "Автоматически бежишь, пока идёшь вперёд");
    }

    @Override
    public void onDisable() {
        if (mc.options != null) mc.options.sprintKey.setPressed(false);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.currentScreen != null) return;
        if (mc.options.forwardKey.isPressed() && !mc.player.isSneaking()) {
            mc.options.sprintKey.setPressed(true);
        }
    }
}
