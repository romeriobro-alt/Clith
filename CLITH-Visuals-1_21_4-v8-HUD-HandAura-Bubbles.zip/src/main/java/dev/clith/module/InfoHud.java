package dev.clith.module;

import dev.clith.module.setting.BoolSetting;
import org.lwjgl.glfw.GLFW;

/** FPS / coordinates overlay (drawn by HudRenderer). */
public class InfoHud extends Module {
    public final BoolSetting showFps = add(new BoolSetting("FPS", true));
    public final BoolSetting showCoords = add(new BoolSetting("Координаты", true));
    public final BoolSetting showDirection = add(new BoolSetting("Направление", true));

    public InfoHud() {
        super("Info HUD", "hud", GLFW.GLFW_KEY_H, Category.HUD, "FPS, координаты и направление");
        listed = false;
    }
}
