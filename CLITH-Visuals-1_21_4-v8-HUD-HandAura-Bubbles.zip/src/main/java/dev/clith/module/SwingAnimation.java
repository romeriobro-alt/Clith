package dev.clith.module;

import dev.clith.module.setting.ModeSetting;
import dev.clith.module.setting.SliderSetting;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.lwjgl.glfw.GLFW;

/** Custom first-person swing and item position. The hook lives in HeldItemRendererMixin. */
public class SwingAnimation extends Module {
    public static SwingAnimation instance;

    public final ModeSetting style = add(new ModeSetting("Стиль", 0, "Слэш", "Толчок", "Круг", "Удар сверху"));
    public final SliderSetting power = add(new SliderSetting("Сила", 1.0, 0.3, 2.0, 0.1));
    public final SliderSetting scale = add(new SliderSetting("Размер предмета", 1.0, 0.5, 1.5, 0.05));
    public final SliderSetting offX = add(new SliderSetting("Смещение X", 0.0, -0.5, 0.5, 0.05));
    public final SliderSetting offY = add(new SliderSetting("Смещение Y", 0.0, -0.5, 0.5, 0.05));

    public SwingAnimation() {
        super("Swing Animation", "swinganim", GLFW.GLFW_KEY_UNKNOWN, Category.VISUAL, "Другая анимация удара и положение руки");
        instance = this;
    }

    public void apply(MatrixStack m, float sp) {
        float k = (float) power.get();
        float sc = (float) scale.get();
        m.translate((float) offX.get(), (float) offY.get(), 0f);
        m.scale(sc, sc, sc);
        if (sp <= 0f) return;
        float s = MathHelper.sin(sp * (float) Math.PI);
        float s2 = MathHelper.sin(MathHelper.sqrt(sp) * (float) Math.PI);
        switch (style.index()) {
            case 0 -> {
                m.translate(0f, -0.12f * s * k, 0f);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-65f * s * k));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-30f * s2 * k));
            }
            case 1 -> {
                m.translate(0f, 0f, -0.85f * s * k);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(15f * s * k));
            }
            case 2 -> m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(360f * sp * Math.min(k, 1f)));
            default -> {
                m.translate(0.15f * s * k, -0.35f * s * k, -0.25f * s * k);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-80f * s * k));
            }
        }
    }
}
