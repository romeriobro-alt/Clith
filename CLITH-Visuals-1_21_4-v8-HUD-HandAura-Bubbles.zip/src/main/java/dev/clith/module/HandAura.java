package dev.clith.module;

import dev.clith.gui.Draw;
import dev.clith.gui.ThemeManager;
import dev.clith.module.setting.BoolSetting;
import dev.clith.module.setting.ModeSetting;
import dev.clith.module.setting.SliderSetting;
import dev.clith.render.Gfx;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

/** Animated multicolour energy halo around the first-person hand area. */
public final class HandAura extends Module {
    public final ModeSetting palette = add(new ModeSetting("Палитра", 1, Gfx.COLOR_MODES));
    public final SliderSetting size = add(new SliderSetting("Размер", 1.0, 0.65, 1.45, 0.05));
    public final SliderSetting intensity = add(new SliderSetting("Яркость", 0.9, 0.25, 1.4, 0.05));
    public final BoolSetting pulse = add(new BoolSetting("Пульсация", true));
    public final BoolSetting sparkles = add(new BoolSetting("Искры", true));

    public HandAura() {
        super("Hand Aura", "handaura", GLFW.GLFW_KEY_UNKNOWN, Category.VISUAL,
                "Пульсирующая цветная аура вокруг руки от первого лица");
    }

    public void draw(DrawContext ctx) {
        if (!isEnabled() || mc.player == null || mc.options.hudHidden || !mc.options.getPerspective().isFirstPerson()) return;
        double time = Gfx.now();
        float sizeScale = (float) size.get();
        float pulseScale = pulse.get() ? 1f + 0.045f * (float) Math.sin(time * 3.2) : 1f;
        float brightness = (float) intensity.get() * (pulse.get() ? 0.78f + 0.22f * (float) Math.sin(time * 3.2 + 0.8) : 1f);
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();

        // The arm enters from the lower-right in first person; the lower half of these arcs
        // intentionally extends off-screen, leaving a luminous crescent around the visible fist.
        double rx = Math.min(238, sw * 0.16) * sizeScale * pulseScale;
        double ry = Math.min(286, sh * 0.32) * sizeScale * pulseScale;
        double cx = sw - rx * 0.92;
        double cy = sh + ry * 0.18;
        arc(ctx, cx, cy, rx, ry, -171, -8, time, -0.02, 9, brightness * 0.095f);
        arc(ctx, cx, cy, rx, ry, -171, -8, time, -0.02, 5, brightness * 0.25f);
        arc(ctx, cx, cy, rx, ry, -171, -8, time, -0.02, 2, brightness * 0.9f);

        double innerRx = rx * 0.79;
        double innerRy = ry * 0.79;
        arc(ctx, cx, cy, innerRx, innerRy, -153, -28, time, 0.46, 5, brightness * 0.12f);
        arc(ctx, cx, cy, innerRx, innerRy, -153, -28, time, 0.46, 2, brightness * 0.62f);

        if (sparkles.get()) {
            for (int i = 0; i < 7; i++) {
                double k = (i / 6.0 + time * 0.055) % 1.0;
                double angle = Math.toRadians(-164 + 150 * k);
                double wobble = 1.0 + 0.035 * Math.sin(time * 3.5 + i * 1.7);
                int x = (int) Math.round(cx + Math.cos(angle) * rx * wobble);
                int y = (int) Math.round(cy + Math.sin(angle) * ry * wobble);
                int c = Gfx.color(palette.index(), (float) (k + time * 0.09));
                float a = brightness * (0.38f + 0.45f * (float) (0.5 + 0.5 * Math.sin(time * 4.3 + i)));
                Draw.sparkle(ctx, x, y, 2 + (i % 3), c, a);
            }
        }
        // A tiny theme-coloured glint ties the HUD effect into the currently selected client theme.
        Draw.sparkle(ctx, sw - 118, sh - 73, 2, ThemeManager.secondary(), brightness * 0.45f);
    }

    private void arc(DrawContext ctx, double cx, double cy, double rx, double ry,
                     double startDeg, double endDeg, double time, double hueOffset, int thickness, float alpha) {
        int steps = 84;
        double px = 0, py = 0;
        int pc = Gfx.color(palette.index(), (float) hueOffset);
        boolean first = true;
        for (int i = 0; i <= steps; i++) {
            double k = i / (double) steps;
            double angle = Math.toRadians(startDeg + (endDeg - startDeg) * k);
            double ripple = pulse.get() ? 1.0 + 0.018 * Math.sin(time * 4.2 + k * 9.0) : 1.0;
            double x = cx + Math.cos(angle) * rx * ripple;
            double y = cy + Math.sin(angle) * ry * ripple;
            int c = Gfx.color(palette.index(), (float) (hueOffset + k * 0.48 + time * 0.085));
            if (!first) line(ctx, px, py, x, y, pc, c, thickness, alpha);
            px = x;
            py = y;
            pc = c;
            first = false;
        }
    }

    private static void line(DrawContext ctx, double x0, double y0, double x1, double y1,
                             int c0, int c1, int thickness, float alpha) {
        int steps = Math.max(1, (int) Math.ceil(Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0))));
        int half = Math.max(0, thickness / 2);
        for (int i = 0; i <= steps; i++) {
            float t = i / (float) steps;
            int x = (int) Math.round(x0 + (x1 - x0) * t);
            int y = (int) Math.round(y0 + (y1 - y0) * t);
            int c = Draw.lerp(c0, c1, t);
            ctx.fill(x - half, y - half, x + half + 1, y + half + 1, Draw.col(c, Draw.clamp01(alpha)));
        }
    }
}
