package dev.clith.module;

import dev.clith.Config;
import dev.clith.gui.ClickGui;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final List<Module> MODULES = new ArrayList<>();
    public static InfoHud infoHud;
    public static ModuleListHud moduleListHud;
    public static Keystrokes keystrokes;
    public static Watermark watermark;
    public static ArmorHud armorHud;
    public static HitEffects hitEffects;
    public static StatusHud statusHud;
    public static HandAura handAura;
    public static KeyBinding guiKey;

    public static void init() {
        // Right Shift opens the Clith menu
        guiKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.clith.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.clith"));

        infoHud = new InfoHud();
        moduleListHud = new ModuleListHud();
        keystrokes = new Keystrokes();
        watermark = new Watermark();
        armorHud = new ArmorHud();
        hitEffects = new HitEffects();
        statusHud = new StatusHud();
        handAura = new HandAura();

        // Visual
        SkyModule sky = new SkyModule();
        MODULES.add(sky);
        sky.setEnabled(true); // the animated Aurora sky replaces vanilla sky by default
        MODULES.add(new ParticlesModule());
        MODULES.add(new Fullbright());
        MODULES.add(new Zoom());
        MODULES.add(new ClearWeather());
        MODULES.add(new JumpCircles());
        MODULES.add(new TargetEsp());
        Trails trails = new Trails();
        MODULES.add(trails);
        MODULES.add(hitEffects);
        MODULES.add(handAura);
        MODULES.add(new BlockOutlineFx());
        MODULES.add(new CustomFog());
        MODULES.add(new SwingAnimation());
        // Performance
        MODULES.add(new Optimization());
        // HUD
        MODULES.add(infoHud);
        MODULES.add(moduleListHud);
        MODULES.add(keystrokes);
        MODULES.add(watermark);
        MODULES.add(armorHud);
        MODULES.add(statusHud);
        // Player
        MODULES.add(new ToggleSprint());

        // HUD overlays are on by default (the saved config overrides this)
        infoHud.setEnabled(true);
        moduleListHud.setEnabled(true);
        watermark.setEnabled(true);
        statusHud.setEnabled(true);
        handAura.setEnabled(true);
        trails.setEnabled(true);

        // Options are not ready yet during mod init, so the config is applied once the client has started
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> Config.load());
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            Config.save();
            // put the player's own video options / FOV back before options.txt is written
            for (Module m : MODULES) {
                if (m instanceof Optimization || m instanceof Zoom) m.setEnabled(false);
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (guiKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new ClickGui());
            }
            for (Module m : MODULES) {
                m.handleKey();
                if (m.isEnabled()) m.onTick();
            }
        });
    }

    public static List<Module> inCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) if (m.category == c) out.add(m);
        return out;
    }
}
