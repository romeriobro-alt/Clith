package dev.clith.module;

import dev.clith.gui.Draw;
import dev.clith.gui.Fonts;
import dev.clith.gui.ThemeManager;
import dev.clith.module.setting.BoolSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/** Compact top-centre status pill inspired by modern gaming HUDs. */
public final class StatusHud extends Module {
    public final BoolSetting showPlayer = add(new BoolSetting("Ник игрока", true));
    public final BoolSetting showFps = add(new BoolSetting("FPS", true));
    public final BoolSetting showTime = add(new BoolSetting("Время", true));
    public final BoolSetting showPing = add(new BoolSetting("Пинг", true));

    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");

    private record Segment(String text, int color, boolean bold) {}

    public StatusHud() {
        super("Status HUD", "statushud", GLFW.GLFW_KEY_UNKNOWN, Category.HUD,
                "Компактная статус-панель сверху по центру экрана");
        listed = false;
    }

    public void draw(DrawContext ctx, MinecraftClient mc, float alpha) {
        if (!isEnabled() || mc.player == null || mc.options.hudHidden) return;

        List<Segment> segments = new ArrayList<>();
        if (showPlayer.get()) {
            String name = mc.player.getName().getString();
            if (name.length() > 16) name = name.substring(0, 15) + "…";
            segments.add(new Segment(name, ThemeManager.TEXT, true));
        }
        if (showFps.get()) segments.add(new Segment(mc.getCurrentFps() + " FPS", ThemeManager.primary(), true));
        if (showTime.get()) segments.add(new Segment(LocalTime.now().format(CLOCK), ThemeManager.TEXT, false));
        if (showPing.get() && mc.getNetworkHandler() != null) {
            PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (entry != null) segments.add(new Segment(entry.getLatency() + " ms", ThemeManager.secondary(), false));
        }

        double t = ThemeManager.seconds();
        float pulse = 0.7f + 0.3f * (float) Math.sin(t * 2.8);
        int logoW = 22;
        int brandW = Fonts.widthBold("CLITH");
        int contentW = logoW + 8 + brandW + 11;
        for (Segment segment : segments) contentW += 10 + (segment.bold() ? Fonts.widthBold(segment.text()) : Fonts.width(segment.text()));
        int w = contentW + 12;
        int h = 24;
        int x = (ctx.getScaledWindowWidth() - w) / 2;
        int y = 5;

        Draw.halo(ctx, x, y, x + w, y + h, 8, ThemeManager.primary(), alpha * (0.35f + pulse * 0.2f));
        Draw.panel(ctx, x, y, x + w, y + h, 8, alpha * 0.96f);
        Draw.rr(ctx, x + 4, y + 4, x + 22, y + 20, 5, Draw.col(ThemeManager.primary(), 0.25f * alpha));
        Draw.sparkle(ctx, x + 13, y + 12, 4, ThemeManager.primary(), alpha * pulse);
        Fonts.drawBold(ctx, "CLITH", x + logoW + 5, y + 8, ThemeManager.TEXT, alpha);

        int cursor = x + logoW + 8 + brandW + 8;
        ctx.fill(cursor, y + 6, cursor + 1, y + h - 6, Draw.col(0xFFFFFF, 0.16f * alpha));
        cursor += 8;
        for (int i = 0; i < segments.size(); i++) {
            Segment segment = segments.get(i);
            if (segment.bold()) Fonts.drawBold(ctx, segment.text(), cursor, y + 8, segment.color(), alpha);
            else Fonts.draw(ctx, segment.text(), cursor, y + 8, segment.color(), alpha);
            int tw = segment.bold() ? Fonts.widthBold(segment.text()) : Fonts.width(segment.text());
            cursor += tw + 10;
            if (i < segments.size() - 1) {
                ctx.fill(cursor - 5, y + 6, cursor - 4, y + h - 6, Draw.col(0xFFFFFF, 0.13f * alpha));
            }
        }
        Draw.gradLine(ctx, x + 9, y + h - 2, x + w - 9, 1, alpha * 0.7f);
    }
}
