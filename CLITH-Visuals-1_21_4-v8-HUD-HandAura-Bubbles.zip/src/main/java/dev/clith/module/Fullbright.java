package dev.clith.module;

import org.lwjgl.glfw.GLFW;

/** Local gamma boost; unlike a potion effect, it does not overwrite the player's effects. */
public class Fullbright extends Module {
    private Double previousGamma;

    public Fullbright() {
        super("Fullbright", "fullbright", GLFW.GLFW_KEY_B, Category.VISUAL, "Максимальная локальная яркость");
    }

    @Override
    public void onEnable() {
        if (mc.options == null) return;
        previousGamma = mc.options.getGamma().getValue();
        mc.options.getGamma().setValue(16.0);
    }

    @Override
    public void onTick() {
        if (mc.options != null) mc.options.getGamma().setValue(16.0);
    }

    @Override
    public void onDisable() {
        if (mc.options != null && previousGamma != null) {
            mc.options.getGamma().setValue(previousGamma);
        }
        previousGamma = null;
    }
}
