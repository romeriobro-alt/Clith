package dev.clith;

import dev.clith.module.Module;
import dev.clith.module.ModuleManager;
import dev.clith.module.Zoom;
import dev.clith.module.setting.Setting;
import dev.clith.gui.ThemeManager;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Saves module states and settings to config/clith.properties. */
public final class Config {
    /** Bumped when defaults/settings change meaning (4 = top HUD, hand aura and bubble trail). */
    private static final int CONFIG_VERSION = 4;

    private Config() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("clith.properties");
    }

    private static Path profileFile(String name) {
        String safe = name == null ? "default" : name.replaceAll("[^a-zA-Z0-9_-]", "_");
        if (safe.isBlank()) safe = "default";
        return FabricLoader.getInstance().getConfigDir().resolve("clith").resolve(safe + ".properties");
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(f)) {
            p.load(in);
        } catch (IOException e) {
            return;
        }
        apply(p);
    }

    public static void save() {
        Properties p = snapshot();
        try {
            Files.createDirectories(file().getParent());
            try (OutputStream out = Files.newOutputStream(file())) {
                p.store(out, "Clith client config");
            }
        } catch (IOException ignored) { }
    }

    /** Save a named preset independently from the active configuration. */
    public static void saveProfile(String name) {
        Properties p = snapshot();
        Path target = profileFile(name);
        try {
            Files.createDirectories(target.getParent());
            try (OutputStream out = Files.newOutputStream(target)) {
                p.store(out, "CLITH profile: " + name);
            }
        } catch (IOException ignored) { }
    }

    /** Load a named preset. Missing or malformed profiles are safely ignored. */
    public static boolean loadProfile(String name) {
        Path target = profileFile(name);
        if (!Files.isRegularFile(target)) return false;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(target)) { p.load(in); }
        catch (IOException e) { return false; }
        apply(p);
        save();
        return true;
    }

    private static Properties snapshot() {
        Properties p = new Properties();
        p.setProperty("clith.theme", ThemeManager.current().name());
        p.setProperty("clith.cfgver", String.valueOf(CONFIG_VERSION));
        for (Module m : ModuleManager.MODULES) {
            if (!(m instanceof Zoom)) p.setProperty(m.id + ".enabled", String.valueOf(m.isEnabled()));
            for (Setting s : m.settings) p.setProperty(m.id + "." + s.name, s.save());
        }
        return p;
    }

    private static void apply(Properties p) {
        int ver = 0;
        try { ver = Integer.parseInt(p.getProperty("clith.cfgver", "0").trim()); } catch (NumberFormatException ignored) { }
        // Configs written before v3 used the amber theme and old sky settings. Preserve themes from
        // v3 while migrating them to v4, which introduces the reference-style HUD and bubble trail.
        ThemeManager.Theme theme = ThemeManager.Theme.ICE;
        if (ver >= 3) {
            try { theme = ThemeManager.Theme.valueOf(p.getProperty("clith.theme", "ICE")); } catch (IllegalArgumentException ignored) { }
        }
        ThemeManager.set(theme);
        for (Module m : ModuleManager.MODULES) {
            for (Setting s : m.settings) {
                if (ver < 3 && m.id.equals("sky") && s.name.equals("Небо")) continue;
                String v = p.getProperty(m.id + "." + s.name);
                if (v != null) s.load(v);
            }
            if (m instanceof Zoom) continue;
            String en = p.getProperty(m.id + ".enabled");
            if (en != null) m.setEnabled(Boolean.parseBoolean(en));
            // One-time migration is intentionally after loading old values so an older config
            // cannot silently switch the new bubble trail back to the ribbon mode.
            if (ver < CONFIG_VERSION && m.id.equals("trails")) {
                for (Setting s : m.settings) if (s.name.equals("Стиль")) s.load("2");
                m.setEnabled(true);
            }
        }
    }
}
