package dev.clith;

import dev.clith.module.ModuleManager;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;

/** Extra HUD pieces: armor panel and floating damage numbers. */
public final class HudExtras {
    private HudExtras() {}

    public static void init() {
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.options.hudHidden || mc.player == null) return;
            if (ModuleManager.armorHud.isEnabled()) ModuleManager.armorHud.draw(ctx);
            if (ModuleManager.hitEffects.isEnabled()) ModuleManager.hitEffects.renderHud(ctx);
        });
    }
}
