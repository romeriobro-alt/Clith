CLITH WEBSITE — DEPLOYMENT NOTES

Main page: index.html

HOW TO UPLOAD
1. Extract this ZIP first if your hosting panel asks for a folder or individual site assets.
2. Upload the contents of this folder, keeping index.html at the root (not inside another nested folder).
3. Choose Production/Deploy in your hosting provider.

The page uses Google Fonts and Three.js from public CDNs, so those visual enhancements require internet access. A fallback is included if Three.js fails to load.

DOWNLOAD BUTTON
No .jar file was included with the supplied HTML. To avoid a broken 404 link, the page's client download button currently opens https://t.me/clithclient. To offer direct downloads later, upload your real .jar alongside index.html and change the button link to its exact filename.
